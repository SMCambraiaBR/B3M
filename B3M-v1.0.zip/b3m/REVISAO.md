# Revisão técnica — B3M 1.0.1

## Alterações desta revisão

- Corrigido `TaxRates.forTipo`: rendimentos de FIIs agora usam a alíquota configurada em **Rendimentos de FIIs**, sem reutilizar a alíquota de dividendos.
- Corrigido o tratamento de cancelamento nas buscas de mercado. Ao trocar ou cancelar uma busca, o cancelamento deixa de ser tratado como uma falha comum e não aciona fontes de fallback desnecessariamente.
- Corrigido o parser da listagem geral de FIIs do Fundamentus, que não reconhecia o ID de tabela usado nessa página; a busca/ranking de FIIs podia ficar vazio mesmo com dados disponíveis.
- Corrigida a variação diária da carteira para preferir o preço de fechamento anterior quando a fonte fornece esse dado, com fallback protegido para variação percentual inválida.
- A média de proventos foi renomeada para `average12` e o teste foi alinhado ao rótulo e comportamento de 12 meses da tela (o nome antigo dizia “6”, mas código e UI já calculavam “12”).
- O cálculo da carteira agora ordena os fechamentos por data e descarta preços não finitos ou não positivos; os intervalos de gráfico também retornam pontos cronológicos.
- Alinhado o fallback de proventos futuros sem data-com à data de pagamento documentada.
- Corrigida a invalidação concorrente dos caches de cotações e séries: consultas antigas não podem voltar a preencher o cache depois de um refresh. O teste cobre as rotas individual e em lote.
- Snapshots agora serializam gravações por chave e recusam sobrescrever um dado mais novo com resposta mais antiga concluída fora de ordem.
- Na segunda rodada de busca em lote, falhas transitórias não marcam ativos como definitivamente ausentes por cinco minutos; respostas com tickers não solicitados também são rejeitadas.
- Acrescentados testes de regressão para os comportamentos corrigidos acima.
- Atualizada a tela **Ajustes → Sobre**: Grok permanece identificado como início do projeto e Manus assina a revisão técnica e as correções desta versão.
- Versão do app atualizada de 1.0.0 (código 26) para 1.0.1 (código 27), para distinguir o APK de teste e permitir atualização sobre instalações com a mesma assinatura.
- O workflow do GitHub agora solicita explicitamente `platforms;android-35` e executa `testDebugUnitTest` antes de montar os APKs.
- Após o teste de instalação, restaurada a assinatura histórica no APK `debug`: debug e release voltam a usar `app/b3m-upload.jks`, como na versão que instalava corretamente.
- Corrigido o Mercado: o ranking de melhores dividendos agora busca e exibe a cotação atual abaixo do ticker, em vez de mostrar apenas o preço histórico usado pelo Fundamentus. O percentual de retorno também passa a usar essa cotação quando disponível.
- Corrigida a normalização de tickers retornados pelas fontes de cotação, evitando perder preços por espaços ou diferenças de maiúsculas/minúsculas.
- O resumo do ativo agora aproveita os campos de negociação do endpoint da B3 para abertura, máxima, mínima e volume, com fallback para nomes alternativos e sem aceitar zeros como dados válidos.
- Na aba **Posição** do detalhe do ativo, “Gasto real/un.” agora é `(investido − proventos recebidos) ÷ quantidade`; o custo total continua disponível internamente para os cálculos de resultado.
- Cotações que chegam apenas com preço agora são enriquecidas em paralelo por outras fontes, preenchendo mínima, máxima, volume, abertura e fechamento anterior quando disponíveis.
- A aba **Posição** agora mostra “Cotação atual” imediatamente acima de “Preço médio”.
- Nos melhores dividendos, removido o texto redundante “12m” da linha de cotação e D.Y.; o valor percentual continua sendo exibido abaixo na mesma linha informativa.
- Mercado e Carteira agora mantêm o estado de rolagem no nível da navegação; ao voltar do detalhe de um ativo, a tela retorna ao mesmo ponto e à mesma aba.
- A evolução patrimonial foi movida para logo abaixo do cartão de Patrimônio, mantendo o gráfico com as informações de patrimônio inicial e final junto ao bloco principal.
- O D.Y. dos melhores dividendos agora aparece em linha própria, abaixo da cotação.
- A composição das fontes de cotação também enriquece variação diária ausente/zerada: busca fechamento anterior ou uma variação válida em outra fonte, da mesma forma que já fazia com mínima, máxima e volume.
- Foi criado `ARQUIVOS-CRITICOS.md` e foram adicionados comentários `CRÍTICO` no Gradle, workflow, banco, montagem de dependências e navegação. A busca confirmou que não há seed ou ativo de demonstração no código; a carteira é criada apenas por lançamentos do usuário/importação CSV.
- Confirmado na resposta real da API B3 que o volume vem no campo `ttlQty` (não em `tradedQty`); o parser agora aceita esse campo e a corrida continua enriquecendo fechamento/variação quando a fonte vencedora não informa esses dados.
- O gráfico de evolução patrimonial passou para dentro do cartão de Patrimônio, logo abaixo do valor atual. Os cartões de patrimônio inicial/final ficam depois de Investido e Δ cotações.
- As listas detalhadas de proventos recebidos e futuros começam recolhidas; o valor “A receber” permanece visível e cada lista pode ser expandida pelo botão Mostrar.
- O ícone do aplicativo foi substituído pela arte B3M fornecida, aplicada tanto ao launcher legado quanto à camada do ícone adaptativo. As cópias foram convertidas para PNG real para garantir compatibilidade com o compilador Android.
- O `BrandHeader`, compartilhado por Mercado, Carteira e Ajustes, agora usa a nova logo horizontal “B3M Monitor” ao lado do título, sem alterar o ícone do launcher.
- A camada de primeiro plano do ícone adaptativo foi reduzida para uma área segura central. Isso evita o zoom/corte aplicado pela máscara do launcher Android e mantém a logo quadrada completa visível; o ícone legado continua usando a arte inteira.
- Os Destaques agora separam a lista de liquidez do Fundamentus em ações e FIIs antes de buscar as cotações: 75% das vagas ficam reservadas para ações e 25% para FIIs, evitando que uma categoria ocupe toda a seção.
- O resumo do Ibovespa na aba Mercado e o resumo de cada ação/FII agora calculam e exibem uma média de preço individual para o ano vigente e os dez anos anteriores (ex.: 2026, 2025, …, 2016), usando a série histórica completa disponível nas fontes de cotação.
- Os gráficos de ativos e do IBOV ganharam botão discreto de tela cheia, seleção de períodos, zoom/zoom out e alternância para candles. OHLC passou a ser carregado do Yahoo/brapi; quando uma fonte histórica antiga não tiver abertura, máxima e mínima, o modo linha permanece disponível como fallback.
- O carregamento foi otimizado: o gráfico de linha usa somente fechamentos e é buscado como antes; OHLC agora possui contrato, cache em memória e snapshot separados (`chart-ohlc`) e só é consultado quando o usuário toca em Candles, respeitando o período selecionado.
- As médias anuais do IBOV agora ficam recolhidas por padrão sob o título “Média por ano”. Nos ativos, ações e FIIs, os indicadores e demais informações aparecem antes, e a grade de médias anuais ficou como última seção do resumo. A tela ampliada dos gráficos ganhou pan por arraste, pinch zoom e tooltip OHLC nos candles.
- Após o teste do usuário, restaurado o suporte ao fluxo de projeto em ZIP: o workflow valida a estrutura, extrai em pasta isolada e compila tanto ZIPs quanto o checkout já extraído. Os APKs são copiados para `dist/` antes do upload, independentemente da pasta de origem.
- O workflow falha cedo se a chave de release esperada não estiver no caminho documentado.
- Criado `.gitignore` para arquivos de build, APKs, IDE e `local.properties`; revisadas as instruções para colocar o workflow no caminho correto da raiz do repositório.

## Limitação remanescente do parser

Linhas de proventos de ações sem data de pagamento (“-”) continuam não entrando nos cálculos, porque o modelo atual exige uma data para distinguir corretamente valor já recebido de valor anunciado. Não substituí essa data por uma data inventada; suportar esses anúncios exige um estado próprio de pagamento e apresentação na interface.

## Validação

Não foi possível concluir a suíte nem gerar o APK neste ambiente: a tentativa inicial parou pela ausência do Android SDK (`ANDROID_HOME` e `sdk.dir`); uma tentativa com SDK temporário também encontrou incompatibilidade entre o AAPT2 x86-64 do Android SDK e a arquitetura ARM64 do sandbox. Portanto, não afirmo que os testes ou o APK foram compilados aqui. O workflow atualizado instala o SDK Android 35 em runner GitHub x86-64 e executa os testes antes de compilar.

## Assinatura e segurança

O arquivo `app/b3m-upload.jks` e a configuração de assinatura foram mantidos para preservar a assinatura usada pelo fluxo atual e evitar quebrar atualizações de versões existentes. O projeto também contém credenciais de assinatura no script de build/workflow; o APK `debug` agora usa uma chave separada. Mantenha o repositório privado e não publique a chave ou credenciais. Se esse material já esteve público, trate a chave como comprometida: torná-lo privado não apaga cópias; planeje rotação e migração com cuidado, pois APKs assinados com outra chave não atualizam diretamente as instalações existentes. Para repositório público, use GitHub Actions Secrets sem trocar a identidade criptográfica usada nos APKs atuais.

## Créditos

- Início do projeto / vibe coding: Grok (xAI), conforme já identificado pelo projeto.
- Revisão de código, correções descritas acima e atualização do build: Manus.
