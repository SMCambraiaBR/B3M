# Revisão técnica — B3M 1.0.1

## Alterações desta revisão

- Corrigido `TaxRates.forTipo`: rendimentos de FIIs agora usam a alíquota configurada em **Rendimentos de FIIs**, sem reutilizar a alíquota de dividendos.
- Corrigido o tratamento de cancelamento nas buscas de mercado. Ao trocar ou cancelar uma busca, o cancelamento deixa de ser tratado como uma falha comum e não aciona fontes de fallback desnecessariamente.
- Corrigido o parser da listagem geral de FIIs do Fundamentus, que não reconhecia o ID de tabela usado nessa página; a busca/ranking de FIIs podia ficar vazio mesmo com dados disponíveis.
- Corrigida a variação diária da carteira para preferir o preço de fechamento anterior quando a fonte fornece esse dado, com fallback protegido para variação percentual inválida.
- A média de proventos foi renomeada para `average12` e o teste foi alinhado ao rótulo e comportamento de 12 meses da tela (o nome antigo dizia “6”, mas código e UI já calculavam “12”).
- O cálculo da carteira agora ordena os fechamentos por data e descarta preços não finitos ou não positivos; os intervalos de gráfico também retornam pontos cronológicos.
- Alinhado o fallback de proventos futuros sem data-com à data de pagamento documentada.
- Corrigida a invalidação concorrente dos caches de cotações e séries: consultas antigas não podem voltar a preencher o cache depois de um refresh. O teste cobre as rotas individual e em lote.
- Snapshots agora serializam gravações por chave e recusam sobrescrever um dado mais novo com resposta mais antiga concluída fora de ordem.
- Na segunda rodada de busca em lote, falhas transitórias não marcam ativos como definitivamente ausentes por cinco minutos; respostas com tickers não solicitados também são rejeitadas.
- Acrescentados testes de regressão para os comportamentos corrigidos acima.
- Atualizada a tela **Ajustes → Sobre**: Grok permanece identificado como início do projeto e Manus assina a revisão técnica e as correções desta versão.
- Versão do app atualizada de 1.0.0 (código 26) para 1.0.1 (código 27), para distinguir o APK de teste e permitir atualização sobre instalações com a mesma assinatura.
- O workflow do GitHub agora solicita explicitamente `platforms;android-35` e executa `testDebugUnitTest` antes de montar os APKs.
- Após o teste de instalação, restaurada a assinatura histórica no APK `debug`: debug e release voltam a usar `app/b3m-upload.jks`, como na versão que instalava corretamente.
- Após o teste do usuário, restaurado o suporte ao fluxo de projeto em ZIP: o workflow valida a estrutura, extrai em pasta isolada e compila tanto ZIPs quanto o checkout já extraído. Os APKs são copiados para `dist/` antes do upload, independentemente da pasta de origem.
- O workflow falha cedo se a chave de release esperada não estiver no caminho documentado.
- Criado `.gitignore` para arquivos de build, APKs, IDE e `local.properties`; revisadas as instruções para colocar o workflow no caminho correto da raiz do repositório.

## Limitação remanescente do parser

Linhas de proventos de ações sem data de pagamento (“-”) continuam não entrando nos cálculos, porque o modelo atual exige uma data para distinguir corretamente valor já recebido de valor anunciado. Não substituí essa data por uma data inventada; suportar esses anúncios exige um estado próprio de pagamento e apresentação na interface.

## Validação

Não foi possível concluir a suíte nem gerar o APK neste ambiente: a tentativa inicial parou pela ausência do Android SDK (`ANDROID_HOME` e `sdk.dir`); uma tentativa com SDK temporário também encontrou incompatibilidade entre o AAPT2 x86-64 do Android SDK e a arquitetura ARM64 do sandbox. Portanto, não afirmo que os testes ou o APK foram compilados aqui. O workflow atualizado instala o SDK Android 35 em runner GitHub x86-64 e executa os testes antes de compilar.

## Assinatura e segurança

O arquivo `app/b3m-upload.jks` e a configuração de assinatura foram mantidos para preservar a assinatura usada pelo fluxo atual e evitar quebrar atualizações de versões existentes. O projeto também contém credenciais de assinatura no script de build/workflow; o APK `debug` agora usa uma chave separada. Mantenha o repositório privado e não publique a chave ou credenciais. Se esse material já esteve público, trate a chave como comprometida: torná-lo privado não apaga cópias; planeje rotação e migração com cuidado, pois APKs assinados com outra chave não atualizam diretamente as instalações existentes. Para repositório público, use GitHub Actions Secrets sem trocar a identidade criptográfica usada nos APKs atuais.

## Créditos

- Início do projeto / vibe coding: Grok (xAI), conforme já identificado pelo projeto.
- Revisão de código, correções descritas acima e atualização do build: Manus.
