# Compilar o B3M só pelo GitHub (sem Android Studio)

## Passo a passo

### 1. Criar o repositório
1. Acesse [github.com/new](https://github.com/new).
2. Nome sugerido: `b3m`.
3. **Não** marque "Add a README". Use repositório privado; veja a observação da chave de assinatura abaixo.

### 2. Enviar o código
Extraia o ZIP e envie o **conteúdo de dentro da pasta `b3m/` para a raiz do repositório** — não envie a pasta externa `b3m/` como um único diretório. A raiz deve conter, entre outros, `.github/workflows/build.yml`, `app/`, `gradle/`, `gradlew` e `settings.gradle.kts`. O GitHub só reconhece Actions em `.github/workflows` na raiz; enviar apenas o ZIP ou deixar o workflow dentro de `b3m/.github/` não inicia a compilação.

Pela interface web: **Add file → Upload files** e envie os arquivos mantendo essa estrutura, inclusive a pasta oculta `.github/`.

Ou no computador:

```bash
git init
git add .
git commit -m "B3M v1.0.1"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/b3m.git
git push -u origin main
```

### 3. Gerar o APK
1. Aba **Actions** → **Build APK** → **Run workflow**.
2. Aguarde ~5–10 minutos.
3. O workflow executa os testes unitários e compila os APKs.
4. Em **Artifacts**, baixe **B3M-release** (preferível) ou **B3M-debug**.
5. Extraia o ZIP e instale o `.apk`. O debug usa a assinatura de depuração padrão e não atualiza diretamente um release; use o release para instalação normal e atualização.

### Instalação no Android 11 (Motorola e similares)

1. Se o Android aceitar a assinatura da versão instalada, instale por cima para preservar seus dados. Se informar que a assinatura é diferente, faça backup CSV da carteira antes de desinstalar a versão antiga.
2. Baixe o **B3M-release** (não o ZIP inteiro — o arquivo `.apk` de dentro).
3. Abra com o app **Arquivos** do Google (não só o Chrome).
4. Em Configurações → Apps → Arquivos → **Instalar apps desconhecidos** → permitir.
5. Se o Play Protect avisar “app prejudicial / bloqueado”:
   - Toque em **Mais detalhes** → **Instalar mesmo assim** (é sideload open-source, não vem da Play Store).
6. O SAI continua funcionando se o instalador do sistema recusar.

### Token brapi (opcional)
Depois de instalar: aba **Ajustes** → token gratuito de [brapi.dev](https://brapi.dev).

### Chave de assinatura — importante
O projeto mantém `app/b3m-upload.jks` e a configuração associada para preservar a identidade dos APKs e permitir atualizações. **Não publique essa chave em um repositório público.** Quem obtiver a chave e as credenciais do build pode assinar um APK que o Android aceite como atualização do B3M. Se esse material já foi publicado, trate-o como comprometido. Não remova nem troque a chave sem planejar a migração: APKs assinados com outra chave não atualizam diretamente instalações existentes. Recomenda-se guardar a chave e as credenciais em GitHub Actions Secrets; essa migração não foi aplicada nesta revisão para não quebrar o build atual.

## Estrutura importante
- `gradlew` + `gradle/wrapper/`
- `.github/workflows/build.yml`
- `app/b3m-upload.jks` — assinatura estável (não apague)
- `local.properties` **não** vai para o Git (ignorado pelo `.gitignore`)
