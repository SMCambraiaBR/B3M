package org.b3m.data.fundamentus

import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Test

class FundamentusClientTest {
    @Test
    fun `resultado reconhece tabela usada na pagina de FIIs`() {
        val html = """
            <table id="tabelaResultado">
              <thead><tr><th>Papel</th><th>Cotação</th><th>Dividend Yield</th><th>Liquidez</th></tr></thead>
              <tbody><tr><td>MXRF11</td><td>10,00</td><td>12,50%</td><td>500.000,00</td></tr></tbody>
            </table>
        """.trimIndent()

        val result = FundamentusClient(OkHttpClient()).parseResultado(html, stock = false)

        assertEquals(1, result.size)
        assertEquals("MXRF11", result.single().ticker)
        assertEquals(10.0, result.single().price, 1e-9)
        assertEquals(12.5, result.single().dividendYield, 1e-9)
        assertEquals(500_000.0, result.single().liquidity, 1e-9)
    }
}
