package org.b3m.data

import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.b3m.data.quotes.CachedQuoteSource
import org.b3m.data.quotes.ChartPoint
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.QuoteSource
import org.b3m.domain.Quote
import org.junit.Assert.assertEquals
import org.junit.Test

class CachedQuoteSourceTest {
    private class FakeSource(private val delayMs: Long = 0) : QuoteSource {
        val batchCalls = AtomicInteger(0)
        val singleCalls = AtomicInteger(0)
        val chartCalls = AtomicInteger(0)
        override suspend fun quote(ticker: String): Quote {
            singleCalls.incrementAndGet()
            delay(delayMs)
            return Quote(ticker.uppercase(), 10.0, 0.0)
        }
        override suspend fun quotes(tickers: List<String>): List<Quote> {
            batchCalls.incrementAndGet()
            delay(delayMs)
            return tickers.reversed().map { Quote(it.uppercase(), 10.0, 0.0) }
        }
        override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> {
            chartCalls.incrementAndGet()
            delay(delayMs)
            return listOf(ChartPoint(1L, 1.0))
        }
    }

    @Test fun `preserva ordem solicitada e duplicatas`() = runBlocking {
        val delegate = FakeSource()
        val cache = CachedQuoteSource(delegate)
        val result = cache.quotes(listOf("VALE3", "PETR4", "VALE3"))
        assertEquals(listOf("VALE3", "PETR4", "VALE3"), result.map { it.ticker })
        assertEquals(1, delegate.batchCalls.get())
    }

    @Test fun `lista vazia nao consulta fonte`() = runBlocking {
        val delegate = FakeSource()
        assertEquals(emptyList<Quote>(), CachedQuoteSource(delegate).quotes(emptyList()))
        assertEquals(0, delegate.batchCalls.get())
    }

    @Test fun `junta chamadas simultaneas em uma so requisicao`() = runBlocking {
        val delegate = FakeSource(delayMs = 100)
        val cache = CachedQuoteSource(delegate)
        val results = (1..6).map { async { cache.quote("PETR4") } }.awaitAll()
        assertEquals(6, results.size)
        assertEquals(1, delegate.singleCalls.get())
    }

    @Test fun `junta lotes identicos simultaneos`() = runBlocking {
        val delegate = FakeSource(delayMs = 100)
        val cache = CachedQuoteSource(delegate)
        (1..4).map { async { cache.quotes(listOf("PETR4", "VALE3")) } }.awaitAll()
        assertEquals(1, delegate.batchCalls.get())
    }

    @Test fun `cotacao expira depois da validade`() = runBlocking {
        var now = 0L
        val delegate = FakeSource()
        val cache = CachedQuoteSource(delegate, quoteTtlMs = 5_000, clock = { now })
        cache.quote("PETR4")
        now = 4_000
        cache.quote("PETR4")
        assertEquals(1, delegate.singleCalls.get())
        now = 6_000
        cache.quote("PETR4")
        assertEquals(2, delegate.singleCalls.get())
    }

    @Test fun `invalidar forca nova consulta a rede`() = runBlocking {
        val delegate = FakeSource()
        val cache = CachedQuoteSource(delegate)
        cache.quote("PETR4")
        cache.quote("PETR4")
        assertEquals(1, delegate.singleCalls.get())
        cache.invalidateQuotes()
        cache.quote("PETR4")
        assertEquals(2, delegate.singleCalls.get())
    }

    @Test fun `invalidacao em voo evita reutilizar e gravar a resposta antiga`() = runBlocking {
        val calls = AtomicInteger()
        val oldStarted = CompletableDeferred<Unit>()
        val releaseOld = CompletableDeferred<Unit>()
        val delegate = object : QuoteSource {
            override suspend fun quote(ticker: String): Quote {
                if (calls.incrementAndGet() == 1) {
                    oldStarted.complete(Unit)
                    releaseOld.await()
                    return Quote(ticker, 1.0, 0.0)
                }
                return Quote(ticker, 2.0, 0.0)
            }
            override suspend fun quotes(tickers: List<String>) = emptyList<Quote>()
            override suspend fun chart(ticker: String, range: ChartRange) = emptyList<ChartPoint>()
        }
        val cache = CachedQuoteSource(delegate)
        val oldRequest = async { cache.quote("PETR4") }
        oldStarted.await()
        cache.invalidateQuotes()

        assertEquals(2.0, cache.quote("PETR4").price, 0.0)
        releaseOld.complete(Unit)
        assertEquals(1.0, oldRequest.await().price, 0.0)
        assertEquals(2.0, cache.quote("PETR4").price, 0.0)
        assertEquals(2, calls.get())
    }

    @Test fun `invalidacao durante lote nao deixa resultado antigo no cache`() = runBlocking {
        val calls = AtomicInteger()
        val oldStarted = CompletableDeferred<Unit>()
        val releaseOld = CompletableDeferred<Unit>()
        val delegate = object : QuoteSource {
            override suspend fun quote(ticker: String) = Quote(ticker, 2.0, 0.0)
            override suspend fun quotes(tickers: List<String>): List<Quote> {
                if (calls.incrementAndGet() == 1) {
                    oldStarted.complete(Unit)
                    releaseOld.await()
                    return tickers.map { Quote(it, 1.0, 0.0) }
                }
                return tickers.map { Quote(it, 2.0, 0.0) }
            }
            override suspend fun chart(ticker: String, range: ChartRange) = emptyList<ChartPoint>()
        }
        val cache = CachedQuoteSource(delegate)
        val oldRequest = async { cache.quotes(listOf("PETR4")) }
        oldStarted.await()
        cache.invalidateQuotes()

        assertEquals(2.0, cache.quotes(listOf("PETR4")).single().price, 0.0)
        releaseOld.complete(Unit)
        assertEquals(1.0, oldRequest.await().single().price, 0.0)
        assertEquals(2.0, cache.quotes(listOf("PETR4")).single().price, 0.0)
        assertEquals(2, calls.get())
    }

    @Test fun `grafico do dia tem validade menor que o longo`() = runBlocking {
        var now = 0L
        val delegate = FakeSource()
        val cache = CachedQuoteSource(delegate, intradayChartTtlMs = 45_000, longChartTtlMs = 300_000, clock = { now })
        cache.chart("PETR4", ChartRange.D1)
        cache.chart("PETR4", ChartRange.Y1)
        now = 60_000
        cache.chart("PETR4", ChartRange.D1)
        cache.chart("PETR4", ChartRange.Y1)
        assertEquals(3, delegate.chartCalls.get()) // D1 buscou de novo; 1A ainda estava válido
    }

    @Test fun `falha nao fica guardada`() = runBlocking {
        val calls = AtomicInteger(0)
        val flaky = object : QuoteSource {
            override suspend fun quote(ticker: String): Quote {
                if (calls.incrementAndGet() == 1) error("rede caiu")
                return Quote(ticker, 5.0, 0.0)
            }
            override suspend fun quotes(tickers: List<String>) = emptyList<Quote>()
            override suspend fun chart(ticker: String, range: ChartRange) = emptyList<ChartPoint>()
        }
        val cache = CachedQuoteSource(flaky)
        val first = runCatching { cache.quote("PETR4") }
        assertEquals(true, first.isFailure)
        assertEquals(5.0, cache.quote("PETR4").price, 0.0)
    }
}
