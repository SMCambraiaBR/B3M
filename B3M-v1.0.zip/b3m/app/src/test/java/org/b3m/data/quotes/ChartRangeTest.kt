package org.b3m.data.quotes

import org.junit.Assert.assertEquals
import org.junit.Test

class ChartRangeTest {
    @Test
    fun `trim retorna pontos em ordem cronologica mesmo sem recorte`() {
        val points = listOf(ChartPoint(3L, 3.0), ChartPoint(1L, 1.0), ChartPoint(2L, 2.0))

        val ordered = ChartRange.M1.trim(points)

        assertEquals(listOf(1L, 2L, 3L), ordered.map { it.epochMillis })
    }
}
