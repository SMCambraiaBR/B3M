package org.b3m.data.market

import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.b3m.data.quotes.MarketListSource
import org.b3m.domain.Quote
import org.junit.Assert.assertEquals
import org.junit.Test

class FallbackMarketSourceTest {
    @Test
    fun `cancelar busca nao chama a fonte seguinte`() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val fallbackCalls = AtomicInteger()
        val waiting = object : MarketListSource {
            override suspend fun search(prefix: String): List<Quote> {
                started.complete(Unit)
                awaitCancellation()
            }
            override suspend fun topGainers(limit: Int) = emptyList<Quote>()
            override suspend fun topLosers(limit: Int) = emptyList<Quote>()
            override suspend fun mostTraded(limit: Int) = emptyList<Quote>()
        }
        val fallback = object : MarketListSource {
            override suspend fun search(prefix: String): List<Quote> {
                fallbackCalls.incrementAndGet()
                return listOf(Quote("PETR4", 30.0, 0.0))
            }
            override suspend fun topGainers(limit: Int) = emptyList<Quote>()
            override suspend fun topLosers(limit: Int) = emptyList<Quote>()
            override suspend fun mostTraded(limit: Int) = emptyList<Quote>()
        }

        val job = launch { FallbackMarketSource(listOf(waiting, fallback)).search("PE") }
        started.await()
        job.cancelAndJoin()

        assertEquals(0, fallbackCalls.get())
    }
}
