package org.b3m.data.quotes

import java.time.LocalDate
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AnnualAveragesTest {
    private val zone = ZoneId.of("UTC")

    @Test
    fun `retorna o ano vigente e os dez anteriores em ordem decrescente`() {
        fun point(date: LocalDate, value: Double) = ChartPoint(date.atStartOfDay(zone).toInstant().toEpochMilli(), value)
        val result = annualAverages(
            listOf(point(LocalDate.of(2026, 1, 2), 100.0), point(LocalDate.of(2026, 2, 2), 120.0), point(LocalDate.of(2025, 3, 2), 80.0)),
            today = LocalDate.of(2026, 6, 1),
            zone = zone,
        )
        assertEquals((2026 downTo 2016).toList(), result.map { it.year })
        assertEquals(110.0, result.first().value!!, 0.0)
        assertEquals(80.0, result[1].value!!, 0.0)
        assertNull(result[2].value)
    }
}
