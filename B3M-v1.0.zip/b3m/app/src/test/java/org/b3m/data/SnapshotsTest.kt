package org.b3m.data

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import org.b3m.data.quotes.ChartPoint
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.QuoteRepository
import org.b3m.data.quotes.QuoteSource
import org.b3m.data.snapshot.Codec
import org.b3m.data.snapshot.MemorySnapshotStore
import org.b3m.data.snapshot.Snapshots
import org.b3m.domain.Quote
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SnapshotsTest {

    private val intCodec = Codec<Int>({ it.toString() }, { it.toInt() })

    @Test
    fun `coleta com sucesso guarda e informa a hora`() = runBlocking {
        var now = 1_000L
        val snaps = Snapshots(MemorySnapshotStore(), clock = { now })
        val r = snaps.fetch("k", intCodec) { 42 }
        assertEquals(42, r.value)
        assertEquals(1_000L, r.fetchedAt)
        assertFalse(r.stale)
        now = 9_000L
        val again = snaps.lastKnown("k", intCodec)!!
        assertEquals(42, again.value)
        assertEquals(1_000L, again.fetchedAt)
    }

    @Test
    fun `snapshot antigo concluido por ultimo nao substitui o mais novo`() = runBlocking {
        val store = MemorySnapshotStore()
        val snaps = Snapshots(store)
        val oldStarted = CompletableDeferred<Unit>()
        val releaseOld = CompletableDeferred<Unit>()
        val oldRequest = async {
            snaps.fetch("k", intCodec, stampOf = { 1L }) {
                oldStarted.complete(Unit)
                releaseOld.await()
                1
            }
        }
        oldStarted.await()
        snaps.fetch("k", intCodec, stampOf = { 2L }) { 2 }
        releaseOld.complete(Unit)
        oldRequest.await()

        val latest = snaps.lastKnown("k", intCodec)!!
        assertEquals(2, latest.value)
        assertEquals(2L, latest.fetchedAt)
    }

    @Test
    fun `falha devolve o ultimo dado marcado como desatualizado com a hora antiga`() = runBlocking {
        var now = 1_000L
        val snaps = Snapshots(MemorySnapshotStore(), clock = { now })
        snaps.fetch("k", intCodec) { 42 }
        now = 5_000L
        val r = snaps.fetch("k", intCodec) { error("sem internet") }
        assertEquals(42, r.value)
        assertEquals(1_000L, r.fetchedAt)
        assertTrue(r.stale)
    }

    @Test(expected = IllegalStateException::class)
    fun `falha sem nenhuma coleta anterior lanca o erro`() {
        runBlocking {
            Snapshots(MemorySnapshotStore()).fetch("k", intCodec) { error("sem internet") }
        }
    }

    @Test
    fun `usa a hora propria do dado quando informada`() = runBlocking {
        val snaps = Snapshots(MemorySnapshotStore(), clock = { 9_999L })
        val r = snaps.fetch("k", intCodec, stampOf = { 123L }) { 1 }
        assertEquals(123L, r.fetchedAt)
    }

    @Test
    fun `dado corrompido em disco e ignorado`() = runBlocking {
        val store = MemorySnapshotStore()
        store.save("k", "isso-nao-e-numero", 1L)
        assertNull(Snapshots(store).lastKnown("k", intCodec))
    }

    @Test
    fun `prune remove o que e antigo`() = runBlocking {
        var now = 100L
        val snaps = Snapshots(MemorySnapshotStore(), clock = { now })
        snaps.fetch("velho", intCodec) { 1 }
        now = 10_000L
        snaps.fetch("novo", intCodec) { 2 }
        snaps.prune(maxAgeMs = 5_000L)
        assertNull(snaps.lastKnown("velho", intCodec))
        assertNotNull(snaps.lastKnown("novo", intCodec))
    }

    // ---- QuoteRepository ----

    private val quoteCodec = Codec<Quote>(
        { "${it.ticker}|${it.price}|${it.changePct}|${it.fetchedAt}" },
        { s -> s.split("|").let { Quote(it[0], it[1].toDouble(), it[2].toDouble(), fetchedAt = it[3].toLong()) } },
    )
    private val chartCodec = Codec<List<ChartPoint>>(
        { l -> l.joinToString(";") { "${it.epochMillis},${it.value}" } },
        { s -> s.split(";").map { p -> p.split(",").let { ChartPoint(it[0].toLong(), it[1].toDouble()) } } },
    )

    private class Switchable : QuoteSource {
        var up = true
        var known = setOf("PETR4", "VALE3")
        var at = 0L
        override suspend fun quote(ticker: String): Quote {
            if (!up || ticker !in known) error("fora do ar")
            return Quote(ticker, 10.0, 1.0, fetchedAt = at)
        }
        override suspend fun quotes(tickers: List<String>): List<Quote> {
            if (!up) error("fora do ar")
            return tickers.filter { it in known }.map { Quote(it, 10.0, 1.0, fetchedAt = at) }
        }
        override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> {
            if (!up) error("fora do ar")
            return listOf(ChartPoint(1L, 1.0), ChartPoint(2L, 2.0))
        }
    }

    @Test
    fun `lote traz cotacao nova e cai para a guardada quando a fonte cai`() = runBlocking {
        val src = Switchable()
        val repo = QuoteRepository(src, Snapshots(MemorySnapshotStore()), quoteCodec, chartCodec)
        src.at = 1_000L
        val ok = repo.quotes(listOf("PETR4", "VALE3"))
        assertFalse(ok.getValue("PETR4").stale)
        assertEquals(1_000L, ok.getValue("PETR4").fetchedAt)

        src.up = false
        src.at = 9_000L
        val down = repo.quotes(listOf("PETR4", "VALE3", "ITUB4"))
        assertTrue(down.getValue("PETR4").stale)
        assertEquals(1_000L, down.getValue("PETR4").fetchedAt) // hora da última coleta, não a de agora
        assertNull(down["ITUB4"]) // nunca coletado: não inventa cotação
    }

    @Test
    fun `lote nunca lanca erro mesmo com a fonte fora do ar`() = runBlocking {
        val src = Switchable().also { it.up = false }
        val repo = QuoteRepository(src, Snapshots(MemorySnapshotStore()), quoteCodec, chartCodec)
        assertEquals(emptyMap<String, Any>(), repo.quotes(listOf("PETR4")))
    }

    @Test
    fun `ativo que a fonte nao tem mais usa a ultima cotacao guardada`() = runBlocking {
        val src = Switchable()
        val repo = QuoteRepository(src, Snapshots(MemorySnapshotStore()), quoteCodec, chartCodec)
        src.at = 500L
        repo.quotes(listOf("PETR4"))
        src.known = emptySet()
        val r = repo.quotes(listOf("PETR4")).getValue("PETR4")
        assertTrue(r.stale)
        assertEquals(500L, r.fetchedAt)
    }

    @Test
    fun `grafico guarda a ultima coleta`() = runBlocking {
        var now = 7_000L
        val src = Switchable()
        val repo = QuoteRepository(src, Snapshots(MemorySnapshotStore(), clock = { now }), quoteCodec, chartCodec)
        val ok = repo.chart("PETR4", ChartRange.M1)
        assertEquals(7_000L, ok.fetchedAt)
        src.up = false
        now = 8_000L
        val stale = repo.chart("PETR4", ChartRange.M1)
        assertTrue(stale.stale)
        assertEquals(7_000L, stale.fetchedAt)
        assertEquals(2, stale.value.size)
    }

    @Test
    fun `cotacoes guardadas aparecem antes da rede responder`() = runBlocking {
        val src = Switchable()
        val repo = QuoteRepository(src, Snapshots(MemorySnapshotStore()), quoteCodec, chartCodec)
        src.at = 42L
        repo.quotes(listOf("PETR4"))
        val known = repo.lastKnownQuotes(listOf("PETR4", "VALE3"))
        assertEquals(setOf("PETR4"), known.keys)
        assertFalse(known.getValue("PETR4").stale)
    }
}
