package org.b3m.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Regra: verde = positivo, vermelho = negativo. Fundo azul escuro (identidade B3M). */
object AppColors {
    val Positive = Color(0xFF2EE59D)
    val Negative = Color(0xFFFF5A5F)
    val Neutral = Color(0xFF9AABB8)
    val Warning = Color(0xFFFFB74D)
    /** Azul da logo, um pouco mais escuro — base do layout. */
    val Brand = Color(0xFF2F6FE0)
    val BrandDark = Color(0xFF1A4FAD)
    val Background = Color(0xFF0A1628)
    val Card = Color(0xFF12233A)
    val CardAlt = Color(0xFF1A3050)

    fun forChange(value: Double): Color = when {
        value > 0 -> Positive
        value < 0 -> Negative
        else -> Neutral
    }
}

private val Dark = darkColorScheme(
    background = AppColors.Background,
    surface = AppColors.Card,
    primary = AppColors.Brand,
    onBackground = Color.White,
    onSurface = Color.White,
    secondary = AppColors.BrandDark,
)

@Composable
fun B3MTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Dark, content = content)
}
