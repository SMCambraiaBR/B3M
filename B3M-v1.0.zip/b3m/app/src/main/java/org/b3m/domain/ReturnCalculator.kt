package org.b3m.domain

import java.time.LocalDate
import java.util.Locale

/**
 * Alíquotas de imposto retido na fonte, em fração (0,15 = 15%). Ficam em um só lugar
 * (Ajustes) e valem para o app inteiro: todo valor "líquido" já desconta estas taxas.
 */
data class TaxRates(
    val dividendo: Double = 0.0,
    val jcp: Double = 0.15,
    val rendimento: Double = 0.0, // FIIs: isento para pessoa física, em regra
) {
    fun forTipo(tipo: ProventoTipo): Double = when (tipo) {
        ProventoTipo.DIVIDENDO -> dividendo
        ProventoTipo.JCP -> jcp
        ProventoTipo.RENDIMENTO -> rendimento
    }

    fun with(tipo: ProventoTipo, rate: Double): TaxRates {
        val r = sanitize(rate)
        return when (tipo) {
            ProventoTipo.DIVIDENDO -> copy(dividendo = r)
            ProventoTipo.JCP -> copy(jcp = r)
            ProventoTipo.RENDIMENTO -> copy(rendimento = r)
        }
    }

    /** "15%", "0%", "17,5%". */
    fun percentText(tipo: ProventoTipo): String = percentText(forTipo(tipo))

    /** "JCP 15% · dividendos 0% · rendimentos de FIIs 0%". */
    fun summary(): String =
        "JCP ${percentText(ProventoTipo.JCP)} · dividendos ${percentText(ProventoTipo.DIVIDENDO)} · " +
            "rendimentos de FIIs ${percentText(ProventoTipo.RENDIMENTO)}"

    companion object {
        fun sanitize(rate: Double): Double = if (rate.isFinite()) rate.coerceIn(0.0, 1.0) else 0.0

        fun percentText(rate: Double): String {
            val pct = rate * 100.0
            val whole = kotlin.math.abs(pct - Math.rint(pct)) < 1e-9
            return if (whole) String.format(Locale("pt", "BR"), "%.0f%%", pct)
            else String.format(Locale("pt", "BR"), "%.2f%%", pct).replace(",00%", "%").replace(Regex("0%$"), "%")
        }
    }
}

object ReturnCalculator {

    const val MONTHS = 12

    /** Valor líquido de um provento, já descontado o imposto. */
    fun net(p: Provento, taxes: TaxRates): Double =
        p.valorBruto * (1.0 - taxes.forTipo(p.tipo))

    /**
     * "Retorno": soma dos proventos líquidos pagos nos últimos 12 meses ÷ 12.
     * "% Retorno": Retorno ÷ cotação atual.
     */
    fun calculate(
        proventos: List<Provento>,
        price: Double,
        today: LocalDate = LocalDate.now(),
        taxes: TaxRates = TaxRates(),
    ): RetornoResult {
        // Janela fechada nos 12 meses: inclui a data inicial e a de hoje.
        // Dividendos, JCP e rendimentos entram todos na mesma soma (só o imposto difere).
        val start = today.minusMonths(MONTHS.toLong())
        val total = proventos
            .filter { !it.dataPagamento.isBefore(start) && !it.dataPagamento.isAfter(today) }
            .sumOf { net(it, taxes) }
        val retorno = total / MONTHS
        val pct = if (price > 0) retorno / price * 100.0 else 0.0
        return RetornoResult(retorno, pct)
    }
}
