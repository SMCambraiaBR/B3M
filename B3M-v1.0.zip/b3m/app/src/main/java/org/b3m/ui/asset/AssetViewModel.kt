package org.b3m.ui.asset

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import org.b3m.data.db.LancamentoRepository
import org.b3m.data.db.WatchlistRepository
import org.b3m.data.db.tryAdd
import org.b3m.data.db.tryRemove
import org.b3m.data.fundamentus.Detalhes
import org.b3m.data.fundamentus.FundamentusApi
import org.b3m.data.fundamentus.Indicador
import org.b3m.data.quotes.ChartPoint
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.QuoteRepository
import org.b3m.data.safely
import org.b3m.data.snapshot.DataCodecs
import org.b3m.data.snapshot.Snapshots
import org.b3m.domain.DividendCalculator
import org.b3m.domain.IncomeEvent
import org.b3m.domain.Lancamento
import org.b3m.domain.Position
import org.b3m.domain.PositionCalculator
import org.b3m.domain.Provento
import org.b3m.domain.Quote
import org.b3m.domain.RetornoResult
import org.b3m.domain.ReturnCalculator
import org.b3m.domain.TaxRates
import org.b3m.ui.Section
import org.b3m.ui.toSection

/**
 * Minha posição no ativo (some se não tenho nada).
 * [price] é null quando nunca houve cotação: aí se usa o preço médio e a tela avisa.
 * [dividendsNet] já está líquido de imposto; [taxPaid] é o que foi retido.
 */
data class PositionInfo(
    val position: Position,
    val price: Double?,
    val priceStale: Boolean,
    val dividendsNet: Double,
    val taxPaid: Double,
) {
    val currentPrice: Double get() = price ?: position.averagePrice
    val invested: Double get() = position.invested
    val value: Double get() = position.quantity * currentPrice
    val result: Double get() = value - invested
    val resultPct: Double get() = if (invested > 0) result / invested * 100 else 0.0

    /** Resultado somando os proventos líquidos recebidos. */
    val totalResult: Double get() = result + dividendsNet
    val totalResultPct: Double get() = if (invested > 0) totalResult / invested * 100 else 0.0

    /** Gasto real: o que foi investido menos o que já voltou em proventos. */
    val realCost: Double get() = invested - dividendsNet
    /** Gasto real por ação/cota mantida. */
    val realCostPerUnit: Double
        get() = if (position.quantity > 0.0) realCost / position.quantity else 0.0
}

data class AssetUi(
    val ticker: String,
    val quote: Section<Quote> = Section(),
    val range: ChartRange = ChartRange.D1,
    val chart: Section<List<ChartPoint>> = Section(),
    val detalhes: Section<Detalhes> = Section(),
    val proventos: Section<List<Provento>> = Section(),
    val favorite: Boolean = false,
    val taxes: TaxRates = TaxRates(),
    // derivados (calculados no combine)
    val lancamentos: List<Lancamento> = emptyList(), // só deste ativo
    val retorno: RetornoResult? = null,
    val position: PositionInfo? = null,
    val incomeEvents: List<IncomeEvent> = emptyList(),
) {
    /** Os indicadores principais com nome por extenso e explicação (só os que o site trouxe). */
    val indicadores: List<Pair<Indicador, String>> get() = detalhes.data?.indicadoresPrincipais().orEmpty()
}

/**
 * Tela de um ativo. [start] quando a tela aparece (descarta os caches e busca tudo de novo,
 * mostrando antes o último dado guardado) e [stop] quando ela sai de vista.
 */
class AssetViewModel(
    private val ticker: String,
    private val quotes: QuoteRepository,
    private val fundamentus: FundamentusApi,
    private val snapshots: Snapshots,
    private val codecs: DataCodecs,
    private val repo: LancamentoRepository,
    private val watchlist: WatchlistRepository,
    taxes: StateFlow<TaxRates>,
    private val quoteRefreshMs: Long = 10_000,
    private val retryMs: Long = RETRY_MS,
) : ViewModel() {

    private val raw = MutableStateFlow(AssetUi(ticker))
    private var job: Job? = null
    private var chartJob: Job? = null

    private val mine = repo.observe().map { list -> list.filter { it.ticker.equals(ticker, ignoreCase = true) } }
    private val isFavorite = watchlist.observe().map { list -> list.any { it.equals(ticker, ignoreCase = true) } }

    val ui: StateFlow<AssetUi> = combine(raw, mine, taxes, isFavorite) { r, lancs, tx, fav ->
        derive(r, lancs, tx, fav)
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AssetUi(ticker, taxes = taxes.value))

    private fun derive(r: AssetUi, lancs: List<Lancamento>, tx: TaxRates, fav: Boolean): AssetUi {
        val price = r.quote.data?.price
        val proventos = r.proventos.data
        val retorno = if (price != null && proventos != null) ReturnCalculator.calculate(proventos, price, taxes = tx) else null
        val pos = PositionCalculator.calculate(lancs).firstOrNull()
        val events = if (proventos != null) DividendCalculator.events(lancs, proventos, taxes = tx) else emptyList()
        val info = pos?.let {
            PositionInfo(
                position = it,
                price = price,
                priceStale = r.quote.stale,
                dividendsNet = events.sumOf { e -> e.net },
                taxPaid = events.sumOf { e -> e.tax },
            )
        }
        return r.copy(taxes = tx, favorite = fav, lancamentos = lancs, retorno = retorno, position = info, incomeEvents = events)
    }

    // ---- ciclo de vida da tela ---------------------------------------------------------

    fun start() {
        if (job?.isActive == true) return
        quotes.invalidateQuotes()
        fundamentus.invalidate(ticker)
        job = viewModelScope.launch {
            supervisorScope {
                launch { pollQuote() }
                launch { loadFundamentals() }
            }
        }
        launchChart(raw.value.range)
    }

    fun stop() {
        job?.cancel()
        chartJob?.cancel()
        job = null
        chartJob = null
    }

    /** Botão "atualizar" / "tentar de novo". */
    fun refresh() {
        if (job == null) return
        stop()
        start()
    }

    fun selectRange(range: ChartRange) {
        if (range == raw.value.range && raw.value.chart.data != null) return
        raw.update { it.copy(range = range, chart = Section()) }
        if (job != null) launchChart(range)
    }

    // ---- cotação ------------------------------------------------------------------------

    private suspend fun pollQuote() {
        quotes.lastKnownQuote(ticker)?.let { s ->
            raw.update { if (it.quote.data == null) it.copy(quote = s.toSection()) else it }
        }
        while (true) {
            safely { quotes.quote(ticker) }
                .onSuccess { s -> raw.update { it.copy(quote = s.toSection()) } }
                .onFailure { raw.update { s -> s.copy(quote = s.quote.failed("Sem cotação agora.")) } }
            delay(quoteRefreshMs)
        }
    }

    private fun launchChart(range: ChartRange) {
        chartJob?.cancel()
        chartJob = viewModelScope.launch {
            quotes.lastKnownChart(ticker, range)?.let { s ->
                raw.update { if (it.range == range && it.chart.data == null) it.copy(chart = s.toSection()) else it }
            }
            while (true) {
                safely { quotes.chart(ticker, range) }
                    .onSuccess { s -> raw.update { if (it.range == range) it.copy(chart = s.toSection()) else it } }
                    .onFailure {
                        raw.update { if (it.range == range) it.copy(chart = it.chart.failed("Gráfico indisponível agora.")) else it }
                    }
                if (!range.isIntraday) break // só o gráfico do dia e da semana muda sozinho
                delay(60_000)
            }
        }
    }

    // ---- Fundamentus: indicadores e proventos --------------------------------------------

    private suspend fun loadFundamentals() {
        snapshots.lastKnown(detalhesKey(), codecs.detalhes)?.let { s ->
            raw.update { if (it.detalhes.data == null) it.copy(detalhes = s.toSection()) else it }
        }
        snapshots.lastKnown(proventosKey(), codecs.proventos)?.let { s ->
            raw.update { if (it.proventos.data == null) it.copy(proventos = s.toSection()) else it }
        }
        // Se alguma coleta falhar, tenta de novo a cada minuto (sem marcar "sem proventos" por engano).
        while (true) {
            val d = loadDetalhes()
            val p = loadProventos()
            if (d && p) break
            delay(retryMs)
        }
    }

    private suspend fun loadDetalhes(): Boolean =
        safely { snapshots.fetch(detalhesKey(), codecs.detalhes) { fundamentus.detalhes(ticker) } }.fold(
            onSuccess = { s -> raw.update { it.copy(detalhes = s.toSection()) }; !s.stale },
            onFailure = { raw.update { it.copy(detalhes = it.detalhes.failed("Dados do Fundamentus indisponíveis para $ticker.")) }; false },
        )

    private suspend fun loadProventos(): Boolean =
        safely { snapshots.fetch(proventosKey(), codecs.proventos) { fundamentus.proventos(ticker) } }.fold(
            onSuccess = { s -> raw.update { it.copy(proventos = s.toSection()) }; !s.stale },
            onFailure = { raw.update { it.copy(proventos = it.proventos.failed("Proventos indisponíveis para $ticker.")) }; false },
        )

    private fun detalhesKey() = "detalhes:${ticker.uppercase()}"
    private fun proventosKey() = "proventos:${ticker.uppercase()}"

    // ---- ações --------------------------------------------------------------------------

    fun toggleFavorite() {
        viewModelScope.launch {
            if (ui.value.favorite) watchlist.remove(ticker) else watchlist.add(ticker)
        }
    }

    /** Valida e grava a compra/venda. [onResult] recebe a mensagem de erro, ou null se deu certo. */
    fun addLancamento(l: Lancamento, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repo.tryAdd(l)) }
    }

    fun removeLancamento(id: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repo.tryRemove(id)) }
    }

    companion object {
        const val RETRY_MS = 60_000L
    }
}
