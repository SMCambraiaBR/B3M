package org.b3m.data.quotes

import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.b3m.data.safely
import org.b3m.domain.Quote
import org.b3m.domain.isValid

/** Guarda a latência média (média móvel) de cada fonte e operação, medida no próprio aparelho. */
class LatencyTracker {
    private class Stat(var avgMs: Double = 0.0, var samples: Int = 0)

    private val stats = ConcurrentHashMap<String, Stat>()

    fun record(key: String, ms: Long) {
        val s = stats.getOrPut(key) { Stat() }
        synchronized(s) {
            s.avgMs = if (s.samples == 0) ms.toDouble() else s.avgMs * 0.7 + ms * 0.3
            s.samples++
        }
    }

    /** Chave mais rápida entre [keys], se já tiver amostras suficientes para confiar. */
    fun fastest(keys: List<String>, minSamples: Int = 3): String? =
        keys.mapNotNull { k -> stats[k]?.takeIf { it.samples >= minSamples }?.let { k to it.avgMs } }
            .minByOrNull { it.second }?.first

    fun averageMs(key: String): Double? = stats[key]?.avgMs
}

class NamedSource(val name: String, val source: QuoteSource)

/**
 * Consulta várias fontes e usa a que responder primeiro COM UMA RESPOSTA VÁLIDA.
 *
 * Uma resposta vazia (lista sem cotações, gráfico sem pontos) ou com preço zero conta como
 * falha: não vence a corrida e não entra na estatística de velocidade. Isso impede que uma
 * fonte bloqueada, que "responde" rápido com nada, vire a preferida.
 *
 * Enquanto não há amostras, todas são consultadas em paralelo e a primeira resposta válida
 * vence (as outras são canceladas). Depois de algumas respostas, a mais rápida (por operação)
 * é consultada sozinha, com tempo limite; se falhar, volta a competir.
 *
 * Em consultas em lote, o que a fonte vencedora não trouxe é pedido numa segunda rodada
 * (outra fonte pode ter o ativo). Só ativos omitidos após uma resposta complementar válida
 * recebem TTL negativo; erro ou resposta vazia não bloqueia novas tentativas.
 */
class RacingQuoteSource(
    private val sources: List<NamedSource>,
    private val tracker: LatencyTracker = LatencyTracker(),
    private val fastTimeoutMs: Long = 5_000,
    private val missingTtlMs: Long = 5 * 60_000,
    private val clock: () -> Long = System::currentTimeMillis,
) : QuoteSource {

    private val missingUntil = ConcurrentHashMap<String, Long>()

    private suspend fun <T> timed(op: String, s: NamedSource, valid: (T) -> Boolean, block: suspend (QuoteSource) -> T): T {
        val start = System.nanoTime()
        // Fora da thread principal: parsing de JSON/HTML não pode travar a tela.
        val result = withContext(Dispatchers.Default) { block(s.source) }
        check(valid(result)) { "${s.name}: resposta vazia ou inválida" }
        tracker.record("${s.name}:$op", (System.nanoTime() - start) / 1_000_000)
        return result
    }

    private suspend fun <T> race(op: String, valid: (T) -> Boolean, block: suspend (QuoteSource) -> T): T = coroutineScope {
        val bestKey = tracker.fastest(sources.map { "${it.name}:$op" })
        val best = bestKey?.let { k -> sources.first { "${it.name}:$op" == k } }
        if (best != null) {
            val fast = withTimeoutOrNull(fastTimeoutMs) { safely { timed(op, best, valid, block) }.getOrNull() }
            if (fast != null) return@coroutineScope fast
        }

        val channel = Channel<Result<T>>(sources.size)
        val jobs = sources.map { s ->
            launch { channel.send(safely { timed(op, s, valid, block) }) }
        }
        var lastError: Throwable? = null
        repeat(sources.size) {
            val res = channel.receive()
            if (res.isSuccess) {
                jobs.forEach { it.cancel() }
                return@coroutineScope res.getOrThrow()
            }
            lastError = res.exceptionOrNull()
        }
        throw lastError ?: IllegalStateException("Nenhuma fonte de cotação configurada")
    }

    override suspend fun quote(ticker: String): Quote {
        val first = race("quote", { q: Quote -> q.isValid() }) { it.quote(ticker) }
        if (first.hasSummaryFields()) return first

        // Uma fonte pode responder rapidamente com o preço, mas sem mínima/volume.
        // Nesse caso, consulta as demais em paralelo e completa apenas os campos ausentes.
        val candidates = coroutineScope {
            sources.map { source ->
                async { safely { source.source.quote(ticker) }.getOrNull() }
            }.awaitAll().filterNotNull()
        }
        return candidates.fold(first) { current, candidate -> current.mergeMissing(candidate) }
    }

    override suspend fun quotes(tickers: List<String>): List<Quote> {
        if (tickers.isEmpty()) return emptyList()
        val wanted = tickers.map { it.trim().uppercase() }.distinct()
        val wantedSet = wanted.toSet()
        val first = race(
            "quotes",
            { l: List<Quote> -> l.any { it.isValid() && it.ticker.trim().uppercase() in wantedSet } },
        ) { it.quotes(tickers) }
            .filter { it.isValid() && it.ticker.trim().uppercase() in wantedSet }
        val have = first.map { it.ticker.trim().uppercase() }.toSet()
        val now = clock()
        val missing = wanted.filter { it !in have && (missingUntil[it] ?: 0L) <= now }
        if (missing.isEmpty()) return first

        val missingSet = missing.toSet()
        val extraResult = safely {
            race(
                "quotes",
                { l: List<Quote> -> l.any { it.isValid() && it.ticker.trim().uppercase() in missingSet } },
            ) { it.quotes(missing) }
        }
        if (extraResult.isFailure) return first
        val extra = extraResult.getOrThrow()
            .filter { it.isValid() && it.ticker.trim().uppercase() in missingSet }
        val got = extra.map { it.ticker.trim().uppercase() }.toSet()
        missing.filter { it !in got }.forEach { missingUntil[it] = now + missingTtlMs }
        return first + extra.filter { it.ticker.trim().uppercase() !in have }
    }

    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> =
        race("chart", { l: List<ChartPoint> -> l.isNotEmpty() }) { it.chart(ticker, range) }

    override suspend fun chartOhlc(ticker: String, range: ChartRange): List<ChartPoint> =
        race("chart-ohlc", { l: List<ChartPoint> -> l.any { it.open != null && it.high != null && it.low != null } }) {
            it.chartOhlc(ticker, range)
        }

    override fun invalidateQuotes() {
        missingUntil.clear()
        sources.forEach { it.source.invalidateQuotes() }
    }

    private fun Quote.hasSummaryFields(): Boolean =
        positive(high) != null && positive(low) != null && positive(volume) != null && hasDailyChange()

    private fun Quote.hasDailyChange(): Boolean =
        positive(previousClose) != null || changePct.isFinite() && changePct != 0.0

    private fun Quote.mergeMissing(other: Quote): Quote = copy(
        open = positive(open) ?: positive(other.open),
        high = positive(high) ?: positive(other.high),
        low = positive(low) ?: positive(other.low),
        previousClose = positive(previousClose) ?: positive(other.previousClose),
        volume = positive(volume) ?: positive(other.volume),
        changePct = if (changePct.isFinite() && changePct != 0.0) changePct else other.changePct,
        trades = trades ?: other.trades,
        quantity = quantity ?: other.quantity,
    )

    private fun positive(value: Double?): Double? = value?.takeIf { it.isFinite() && it > 0.0 }
}
