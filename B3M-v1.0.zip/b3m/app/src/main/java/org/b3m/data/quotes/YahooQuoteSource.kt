package org.b3m.data.quotes

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull
import okhttp3.OkHttpClient
import org.b3m.data.safely
import org.b3m.domain.Quote

/**
 * Yahoo Finance (endpoint não oficial, sem chave). [host] permite usar o espelho
 * query2 como fonte separada: os dois hosts competem entre si na corrida.
 */
class YahooQuoteSource(
    private val http: OkHttpClient,
    private val host: String = "query1.finance.yahoo.com",
) : QuoteSource {

    private val json = Json { ignoreUnknownKeys = true }

    private suspend fun chartJson(ticker: String, range: String, interval: String): JsonObject {
        val url = "https://$host/v8/finance/chart/${Symbols.yahoo(ticker)}?range=$range&interval=$interval"
        val root = json.parseToJsonElement(http.getString(url)).jsonObject
        val result = root["chart"]?.jsonObject?.get("result") as? JsonArray
        return result?.firstOrNull()?.jsonObject ?: error("Yahoo: sem dados para $ticker")
    }

    override suspend fun quote(ticker: String): Quote {
        val result = chartJson(ticker, "1d", "1m")
        val meta = result["meta"]!!.jsonObject
        val price = meta.num("regularMarketPrice")?.takeIf { it > 0.0 } ?: error("Yahoo: sem preço para $ticker")
        val prev = meta.num("chartPreviousClose") ?: meta.num("previousClose")
        val opens = result.quoteSeries("open")
        return Quote(
            ticker = ticker.uppercase(),
            price = price,
            changePct = if (prev != null && prev > 0) (price - prev) / prev * 100.0 else 0.0,
            open = opens.firstOrNull { it != null },
            high = meta.num("regularMarketDayHigh"),
            low = meta.num("regularMarketDayLow"),
            previousClose = prev,
            volume = meta.num("regularMarketVolume"),
        )
    }

    override suspend fun quotes(tickers: List<String>): List<Quote> = coroutineScope {
        tickers.map { t -> async { safely { quote(t) }.getOrNull() } }
            .mapNotNull { it.await() }
    }

    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> {
        val result = chartJson(ticker, range.range, range.interval)
        val times = result["timestamp"]?.jsonArray ?: return emptyList()
        val closes = result.quoteSeries("close")
        val adj = result.adjSeries()
        val points = times.mapIndexedNotNull { i, t ->
            val ts = (t as? JsonPrimitive)?.longOrNull ?: return@mapIndexedNotNull null
            val close = closes.getOrNull(i) ?: adj.getOrNull(i) ?: return@mapIndexedNotNull null
            ChartPoint(ts * 1000, close)
        }
        return range.trim(points).takeIf { it.isNotEmpty() } ?: error("Yahoo: gráfico vazio para $ticker")
    }

    private fun JsonObject.num(key: String): Double? = (this[key] as? JsonPrimitive)?.doubleOrNull

    private fun JsonObject.quoteSeries(key: String): List<Double?> {
        val q = this["indicators"]?.jsonObject?.get("quote")?.jsonArray?.firstOrNull()?.jsonObject
        val arr = q?.get(key) as? JsonArray ?: return emptyList()
        return arr.map { (it as? JsonPrimitive)?.doubleOrNull }
    }

    private fun JsonObject.adjSeries(): List<Double?> {
        val adj = this["indicators"]?.jsonObject?.get("adjclose")?.jsonArray
            ?.firstOrNull()?.jsonObject?.get("adjclose") as? JsonArray
            ?: return emptyList()
        return adj.map { (it as? JsonPrimitive)?.doubleOrNull }
    }
}
