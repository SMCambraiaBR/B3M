package org.b3m.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.LocalDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.b3m.BuildConfig
import org.b3m.domain.TaxRates
import org.b3m.domain.parseBrNumber
import org.b3m.ui.Factories
import org.b3m.ui.components.AppCard
import org.b3m.ui.components.BrandHeader
import org.b3m.ui.components.SectionTitle
import org.b3m.ui.theme.AppColors

private fun pctField(rate: Double): String = TaxRates.percentText(rate).removeSuffix("%")

/** "15" ou "17,5" (em %) para fração; null se não for um número entre 0 e 100. */
private fun parseRate(text: String): Double? =
    parseBrNumber(text)?.takeIf { it in 0.0..100.0 }?.div(100.0)

@Composable
fun SettingsScreen(vm: SettingsViewModel = viewModel(factory = Factories.settings)) {
    val taxes by vm.taxes.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var dividendo by rememberSaveable(taxes) { mutableStateOf(pctField(taxes.dividendo)) }
    var jcp by rememberSaveable(taxes) { mutableStateOf(pctField(taxes.jcp)) }
    var rendimento by rememberSaveable(taxes) { mutableStateOf(pctField(taxes.rendimento)) }
    var taxError by rememberSaveable { mutableStateOf(false) }
    var brapi by rememberSaveable { mutableStateOf(vm.savedBrapiToken) }
    var hg by rememberSaveable { mutableStateOf(vm.savedHgKey) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) scope.launch {
            val text = vm.csv()
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                        ?: error("sem acesso ao arquivo")
                }
            }
            vm.report(if (ok.isSuccess) "Carteira exportada." else "Não foi possível gravar o arquivo.")
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull()
            }
            if (text == null) vm.report("Não foi possível ler o arquivo.") else vm.importCsv(text)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppColors.Background).statusBarsPadding(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { BrandHeader("Ajustes") }

        // ---- impostos ----
        item { SectionTitle("Imposto sobre proventos") }
        item {
            AppCard {
                Text(
                    "Alíquota retida em cada tipo de provento. Todo valor \"líquido\" do app (Retorno, % Retorno, " +
                        "proventos recebidos, renda mensal, desempenho) já desconta estas alíquotas.",
                    color = AppColors.Neutral, fontSize = 13.sp,
                )
                Spacer(Modifier.height(12.dp))
                RateField("Dividendos (%)", dividendo, taxError && parseRate(dividendo) == null) { dividendo = it; taxError = false }
                Text(
                    "Hoje isentos para a maioria. Desde 2026, quem recebe mais de R$ 50 mil por mês de uma mesma " +
                        "empresa tem 10% retidos (Lei 15.270/2025). O app não calcula esse limite: use 10% só se for o seu caso.",
                    color = AppColors.Neutral, fontSize = 11.sp,
                )
                Spacer(Modifier.height(10.dp))
                RateField("JCP (%)", jcp, taxError && parseRate(jcp) == null) { jcp = it; taxError = false }
                Text("Juros sobre capital próprio: 15% retidos na fonte.", color = AppColors.Neutral, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                RateField("Rendimentos de FIIs (%)", rendimento, taxError && parseRate(rendimento) == null) { rendimento = it; taxError = false }
                Text("Isentos para pessoa física, em regra.", color = AppColors.Neutral, fontSize = 11.sp)
                if (taxError) {
                    Text("Informe um número entre 0 e 100.", color = AppColors.Negative, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val d = parseRate(dividendo)
                        val j = parseRate(jcp)
                        val r = parseRate(rendimento)
                        if (d == null || j == null || r == null) taxError = true
                        else vm.saveTaxes(TaxRates(dividendo = d, jcp = j, rendimento = r))
                    }) { Text("Salvar") }
                    OutlinedButton(onClick = {
                        val d = TaxRates()
                        dividendo = pctField(d.dividendo); jcp = pctField(d.jcp); rendimento = pctField(d.rendimento)
                        taxError = false
                    }) { Text("Valores padrão") }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Informação geral, não é orientação tributária: confirme com um contador.",
                    color = AppColors.Neutral, fontSize = 11.sp,
                )
            }
        }

        // ---- chaves ----
        item { SectionTitle("Fontes de dados") }
        item {
            AppCard {
                Text(
                    "Opcionais. Com o token da brapi.dev os destaques do Mercado ficam completos; a chave da HG Brasil " +
                        "é mais uma fonte de cotação. Ficam só neste aparelho e não entram no backup do Android.",
                    color = AppColors.Neutral, fontSize = 13.sp,
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = brapi, onValueChange = { brapi = it },
                    label = { Text("Token da brapi.dev") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = hg, onValueChange = { hg = it },
                    label = { Text("Chave da HG Brasil") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = { vm.saveKeys(brapi, hg) }) { Text("Salvar chaves") }
            }
        }

        // ---- backup ----
        item { SectionTitle("Backup da carteira") }
        item {
            AppCard {
                Text(
                    "Exporta todos os seus lançamentos para um arquivo CSV (código;tipo;quantidade;preço;data) e importa de volta. " +
                        "Importar o mesmo arquivo duas vezes não duplica nada; linhas com erro são apontadas e ignoradas.",
                    color = AppColors.Neutral, fontSize = 13.sp,
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { exporter.launch("b3m-carteira-${LocalDate.now()}.csv") }) { Text("Exportar CSV") }
                    OutlinedButton(onClick = { importer.launch(arrayOf("text/*", "application/octet-stream")) }) { Text("Importar CSV") }
                }
            }
        }

        // ---- cache ----
        item { SectionTitle("Dados guardados") }
        item {
            AppCard {
                Text(
                    "O app guarda a última coleta de cada dado para mostrar, com data e hora, quando a internet falha. " +
                        "Apagar não mexe na sua carteira.",
                    color = AppColors.Neutral, fontSize = 13.sp,
                )
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = vm::clearCache) { Text("Apagar dados guardados") }
            }
        }

        // ---- sobre ----
        item { SectionTitle("Sobre") }
        item {
            AppCard {
                Text("B3M ${BuildConfig.VERSION_NAME}", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Cotações: Yahoo · brapi · B3 · HG (1ª resposta). Fundamentos/proventos: Fundamentus. CDI/IPCA: BCB. " +
                        "Dados podem atrasar ou falhar. Não é recomendação de investimento.",
                    color = AppColors.Neutral, fontSize = 12.sp,
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Vibe coding com ajuda do Grok (xAI).",
                    color = AppColors.Neutral, fontSize = 12.sp,
                )
                Text(
                    "— Grok · início do projeto",
                    color = AppColors.Brand,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Revisão técnica e correções desta versão:",
                    color = AppColors.Neutral, fontSize = 12.sp,
                )
                Text(
                    "— Manus",
                    color = AppColors.Brand,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                )
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    message?.let { msg ->
        AlertDialog(
            onDismissRequest = vm::dismissMessage,
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = vm::dismissMessage) { Text("OK") } },
        )
    }
}

@Composable
private fun RateField(label: String, value: String, isError: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(6)) },
        label = { Text(label) },
        isError = isError,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth(),
    )
}
