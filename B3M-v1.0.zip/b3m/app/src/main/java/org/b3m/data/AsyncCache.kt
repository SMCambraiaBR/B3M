package org.b3m.data

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async

/**
 * Junta chamadas idênticas que chegam ao mesmo tempo: a primeira faz o trabalho e as outras
 * esperam o mesmo resultado (uma requisição de rede em vez de várias). O trabalho roda num
 * escopo próprio, então cancelar quem pediu (ex.: fechar a tela) não derruba quem ainda espera.
 */
class InFlight<V>(
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
) {
    private val running = ConcurrentHashMap<String, Deferred<V>>()

    suspend fun run(key: String, load: suspend () -> V): V {
        val job = running.computeIfAbsent(key) { scope.async(start = CoroutineStart.LAZY) { load() } }
        job.invokeOnCompletion { running.remove(key, job) }
        return job.await()
    }
}

/** Cache em memória com validade (TTL) + [InFlight]. Falhas não ficam guardadas. */
class AsyncCache<V : Any>(
    private val ttlMs: Long,
    private val clock: () -> Long = System::currentTimeMillis,
    scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
) {
    private class Entry<V>(val at: Long, val value: V)

    private val done = ConcurrentHashMap<String, Entry<V>>()
    private val inFlight = InFlight<V>(scope)
    private val generation = AtomicLong()
    private val keyGenerations = ConcurrentHashMap<String, AtomicLong>()
    private val invalidationLock = Any()

    /** Valor guardado, se ainda estiver dentro da validade. */
    fun fresh(key: String, ttl: Long = ttlMs): V? =
        done[key]?.takeIf { clock() - it.at < ttl }?.value

    fun put(key: String, value: V) {
        synchronized(invalidationLock) {
            done[key] = Entry(clock(), value)
        }
    }

    suspend fun get(key: String, ttl: Long = ttlMs, load: suspend () -> V): V {
        fresh(key, ttl)?.let { return it }
        val cacheGeneration = generation.get()
        val keyGeneration = keyGenerations[key]?.get() ?: 0L
        val flightKey = "$cacheGeneration:$keyGeneration:$key"
        return inFlight.run(flightKey) {
            val value = load()
            synchronized(invalidationLock) {
                if (generation.get() == cacheGeneration && (keyGenerations[key]?.get() ?: 0L) == keyGeneration) {
                    done[key] = Entry(clock(), value)
                }
            }
            value
        }
    }

    fun invalidate(key: String) {
        synchronized(invalidationLock) {
            keyGenerations.computeIfAbsent(key) { AtomicLong() }.incrementAndGet()
            done.remove(key)
        }
    }

    fun invalidateAll() {
        synchronized(invalidationLock) {
            generation.incrementAndGet()
            done.clear()
        }
    }
}
