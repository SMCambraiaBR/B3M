package org.b3m.data.quotes

import java.time.LocalDate
import java.time.ZoneId
import kotlinx.serialization.Serializable
import org.b3m.domain.Quote

/**
 * Período dos gráficos (todo gráfico do app usa este seletor).
 * [range] e [interval] seguem o vocabulário de Yahoo/brapi; [trimMonths] corta
 * o excesso quando a fonte só oferece períodos fixos (ex.: 3 anos vira 5y cortado).
 */
enum class ChartRange(
    val label: String,
    val range: String,
    val interval: String,
    val trimMonths: Int? = null,
) {
    D1("1D", "1d", "1m"),
    W1("1S", "5d", "15m"),
    M1("1M", "1mo", "1d"),
    M3("3M", "3mo", "1d"),
    M6("6M", "6mo", "1d"),
    Y1("1A", "1y", "1d"),
    Y2("2A", "5y", "1wk", trimMonths = 24),
    Y3("3A", "5y", "1wk", trimMonths = 36),
    ALL("Tudo", "max", "1mo");

    /** Gráficos do dia/semana mudam o tempo todo; os longos só mudam no último ponto. */
    val isIntraday: Boolean get() = this == D1 || this == W1

    fun trim(points: List<ChartPoint>): List<ChartPoint> {
        val ordered = points.sortedBy { it.epochMillis }
        val months = trimMonths ?: return ordered
        val cutoff = LocalDate.now().minusMonths(months.toLong())
            .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        return ordered.filter { it.epochMillis >= cutoff }
    }
}

@Serializable
data class ChartPoint(
    val epochMillis: Long,
    val value: Double,
    val open: Double? = null,
    val high: Double? = null,
    val low: Double? = null,
)

/**
 * Fonte de cotações em tempo real. Separada do Fundamentus de propósito: o
 * Fundamentus é lento; cotação vem daqui. Trocar de provedor = nova implementação.
 *
 * Contrato: uma fonte que não consegue responder LANÇA erro (ou devolve lista vazia, que a
 * corrida trata como erro). Nunca devolve cotação com preço zero.
 */
interface QuoteSource {
    suspend fun quote(ticker: String): Quote
    suspend fun quotes(tickers: List<String>): List<Quote>
    suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint>

    /** Histórico OHLC solicitado somente quando o usuário escolhe candles. */
    suspend fun chartOhlc(ticker: String, range: ChartRange): List<ChartPoint> = chart(ticker, range)

    /** Descarta cotações em cache para que a próxima consulta vá à rede (usado ao abrir uma tela). */
    fun invalidateQuotes() {}
}

/** Listas da tela Mercado (busca e destaques). */
interface MarketListSource {
    suspend fun search(prefix: String): List<Quote>
    suspend fun topGainers(limit: Int = 9): List<Quote>
    suspend fun topLosers(limit: Int = 9): List<Quote>
    suspend fun mostTraded(limit: Int = 9): List<Quote>

    /** Descarta listas em cache: a próxima consulta vai à rede (usado ao abrir a tela). */
    fun invalidate() {}
}
