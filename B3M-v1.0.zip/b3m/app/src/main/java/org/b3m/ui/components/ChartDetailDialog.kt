package org.b3m.ui.components

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.ChartPoint
import kotlinx.coroutines.launch
import org.b3m.ui.theme.AppColors

/**
 * Janela ampliada do gráfico: mais altura, seletor de período e fechar.
 */
@Composable
fun ChartDetailDialog(
    title: String,
    series: List<ChartSeries>,
    range: ChartRange,
    onRange: (ChartRange) -> Unit,
    valueFormat: (Double) -> String,
    timeFormat: (Long) -> String,
    onDismiss: () -> Unit,
    zeroLine: Boolean = false,
    footnote: String? = null,
    onLoadCandles: (suspend () -> List<ChartPoint>)? = null,
) {
    val activity = LocalContext.current as? Activity
    val originalOrientation = remember { activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    var landscape by remember { mutableStateOf(false) }
    fun closeDialog() {
        activity?.requestedOrientation = originalOrientation
        onDismiss()
    }
    Dialog(
        onDismissRequest = ::closeDialog,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        var zoom by remember { mutableStateOf(1f) }
        var panX by remember { mutableStateOf(0f) }
        var panY by remember { mutableStateOf(0f) }
        var candles by remember { mutableStateOf(false) }
        var candlePoints by remember { mutableStateOf<List<ChartPoint>>(emptyList()) }
        var loadingCandles by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        LaunchedEffect(range) { candles = false; candlePoints = emptyList(); zoom = 1f; panX = 0f; panY = 0f }
        val canUseCandles = candlePoints.any { it.open != null && it.high != null && it.low != null }
        Column(
            Modifier
                .fillMaxSize()
                .background(AppColors.Card, RoundedCornerShape(16.dp))
                .padding(16.dp),
        ) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            RangeSelector(range, onRange)
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = { zoom = (zoom / 1.35f).coerceAtLeast(1f) }, enabled = zoom > 1.01f) { Text("Zoom out") }
                Text("Zoom ${"%.1f".format(zoom)}x", modifier = Modifier.weight(1f), color = AppColors.Neutral)
                TextButton(onClick = { zoom = (zoom * 1.35f).coerceAtMost(8f) }, enabled = zoom < 7.99f) { Text("Zoom in") }
                TextButton(onClick = {
                    if (canUseCandles) candles = !candles
                    else if (!loadingCandles && onLoadCandles != null) scope.launch {
                        loadingCandles = true
                        runCatching { onLoadCandles() }.onSuccess { candlePoints = it; candles = it.any { p -> p.open != null && p.high != null && p.low != null } }
                        loadingCandles = false
                    }
                }, enabled = onLoadCandles != null || canUseCandles) { Text(if (loadingCandles) "Buscando…" else if (candles) "Linha" else "Candles") }
                TextButton(onClick = {
                    landscape = !landscape
                    activity?.requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                }) { Text(if (landscape) "Retrato" else "Paisagem") }
            }
            Spacer(Modifier.height(12.dp))
            val gesture: (Float, Offset) -> Unit = { gestureZoom, pan ->
                zoom = (zoom * gestureZoom).coerceIn(1f, 8f)
                panX += pan.x
                panY += pan.y
            }
            if (candles && canUseCandles) CandleChart(candlePoints, height = 440.dp, zoom = zoom, panX = panX, panY = panY, valueFormat = valueFormat, timeFormat = timeFormat, onGesture = gesture)
            else LineChart(series, valueFormat, timeFormat, zeroLine = zeroLine, height = 440.dp, zoom = zoom, panX = panX, panY = panY, onGesture = gesture, modifier = Modifier.fillMaxWidth())
            footnote?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = AppColors.Neutral, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = ::closeDialog, modifier = Modifier.fillMaxWidth()) {
                Text("Fechar")
            }
        }
    }
}
