package org.b3m.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.b3m.data.quotes.ChartRange
import org.b3m.ui.theme.AppColors

/**
 * Janela ampliada do gráfico: mais altura, seletor de período e fechar.
 */
@Composable
fun ChartDetailDialog(
    title: String,
    series: List<ChartSeries>,
    range: ChartRange,
    onRange: (ChartRange) -> Unit,
    valueFormat: (Double) -> String,
    timeFormat: (Long) -> String,
    onDismiss: () -> Unit,
    zeroLine: Boolean = false,
    footnote: String? = null,
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.96f)
                .background(AppColors.Card, RoundedCornerShape(16.dp))
                .padding(16.dp),
        ) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            RangeSelector(range, onRange)
            Spacer(Modifier.height(12.dp))
            LineChart(
                series = series,
                valueFormat = valueFormat,
                timeFormat = timeFormat,
                zeroLine = zeroLine,
                height = 320.dp,
                modifier = Modifier.fillMaxWidth(),
            )
            footnote?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = AppColors.Neutral, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                Text("Fechar")
            }
        }
    }
}
