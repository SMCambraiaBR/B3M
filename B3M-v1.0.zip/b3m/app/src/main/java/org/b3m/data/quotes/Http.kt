package org.b3m.data.quotes

import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response

/** GET assíncrono que cancela a chamada de rede quando a coroutine é cancelada. */
suspend fun OkHttpClient.getString(url: String): String = suspendCancellableCoroutine { cont ->
    val call = newCall(
        Request.Builder()
            .url(url)
            .header(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 11; moto g(20)) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
            )
            .header("Accept", "application/json,text/plain,*/*")
            .header("Accept-Language", "pt-BR,pt;q=0.9,en;q=0.8")
            .build()
    )
    cont.invokeOnCancellation { call.cancel() }
    call.enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            response.use { r ->
                if (!r.isSuccessful) {
                    cont.resumeWithException(IOException("HTTP ${r.code}"))
                } else {
                    cont.resume(r.body!!.string())
                }
            }
        }
    })
}
