package org.b3m.data.quotes

import org.b3m.data.safely
import org.b3m.data.snapshot.Codec
import org.b3m.data.snapshot.Snapshots
import org.b3m.data.snapshot.Stamped
import org.b3m.domain.Quote

/**
 * Cotações e gráficos com a data/hora da coleta. Se a coleta nova falha, devolve o último dado
 * guardado em disco marcado como desatualizado ([Stamped.stale]) — a tela mostra quando foi.
 */
class QuoteRepository(
    private val source: QuoteSource,
    private val snapshots: Snapshots,
    private val quoteCodec: Codec<Quote>,
    private val chartCodec: Codec<List<ChartPoint>>,
) {
    private fun qKey(t: String) = "quote:${t.trim().uppercase()}"
    private fun cKey(t: String, r: ChartRange) = "chart:${t.trim().uppercase()}:${r.name}"

    /** Descarta o cache de cotações para a próxima consulta ir à rede. */
    fun invalidateQuotes() = source.invalidateQuotes()

    suspend fun quote(ticker: String): Stamped<Quote> =
        snapshots.fetch(qKey(ticker), quoteCodec, stampOf = { it.fetchedAt }) { source.quote(ticker) }

    /**
     * Uma cotação por código: nova, se a fonte respondeu; senão a última guardada (stale = true).
     * Códigos sem nenhuma cotação conhecida não aparecem no resultado. Nunca lança erro.
     */
    suspend fun quotes(tickers: List<String>): Map<String, Stamped<Quote>> {
        val keys = tickers.map { it.trim().uppercase() }.distinct()
        if (keys.isEmpty()) return emptyMap()
        val fresh = safely { source.quotes(keys) }.getOrNull().orEmpty()
            .associateBy { it.ticker.trim().uppercase() }
        val out = LinkedHashMap<String, Stamped<Quote>>()
        for (k in keys) {
            val q = fresh[k]
            if (q != null) {
                out[k] = Stamped(q, q.fetchedAt, stale = false)
                snapshots.save(qKey(k), quoteCodec, q, q.fetchedAt)
            } else {
                snapshots.lastKnown(qKey(k), quoteCodec)?.let { out[k] = it.copy(stale = true) }
            }
        }
        return out
    }

    /** Última cotação guardada de cada código (para mostrar algo na hora, antes da rede responder). */
    suspend fun lastKnownQuotes(tickers: List<String>): Map<String, Stamped<Quote>> {
        val out = LinkedHashMap<String, Stamped<Quote>>()
        for (t in tickers.map { it.trim().uppercase() }.distinct()) {
            snapshots.lastKnown(qKey(t), quoteCodec)?.let { out[t] = it }
        }
        return out
    }

    suspend fun lastKnownQuote(ticker: String): Stamped<Quote>? = snapshots.lastKnown(qKey(ticker), quoteCodec)

    suspend fun chart(ticker: String, range: ChartRange): Stamped<List<ChartPoint>> =
        snapshots.fetch(cKey(ticker, range), chartCodec) { source.chart(ticker, range) }

    suspend fun lastKnownChart(ticker: String, range: ChartRange): Stamped<List<ChartPoint>>? =
        snapshots.lastKnown(cKey(ticker, range), chartCodec)
}
