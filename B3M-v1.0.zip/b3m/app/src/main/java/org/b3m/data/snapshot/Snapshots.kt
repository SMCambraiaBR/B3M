package org.b3m.data.snapshot

import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.b3m.data.safely

/**
 * Dado com a data/hora da coleta. [stale] = true quando a coleta nova FALHOU e o que se mostra
 * é o último dado guardado: a tela avisa "sem atualização — último dado de dd/MM às HH:mm:ss".
 */
data class Stamped<T>(val value: T, val fetchedAt: Long, val stale: Boolean = false)

/** Como transformar um dado em texto (JSON) e de volta. Mantém esta camada independente do formato. */
class Codec<T>(val encode: (T) -> String, val decode: (String) -> T)

data class StoredSnapshot(val json: String, val fetchedAt: Long)

/** Onde os snapshots ficam guardados (Room no app; memória nos testes). */
interface SnapshotStore {
    suspend fun load(key: String): StoredSnapshot?
    suspend fun save(key: String, json: String, fetchedAt: Long)
    suspend fun prune(olderThan: Long)
    suspend fun clear()
}

/**
 * Última coleta bem-sucedida de cada dado, guardada em disco.
 *
 * Toda leitura de dados da internet passa por [fetch]: tenta a fonte; se der certo, guarda e
 * devolve com a hora da coleta; se falhar, devolve o último dado guardado marcado como
 * desatualizado (e só lança erro se nunca houve coleta).
 */
class Snapshots(
    private val store: SnapshotStore,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val saveLocks = ConcurrentHashMap<String, Mutex>()

    suspend fun <T> fetch(
        key: String,
        codec: Codec<T>,
        stampOf: (T) -> Long = { clock() },
        load: suspend () -> T,
    ): Stamped<T> {
        val result = safely { load() }
        if (result.isSuccess) {
            val value = result.getOrThrow()
            val at = stampOf(value)
            save(key, codec, value, at)
            return Stamped(value, at, stale = false)
        }
        val error = result.exceptionOrNull() ?: IllegalStateException("falha sem detalhes")
        val old = lastKnown(key, codec) ?: throw error
        return old.copy(stale = true)
    }

    /** Último dado guardado (sem tentar a rede), ou null. Não é marcado como desatualizado. */
    suspend fun <T> lastKnown(key: String, codec: Codec<T>): Stamped<T>? {
        val snap = safely { store.load(key) }.getOrNull() ?: return null
        val value = safely { withContext(Dispatchers.Default) { codec.decode(snap.json) } }.getOrNull() ?: return null
        return Stamped(value, snap.fetchedAt, stale = false)
    }

    suspend fun <T> save(key: String, codec: Codec<T>, value: T, at: Long = clock()) {
        safely {
            val json = withContext(Dispatchers.Default) { codec.encode(value) }
            saveLocks.computeIfAbsent(key) { Mutex() }.withLock {
                val current = store.load(key)
                if (current == null || current.fetchedAt <= at) store.save(key, json, at)
            }
        }
    }

    suspend fun prune(maxAgeMs: Long) {
        safely { store.prune(clock() - maxAgeMs) }
    }

    suspend fun clear() {
        safely { store.clear() }
    }
}

/** Implementação em memória, para testes. */
class MemorySnapshotStore : SnapshotStore {
    private val map = java.util.concurrent.ConcurrentHashMap<String, StoredSnapshot>()
    override suspend fun load(key: String): StoredSnapshot? = map[key]
    override suspend fun save(key: String, json: String, fetchedAt: Long) {
        map[key] = StoredSnapshot(json, fetchedAt)
    }
    override suspend fun prune(olderThan: Long) {
        map.entries.removeIf { it.value.fetchedAt < olderThan }
    }
    override suspend fun clear() = map.clear()
}
