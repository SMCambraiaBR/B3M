package org.b3m.data.market

import java.time.LocalDate
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.b3m.data.fundamentus.FundamentusApi
import org.b3m.data.safely

/**
 * Ranking de melhores proventos (ações ou FIIs).
 * Ações: dividendos + JCP. FIIs: rendimentos (tratados como dividendos no cálculo).
 */
class DividendRanking(
    private val fundamentus: FundamentusApi,
    private val candidates: Int = 40,
    private val minLiquidity: Double = 300_000.0,
    private val maxYield: Double = 40.0,
    private val keepMonths: Long = 14,
) : RankingSource {
    /** Padrão: só ações (como v0.9.1). */
    override suspend fun load(): List<DividendRank> = candidates(fii = false)

    suspend fun loadFiis(): List<DividendRank> = candidates(fii = true)

    suspend fun candidates(today: LocalDate = LocalDate.now(), fii: Boolean = false): List<DividendRank> =
        coroutineScope {
            val rows = fundamentus.resultado()
                .filter { row ->
                    val isFii = isFiiTicker(row.ticker)
                    val minLiq = if (fii) 50_000.0 else minLiquidity
                    (isFii == fii) &&
                        row.liquidity >= minLiq &&
                        row.dividendYield in 0.01..maxYield &&
                        row.price > 0
                }
                .sortedByDescending { it.dividendYield }
                .take(candidates)
            val gate = Semaphore(4)
            val since = today.minusMonths(keepMonths)
            rows.map { row ->
                async {
                    gate.withPermit {
                        safely {
                            val prov = fundamentus.proventos(row.ticker)
                                .filter { !it.dataPagamento.isBefore(since) }
                            DividendRank(row.ticker, row.price, row.dividendYield, prov)
                        }.getOrNull()
                    }
                }
            }.awaitAll().filterNotNull()
        }
}
