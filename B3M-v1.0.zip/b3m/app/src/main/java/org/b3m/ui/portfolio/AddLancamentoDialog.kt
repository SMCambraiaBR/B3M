package org.b3m.ui.portfolio

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.b3m.AppGraph
import org.b3m.data.safely
import org.b3m.domain.Lancamento
import org.b3m.domain.LancamentoTipo
import org.b3m.domain.LancamentoValidator
import org.b3m.domain.TickerRules
import org.b3m.ui.theme.AppColors
import org.b3m.ui.toDoubleBR

/**
 * Cadastro de compra ou venda. Confere os dados enquanto a pessoa digita e sugere códigos
 * (auto-completar) a partir da busca de mercado.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddLancamentoDialog(
    existing: List<Lancamento>,
    onDismiss: () -> Unit,
    onSubmit: (Lancamento, (String?) -> Unit) -> Unit,
    initialTicker: String = "",
    tickerEditable: Boolean = true,
) {
    var ticker by rememberSaveable { mutableStateOf(initialTicker) }
    var tipo by rememberSaveable { mutableStateOf(LancamentoTipo.COMPRA) }
    var qtd by rememberSaveable { mutableStateOf("") }
    var preco by rememberSaveable { mutableStateOf("") }
    var dataEpochDay by rememberSaveable { mutableStateOf(LocalDate.now().toEpochDay()) }
    var showPicker by rememberSaveable { mutableStateOf(false) }
    var showErrors by rememberSaveable { mutableStateOf(false) }
    var submitting by rememberSaveable { mutableStateOf(false) }
    var saveError by rememberSaveable { mutableStateOf<String?>(null) }
    var suggestions by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }

    // Auto-completar: busca com pequena espera a cada letra digitada
    LaunchedEffect(ticker) {
        if (!tickerEditable || ticker.length < 2) {
            suggestions = emptyList()
            searching = false
            return@LaunchedEffect
        }
        searching = true
        delay(250)
        val q = ticker.trim()
        val found = withContext(Dispatchers.IO) {
            safely { AppGraph.market.search(q) }.getOrNull().orEmpty()
                .map { it.ticker to (it.name ?: it.ticker) }
                .distinctBy { it.first }
                .take(8)
        }
        suggestions = found
        searching = false
    }

    val data = LocalDate.ofEpochDay(dataEpochDay)
    val qtdValue = qtd.toDoubleBR()?.takeIf { it > 0 }
    val precoValue = preco.toDoubleBR()?.takeIf { it > 0 }
    val tickerOk = TickerRules.isValid(ticker)
    val dataOk = !data.isAfter(LocalDate.now())

    val candidate = if (tickerOk && qtdValue != null && precoValue != null) {
        Lancamento(
            ticker = TickerRules.normalize(ticker),
            tipo = tipo,
            quantidade = qtdValue,
            preco = precoValue,
            data = data,
        )
    } else {
        null
    }
    val problem = candidate?.let { LancamentoValidator.validate(existing, it) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (tickerEditable) "Adicionar ativo" else "Compra ou venda de $ticker") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LancamentoTipo.entries.forEach { t ->
                        FilterChip(
                            selected = tipo == t,
                            onClick = { tipo = t; saveError = null },
                            label = { Text(if (t == LancamentoTipo.COMPRA) "Compra" else "Venda") },
                        )
                    }
                }
                OutlinedTextField(
                    value = ticker,
                    onValueChange = {
                        ticker = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6)
                        saveError = null
                    },
                    label = { Text("Código (ex.: PETR4, MXRF11)") },
                    isError = (showErrors || ticker.length >= 5) && !tickerOk,
                    enabled = tickerEditable,
                    singleLine = true,
                )
                if (searching) {
                    Text("Buscando…", color = AppColors.Neutral, fontSize = 11.sp)
                }
                // for-loop (não forEach): composable só pode ser chamado em contexto @Composable
                if (suggestions.isNotEmpty() && tickerEditable) {
                    Text("Sugestões:", color = AppColors.Neutral, fontSize = 11.sp)
                    for (pair in suggestions) {
                        val code = pair.first
                        val name = pair.second
                        Text(
                            "$code · $name",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    ticker = code
                                    suggestions = emptyList()
                                    saveError = null
                                }
                                .padding(vertical = 6.dp),
                            fontSize = 14.sp,
                        )
                    }
                }
                OutlinedTextField(
                    value = qtd,
                    onValueChange = { qtd = it; saveError = null },
                    label = { Text("Quantidade") },
                    isError = showErrors && qtdValue == null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                )
                OutlinedTextField(
                    value = preco,
                    onValueChange = { preco = it; saveError = null },
                    label = { Text("Preço por unidade (R$)") },
                    isError = showErrors && precoValue == null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                )
                OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Data: " + data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
                }
                val message = saveError
                    ?: problem
                    ?: if (showErrors && !tickerOk) "Código inválido. Exemplos: PETR4, B3SA3, BOVA11."
                    else if (showErrors && !dataOk) "A data não pode ser futura."
                    else null
                if (message != null) {
                    Text(message, color = AppColors.Negative, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !submitting,
                onClick = {
                    if (candidate != null && problem == null && dataOk) {
                        submitting = true
                        saveError = null
                        onSubmit(candidate) { error ->
                            submitting = false
                            if (error == null) onDismiss() else saveError = error
                        }
                    } else {
                        showErrors = true
                    }
                },
            ) { Text(if (submitting) "Salvando…" else "Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )

    if (showPicker) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = data.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let {
                        dataEpochDay = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toEpochDay()
                    }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Cancelar") } },
        ) { DatePicker(state = state) }
    }
}
