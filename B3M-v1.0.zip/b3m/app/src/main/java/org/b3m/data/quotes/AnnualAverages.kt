package org.b3m.data.quotes

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class AnnualAverage(val year: Int, val value: Double?)

/** Médias de fechamento por ano-calendário, do ano atual aos dez anos anteriores. */
fun annualAverages(
    points: List<ChartPoint>,
    today: LocalDate = LocalDate.now(),
    zone: ZoneId = ZoneId.systemDefault(),
): List<AnnualAverage> {
    val valid = points.asSequence()
        .filter { it.value.isFinite() && it.value > 0.0 }
        .map { Instant.ofEpochMilli(it.epochMillis).atZone(zone).toLocalDate().year to it.value }
        .groupBy({ it.first }, { it.second })
    return (today.year downTo today.year - 10).map { year ->
        AnnualAverage(year, valid[year]?.average()?.takeIf { it.isFinite() })
    }
}
