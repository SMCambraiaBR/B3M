package org.b3m.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.b3m.data.quotes.ChartPoint
import org.b3m.ui.theme.AppColors

@Composable
fun CandleChart(
    points: List<ChartPoint>,
    modifier: Modifier = Modifier,
    height: androidx.compose.ui.unit.Dp = 320.dp,
    zoom: Float = 1f,
    panX: Float = 0f,
    panY: Float = 0f,
    valueFormat: (Double) -> String = { "%.2f".format(it) },
    timeFormat: (Long) -> String = { it.toString() },
    onGesture: ((Float, Offset) -> Unit)? = null,
) {
    val candles = points.filter { it.open != null && it.high != null && it.low != null && it.value.isFinite() }
    if (candles.isEmpty()) {
        LineChart(listOf(ChartSeries("Preço", points, AppColors.Neutral)), valueFormat, timeFormat, modifier, height = height, zoom = zoom, panX = panX, panY = panY, onGesture = onGesture)
        return
    }
    var touchX by remember { mutableStateOf<Float?>(null) }
    val measurer = rememberTextMeasurer()
    val labelStyle = TextStyle(color = AppColors.Neutral, fontSize = 10.sp)
    val tipStyle = TextStyle(color = Color.White, fontSize = 12.sp)
    Canvas(
        modifier.fillMaxWidth().height(height).pointerInput(onGesture) {
            if (onGesture != null) {
                detectTransformGestures { centroid, pan, gestureZoom, _ ->
                    touchX = centroid.x
                    onGesture(gestureZoom, pan)
                }
            }
        },
    ) {
        val left = 54.dp.toPx(); val right = 8.dp.toPx(); val top = 8.dp.toPx(); val bottom = 20.dp.toPx()
        val plotW = size.width - left - right
        val min = candles.minOf { it.low!! }; val max = candles.maxOf { it.high!! }
        val center = (min + max) / 2.0; val span = ((max - min) / zoom.coerceIn(1f, 8f)).coerceAtLeast(0.000001)
        val lo = center - span / 2; val hi = center + span / 2
        fun y(v: Double) = (top + (size.height - top - bottom) * (1 - (v - lo) / (hi - lo))).toFloat() + panY
        val step = plotW / candles.size
        val body = (step * 0.62f).coerceAtLeast(1f)
        for (i in 0..4) {
            val value = hi - (hi - lo) * i / 4.0
            val yy = y(value)
            drawLine(Color(0x22FFFFFF), Offset(left, yy), Offset(size.width - right, yy), strokeWidth = 1f)
            val layout = measurer.measure(valueFormat(value), labelStyle)
            drawText(layout, topLeft = Offset((size.width - right - layout.size.width).coerceAtLeast(left), (yy - layout.size.height / 2f).coerceIn(0f, size.height - layout.size.height)))
        }
        candles.forEachIndexed { i, p ->
            val x = left + plotW / 2f + (step * (i + 0.5f) - plotW / 2f) * zoom.coerceIn(1f, 8f) + panX
            val open = p.open!!; val close = p.value; val up = close >= open
            val color = if (up) Color(0xFF35C979) else Color(0xFFE85D75)
            drawLine(color, Offset(x, y(p.low!!)), Offset(x, y(p.high!!)), strokeWidth = 1.5f, cap = StrokeCap.Round)
            val topBody = y(maxOf(open, close)); val bottomBody = y(minOf(open, close))
            drawRect(color, Offset(x - body / 2, topBody), Size(body, (bottomBody - topBody).coerceAtLeast(2f)))
        }
        touchX?.let { rawX ->
            val cx = rawX.coerceIn(left, (size.width - right).coerceAtLeast(left))
            val localX = ((cx - left - plotW / 2f - panX) / zoom.coerceIn(1f, 8f) + plotW / 2f)
            val index = ((localX / step).toInt()).coerceIn(0, candles.lastIndex)
            val p = candles[index]
            val x = left + plotW / 2f + (step * (index + 0.5f) - plotW / 2f) * zoom.coerceIn(1f, 8f) + panX
            drawLine(Color.White, Offset(x, top), Offset(x, size.height - bottom), strokeWidth = 1.5f)
            val lines = listOf(
                timeFormat(p.epochMillis),
                "Abertura: ${valueFormat(p.open!!)}",
                "Máxima: ${valueFormat(p.high!!)}",
                "Mínima: ${valueFormat(p.low!!)}",
                "Fechamento: ${valueFormat(p.value)}",
            )
            val layout = measurer.measure(lines.joinToString("\n"), tipStyle)
            val pad = 6.dp.toPx()
            val boxW = layout.size.width + pad * 2
            val boxH = layout.size.height + pad * 2
            val bx = (x - boxW / 2).coerceIn(left, (size.width - boxW).coerceAtLeast(left))
            drawRoundRect(AppColors.CardAlt, Offset(bx, top), Size(boxW, boxH), CornerRadius(8.dp.toPx()))
            drawText(layout, topLeft = Offset(bx + pad, top + pad))
        }
    }
}
