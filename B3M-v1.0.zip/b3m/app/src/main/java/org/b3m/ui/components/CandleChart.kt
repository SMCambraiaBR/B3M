package org.b3m.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import org.b3m.data.quotes.ChartPoint
import org.b3m.ui.theme.AppColors

@Composable
fun CandleChart(points: List<ChartPoint>, modifier: Modifier = Modifier, height: androidx.compose.ui.unit.Dp = 320.dp, zoom: Float = 1f) {
    val candles = points.filter { it.open != null && it.high != null && it.low != null && it.value.isFinite() }
    if (candles.isEmpty()) {
        LineChart(listOf(ChartSeries("Preço", points, AppColors.Neutral)), { "%.2f".format(it) }, { "" }, modifier, height = height, zoom = zoom)
        return
    }
    Canvas(modifier.fillMaxWidth().height(height)) {
        val left = 8.dp.toPx(); val right = 8.dp.toPx(); val top = 8.dp.toPx(); val bottom = 8.dp.toPx()
        val min = candles.minOf { it.low!! }; val max = candles.maxOf { it.high!! }
        val center = (min + max) / 2.0; val span = ((max - min) / zoom.coerceIn(1f, 8f)).coerceAtLeast(0.000001)
        val lo = center - span / 2; val hi = center + span / 2
        fun y(v: Double) = (top + (size.height - top - bottom) * (1 - (v - lo) / (hi - lo))).toFloat()
        val step = (size.width - left - right) / candles.size
        val body = (step * 0.62f).coerceAtLeast(1f)
        candles.forEachIndexed { i, p ->
            val x = left + step * (i + 0.5f)
            val open = p.open!!; val close = p.value; val up = close >= open
            val color = if (up) Color(0xFF35C979) else Color(0xFFE85D75)
            drawLine(color, androidx.compose.ui.geometry.Offset(x, y(p.low!!)), androidx.compose.ui.geometry.Offset(x, y(p.high!!)), strokeWidth = 1.5f, cap = StrokeCap.Round)
            val topBody = y(maxOf(open, close)); val bottomBody = y(minOf(open, close))
            drawRect(color, androidx.compose.ui.geometry.Offset(x - body / 2, topBody), androidx.compose.ui.geometry.Size(body, (bottomBody - topBody).coerceAtLeast(2f)))
        }
    }
}
