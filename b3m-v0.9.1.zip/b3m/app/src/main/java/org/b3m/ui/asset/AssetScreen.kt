package org.b3m.ui.asset

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.format.DateTimeFormatter
import org.b3m.data.fundamentus.Indicador
import org.b3m.data.quotes.ChartRange
import org.b3m.domain.ReturnCalculator
import org.b3m.domain.TaxRates
import org.b3m.domain.label
import org.b3m.ui.Factories
import org.b3m.ui.arrowPct
import org.b3m.ui.brl
import org.b3m.ui.compact
import org.b3m.ui.components.AppCard
import org.b3m.ui.components.ChartSeries
import org.b3m.ui.components.ChipRow
import org.b3m.ui.components.CompanyLogo
import org.b3m.ui.components.ErrorLine
import org.b3m.ui.components.InfoRow
import org.b3m.ui.components.ChartDetailDialog
import org.b3m.ui.components.LineChart
import org.b3m.ui.components.RangeSelector
import org.b3m.ui.components.SectionTitle
import org.b3m.ui.components.StatGrid
import org.b3m.ui.components.TaxNote
import org.b3m.ui.components.UpdatedLine
import org.b3m.ui.components.WarningLine
import org.b3m.ui.components.trendColor
import org.b3m.ui.num
import org.b3m.ui.pct
import org.b3m.ui.portfolio.AddLancamentoDialog
import org.b3m.ui.prettyValue
import org.b3m.ui.qty
import org.b3m.ui.signedBrl
import org.b3m.ui.signedPct
import org.b3m.ui.theme.AppColors
import org.b3m.ui.timeFormatter

private enum class AssetTab(val label: String) { COTACAO("Cotação"), POSICAO("Posição") }

private val dateFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")

@Composable
fun AssetScreen(ticker: String, onBack: () -> Unit) {
    val vm: AssetViewModel = viewModel(key = "asset-$ticker", factory = Factories.asset(ticker))
    val ui by vm.ui.collectAsStateWithLifecycle()
    var showFull by rememberSaveable(ticker) { mutableStateOf(false) }
    var showAdd by rememberSaveable(ticker) { mutableStateOf(false) }
    var tab by rememberSaveable(ticker) { mutableStateOf(AssetTab.COTACAO) }

    // Só consulta a internet enquanto a tela está à vista; ao voltar, busca tudo de novo.
    LifecycleStartEffect(vm) {
        vm.start()
        onStopOrDispose { vm.stop() }
    }

    BackHandler(showFull) { showFull = false }

    if (showFull) {
        FullDataScreen(ui, onBack = { showFull = false }, onRetry = vm::refresh)
        return
    }

    val tabs = if (ui.position != null) AssetTab.entries else listOf(AssetTab.COTACAO)
    val currentTab = if (tab in tabs) tab else AssetTab.COTACAO

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppColors.Background).statusBarsPadding(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar") }
                CompanyLogo(ticker, size = 48.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(ticker, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    val empresa = ui.detalhes.data?.empresa
                    if (!empresa.isNullOrBlank()) Text(empresa, fontSize = 14.sp, maxLines = 1)
                    val sub = listOfNotNull(ui.detalhes.data?.setor, ui.detalhes.data?.subsetor).distinct().joinToString(" · ")
                    if (sub.isNotBlank()) Text(sub, color = AppColors.Neutral, fontSize = 12.sp, maxLines = 1)
                }
                IconButton(onClick = vm::refresh) { Icon(Icons.Default.Refresh, contentDescription = "Atualizar") }
                IconButton(onClick = vm::toggleFavorite) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = if (ui.favorite) "Remover dos favoritos" else "Adicionar aos favoritos",
                        tint = if (ui.favorite) AppColors.Warning else AppColors.Neutral,
                    )
                }
            }
        }

        if (tabs.size > 1) {
            item { ChipRow(tabs, currentTab, { it.label }, { tab = it }) }
        }

        if (currentTab == AssetTab.POSICAO) {
            ui.position?.let { p -> item { PositionBlock(p, ui) } }
            item {
                Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Registrar compra ou venda")
                }
            }
        } else {
            item { QuoteHeader(ui, vm) }
            item { ChartBlock(ui, vm) }
            item { SummaryBlock(ui, vm) }
            item { IndicatorsBlock(ui, vm) }
            item {
                Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (ui.position == null) "Adicionar à carteira" else "Registrar compra ou venda")
                }
            }
            item {
                OutlinedButton(onClick = { showFull = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Dados completos")
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showAdd) {
        AddLancamentoDialog(
            initialTicker = ticker,
            tickerEditable = false,
            existing = ui.lancamentos,
            onDismiss = { showAdd = false },
            onSubmit = { l, done -> vm.addLancamento(l, done) },
        )
    }
}

@Composable
private fun QuoteHeader(ui: AssetUi, vm: AssetViewModel) {
    val q = ui.quote.data
    if (q == null) {
        if (ui.quote.loading) CircularProgressIndicator(Modifier.height(28.dp))
        ui.quote.error?.let { ErrorLine(it, vm::refresh) }
        return
    }
    val color = AppColors.forChange(q.changePct)
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Text(q.price.brl(), fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Column(horizontalAlignment = Alignment.End) {
                Text(q.changePct.arrowPct(), color = color, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                q.previousClose?.let { Text((q.price - it).signedBrl(), color = color, fontSize = 13.sp) }
            }
        }
        UpdatedLine(ui.quote.updatedAt, ui.quote.stale, Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun ChartBlock(ui: AssetUi, vm: AssetViewModel) {
    val points = ui.chart.data.orEmpty()
    val quote = ui.quote.data
    val color = if (ui.range == ChartRange.D1 && quote != null) AppColors.forChange(quote.changePct) else trendColor(points)
    val series = listOf(ChartSeries(ui.ticker, points, color, fill = true))
    var expanded by remember { mutableStateOf(false) }
    Column {
        if (ui.chart.loading && points.isEmpty()) CircularProgressIndicator(Modifier.height(28.dp))
        ui.chart.error?.let { ErrorLine(it, vm::refresh) }
        Column(Modifier.clickable(enabled = points.isNotEmpty()) { expanded = true }) {
            LineChart(
                series = series,
                valueFormat = { it.brl() },
                timeFormat = timeFormatter(ui.range),
            )
            if (points.isNotEmpty()) {
                Text("Toque para ampliar", color = AppColors.Neutral, fontSize = 11.sp)
            }
        }
        UpdatedLine(ui.chart.updatedAt, ui.chart.stale, onlyWhenStale = true)
        Spacer(Modifier.height(8.dp))
        RangeSelector(ui.range, vm::selectRange)
    }
    if (expanded) {
        ChartDetailDialog(
            title = "${ui.ticker} · cotação",
            series = series,
            range = ui.range,
            onRange = vm::selectRange,
            valueFormat = { it.brl() },
            timeFormat = timeFormatter(ui.range),
            onDismiss = { expanded = false },
        )
    }
}

@Composable
private fun SummaryBlock(ui: AssetUi, vm: AssetViewModel) {
    val q = ui.quote.data
    val dash = "—"
    val dayChange = if (q?.previousClose != null) q.price - q.previousClose else null
    val items = listOf(
        "Fech. anterior" to (q?.previousClose?.brl() ?: dash),
        "Abertura" to (q?.open?.brl() ?: dash),
        "Máxima" to (q?.high?.brl() ?: dash),
        "Mínima" to (q?.low?.brl() ?: dash),
        "Volume" to (q?.volume?.compact() ?: dash),
        "Variação do dia" to (dayChange?.signedBrl() ?: dash),
        "Retorno/mês" to (ui.retorno?.retorno?.brl() ?: dash),
        "% Retorno" to (ui.retorno?.percentRetorno?.pct() ?: dash),
    )
    val colors = buildMap<String, Color> {
        dayChange?.let { put("Variação do dia", AppColors.forChange(it)) }
        ui.retorno?.let {
            put("Retorno/mês", AppColors.forChange(it.retorno))
            put("% Retorno", AppColors.forChange(it.percentRetorno))
        }
    }
    Column {
        SectionTitle("Resumo")
        Spacer(Modifier.height(6.dp))
        StatGrid(items, colors)
        Spacer(Modifier.height(6.dp))
        Text(
            "Retorno = Σ prov. 12m ÷ 12 · %Ret = Retorno ÷ P · " +
                "Valores líquidos, com o imposto já descontado.",
            color = AppColors.Neutral, fontSize = 12.sp,
        )
        TaxNote(ui.taxes, Modifier.padding(top = 2.dp))
        if (ui.proventos.data == null) {
            if (ui.proventos.loading) Text("Carregando proventos…", color = AppColors.Neutral, fontSize = 12.sp)
            ui.proventos.error?.let { ErrorLine("$it Tentando de novo.", vm::refresh) }
        }
        UpdatedLine(ui.proventos.updatedAt, ui.proventos.stale, onlyWhenStale = true)
    }
}

@Composable
private fun IndicatorsBlock(ui: AssetUi, vm: AssetViewModel) {
    var open by rememberSaveable(ui.ticker) { mutableStateOf<String?>(null) }
    Column {
        SectionTitle("Indicadores")
        Text("Toque em um indicador para ver o que ele significa.", color = AppColors.Neutral, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        val list = ui.indicadores
        if (ui.detalhes.loading && list.isEmpty()) CircularProgressIndicator(Modifier.height(28.dp))
        ui.detalhes.error?.let { ErrorLine(it, vm::refresh) }
        list.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { (ind, value) ->
                    IndicatorTile(ind, value, expanded = open == ind.short, Modifier.weight(1f)) {
                        open = if (open == ind.short) null else ind.short
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        UpdatedLine(ui.detalhes.updatedAt, ui.detalhes.stale)
    }
}

@Composable
private fun IndicatorTile(ind: Indicador, value: String, expanded: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .background(AppColors.CardAlt, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(ind.short, color = AppColors.Neutral)
            Text(prettyValue(value), fontWeight = FontWeight.Bold)
        }
        Text(ind.name, color = AppColors.Neutral, fontSize = 11.sp, maxLines = if (expanded) 3 else 1)
        if (expanded) Text(ind.hint, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun PositionBlock(p: PositionInfo, ui: AssetUi) {
    val ready = ui.proventos.data != null
    val dash = "—"
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AppCard {
            if (p.price == null) {
                WarningLine("Sem cotação agora: usando o preço médio.")
            } else {
                UpdatedLine(ui.quote.updatedAt, p.priceStale)
            }
            InfoRow("Valor atual", p.value.brl())
            InfoRow("Valor investido", p.invested.brl())
            InfoRow("Quantidade", p.position.quantity.qty())
            InfoRow("Preço médio", p.position.averagePrice.brl())
            InfoRow(
                "Resultado das cotações",
                "${p.result.signedBrl()} (${p.resultPct.signedPct()})",
                AppColors.forChange(p.result),
            )
            InfoRow(
                "Proventos recebidos",
                if (ready) p.dividendsNet.brl() else dash,
                if (ready && p.dividendsNet > 0) AppColors.Positive else Color.White,
                note = "Líquidos: imposto já descontado (${ui.taxes.summary()})",
            )
            if (ready && p.taxPaid > 0) {
                InfoRow("Imposto retido nos proventos", p.taxPaid.brl(), note = "Já descontado do valor acima")
            }
            InfoRow(
                "Resultado total",
                if (ready) "${p.totalResult.signedBrl()} (${p.totalResultPct.signedPct()})" else dash,
                if (ready) AppColors.forChange(p.totalResult) else Color.White,
                note = "Cotações + proventos líquidos",
            )
            InfoRow("Gasto real", if (ready) p.realCost.brl() else dash, note = "Investido menos proventos recebidos")
        }
        if (!ready) {
            if (ui.proventos.loading) Text("Carregando proventos…", color = AppColors.Neutral, fontSize = 12.sp)
            ui.proventos.error?.let { WarningLine("$it Tentando de novo.") }
        }
        UpdatedLine(ui.proventos.updatedAt, ui.proventos.stale, onlyWhenStale = true)
        TaxNote(ui.taxes)
    }
}

/** "Dados completos": tudo o que o Fundamentus mostra, por seção, mais a aba de proventos. */
@Composable
private fun FullDataScreen(ui: AssetUi, onBack: () -> Unit, onRetry: () -> Unit) {
    val sections = ui.detalhes.data?.sections.orEmpty()
    val proventosTab = "Proventos"
    val tabs = sections.map { it.title } + proventosTab
    var selected by rememberSaveable(ui.ticker) { mutableStateOf(proventosTab) }
    val current = if (selected in tabs) selected else tabs.first()

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppColors.Background).statusBarsPadding(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar") }
                Text("${ui.ticker} · Dados completos", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
        ui.detalhes.error?.let { msg -> item { ErrorLine(msg, onRetry) } }
        item { ChipRow(tabs, current, { it }, { selected = it }) }

        if (current == proventosTab) {
            item { ProventosHeader(ui) }
            ui.proventos.error?.let { msg -> item { ErrorLine(msg, onRetry) } }
            item { UpdatedLine(ui.proventos.updatedAt, ui.proventos.stale) }
            val list = ui.proventos.data?.sortedByDescending { it.dataPagamento }
            if (list == null) {
                if (ui.proventos.loading) item { CircularProgressIndicator(Modifier.height(28.dp)) }
            } else if (list.isEmpty()) {
                item { Text("Sem proventos registrados.", color = AppColors.Neutral) }
            } else {
                // sem chave: dois proventos idênticos (mesma data, tipo e valor) derrubariam a lista por chave repetida
                items(list) { p ->
                    val rate = ui.taxes.forTipo(p.tipo)
                    AppCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(p.tipo.label(), fontWeight = FontWeight.Bold)
                                Text(
                                    "Pago em ${p.dataPagamento.format(dateFmt)}" +
                                        (p.dataCom?.let { " · Data com ${it.format(dateFmt)}" } ?: ""),
                                    color = AppColors.Neutral, fontSize = 12.sp,
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(p.valorBruto.num(4) + " bruto", fontWeight = FontWeight.Medium)
                                Text(
                                    ReturnCalculator.net(p, ui.taxes).num(4) + " líquido",
                                    color = AppColors.Positive, fontSize = 13.sp,
                                )
                            }
                        }
                        Text(
                            if (rate > 0) "Imposto de ${TaxRates.percentText(rate)} já descontado no valor líquido"
                            else "Sem imposto (alíquota 0%): líquido igual ao bruto",
                            color = AppColors.Neutral, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }
            }
        } else {
            item { UpdatedLine(ui.detalhes.updatedAt, ui.detalhes.stale) }
            val rows = sections.firstOrNull { it.title == current }?.items.orEmpty()
            item {
                AppCard {
                    rows.forEach { (label, value) -> InfoRow(label, prettyValue(value)) }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun ProventosHeader(ui: AssetUi) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ui.retorno?.let { r ->
            AppCard {
                InfoRow("Retorno por mês (por ação)", r.retorno.brl(), AppColors.forChange(r.retorno))
                InfoRow("% Retorno", r.percentRetorno.pct(), AppColors.forChange(r.percentRetorno))
                Text(
                    "Proventos líquidos dos últimos 12 meses ÷ 12.",
                    color = AppColors.Neutral, fontSize = 12.sp,
                )
            }
        }
        Text("Valores por ação.", color = AppColors.Neutral, fontSize = 12.sp)
        TaxNote(ui.taxes)
    }
}
