# Keep Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Keep Kotlin Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class org.b3m.**$$serializer { *; }
-keepclassmembers class org.b3m.** { *** Companion; }
-keepclasseswithmembers class org.b3m.** { kotlinx.serialization.KSerializer serializer(...); }

# OkHttp / Jsoup
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.jsoup.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# Keep data classes
-keep class org.b3m.domain.** { *; }
-keep class org.b3m.data.** { *; }
