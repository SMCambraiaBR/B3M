# Regras do R8 para o build release (isMinifyEnabled = true). Não testado em aparelho.

# kotlinx.serialization: as classes @Serializable do app são gravadas em disco como JSON (snapshots).
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class org.b3m.** {
    *** Companion;
}
-keepclasseswithmembers class org.b3m.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class org.b3m.**$$serializer { *; }

# Jsoup referencia anotações que não vêm no APK.
-dontwarn org.jspecify.annotations.**

# OkHttp: provedores de TLS opcionais.
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
