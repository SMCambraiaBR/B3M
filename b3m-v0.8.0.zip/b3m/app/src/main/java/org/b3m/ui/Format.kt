package org.b3m.ui

import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.b3m.data.quotes.ChartRange
import org.b3m.domain.parseBrNumber

private val ptBR = Locale("pt", "BR")

fun Double.brl(): String = NumberFormat.getCurrencyInstance(ptBR).format(this)

fun Double.pct(): String = String.format(ptBR, "%.2f%%", this)

fun Double.num(decimals: Int = 2): String = String.format(ptBR, "%,.${decimals}f", this)

/** "+R$ 1,00" / "-R$ 1,00", para variações. */
fun Double.signedBrl(): String =
    (if (this > 0) "+" else if (this < 0) "-" else "") + kotlin.math.abs(this).brl()

fun Double.signedPct(): String = (if (this > 0) "+" else "") + pct()

/** "▲ 1,23%" / "▼ 1,23%": a seta reforça a cor (verde/vermelho) para quem não distingue as cores. */
fun Double.arrowPct(): String = when {
    this > 0 -> "▲ " + pct()
    this < 0 -> "▼ " + kotlin.math.abs(this).pct()
    else -> pct()
}

fun Double.qty(): String =
    if (this % 1.0 == 0.0) this.toLong().toString()
    else String.format(ptBR, "%.4f", this).trimEnd('0').trimEnd(',')

/** Volumes grandes em forma curta: 4,29B / 80,59M / 12,3K. */
fun Double.compact(): String = when {
    this >= 1e9 -> String.format(ptBR, "%.2fB", this / 1e9)
    this >= 1e6 -> String.format(ptBR, "%.2fM", this / 1e6)
    this >= 1e3 -> String.format(ptBR, "%.1fK", this / 1e3)
    else -> String.format(ptBR, "%.0f", this)
}

/** Aceita "1.234,56", "1234.56" e "1.000" (milhar). Veja [parseBrNumber]. */
fun String.toDoubleBR(): Double? = parseBrNumber(this)

private val bigInt = Regex("^-?\\d{1,3}(\\.\\d{3})+$")

/**
 * Números inteiros enormes do Fundamentus ("489.435.000.000") ficam legíveis ("489,44 bi").
 * Qualquer outro texto (percentuais, datas, valores pequenos) passa sem mudança.
 */
fun prettyValue(raw: String): String {
    val s = raw.trim()
    if (!bigInt.matches(s)) return raw
    val v = s.replace(".", "").toDoubleOrNull() ?: return raw
    val a = kotlin.math.abs(v)
    return when {
        a >= 1e12 -> String.format(ptBR, "%.2f tri", v / 1e12)
        a >= 1e9 -> String.format(ptBR, "%.2f bi", v / 1e9)
        a >= 1e6 -> String.format(ptBR, "%.2f mi", v / 1e6)
        else -> raw
    }
}

private val hourFmt = DateTimeFormatter.ofPattern("HH:mm", ptBR)
private val dayHourFmt = DateTimeFormatter.ofPattern("dd/MM HH:mm", ptBR)
private val dayFmt = DateTimeFormatter.ofPattern("dd/MM/yy", ptBR)
private val clockFmt = DateTimeFormatter.ofPattern("HH:mm:ss", ptBR)
private val fullDayFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy", ptBR)

/**
 * Momento da coleta de um dado, para a frase "Atualizado ...": "hoje às 14:32:10",
 * "ontem às 18:05:44" ou "em 27/10/2026 às 09:01:12".
 */
fun formatCollected(
    fetchedAt: Long,
    now: Long = System.currentTimeMillis(),
    zone: ZoneId = ZoneId.systemDefault(),
): String {
    val at = Instant.ofEpochMilli(fetchedAt).atZone(zone)
    val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    val time = clockFmt.format(at)
    return when (at.toLocalDate()) {
        today -> "hoje às $time"
        today.minusDays(1) -> "ontem às $time"
        else -> "em ${fullDayFmt.format(at)} às $time"
    }
}

/** Formato do rótulo de tempo conforme o período do gráfico. */
fun timeFormatter(range: ChartRange): (Long) -> String {
    val fmt = when (range) {
        ChartRange.D1 -> hourFmt
        ChartRange.W1 -> dayHourFmt
        else -> dayFmt
    }
    return { ms -> fmt.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())) }
}
