package org.b3m.data

import kotlinx.coroutines.CancellationException

/**
 * Como runCatching, mas deixa o cancelamento da coroutine passar. Com runCatching, uma
 * chamada cancelada (ex.: o usuário trocou o período do gráfico) cairia no onFailure e
 * poderia sobrescrever o estado novo com uma mensagem de erro antiga.
 */
inline fun <T> safely(block: () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Throwable) {
    Result.failure(e)
}
