package org.b3m.domain

import java.time.LocalDate

enum class LancamentoTipo { COMPRA, VENDA }

/** Uma operação cadastrada manualmente pelo usuário. */
data class Lancamento(
    val id: Long = 0,
    val ticker: String,
    val tipo: LancamentoTipo,
    val quantidade: Double,
    val preco: Double,
    val data: LocalDate,
)

object PositionCalculator {

    /**
     * Posição atual por ativo a partir dos lançamentos, em ordem cronológica.
     * Compra: preço médio ponderado. Venda: reduz a quantidade e mantém o preço
     * médio (regra usada no Brasil). Posição zerada some da lista.
     */
    fun calculate(lancamentos: List<Lancamento>): List<Position> =
        lancamentos.groupBy { it.ticker.uppercase() }.mapNotNull { (ticker, list) ->
            var qty = 0.0
            var avg = 0.0
            list.sortedWith(compareBy({ it.data }, { it.id })).forEach { l ->
                when (l.tipo) {
                    LancamentoTipo.COMPRA -> {
                        val total = qty * avg + l.quantidade * l.preco
                        qty += l.quantidade
                        avg = if (qty > 0) total / qty else 0.0
                    }
                    LancamentoTipo.VENDA -> {
                        qty -= l.quantidade
                        if (qty < QTY_EPS) {
                            qty = 0.0
                            avg = 0.0
                        }
                    }
                }
            }
            if (qty > QTY_EPS) Position(ticker, qty, avg) else null
        }.sortedBy { it.ticker }
}
