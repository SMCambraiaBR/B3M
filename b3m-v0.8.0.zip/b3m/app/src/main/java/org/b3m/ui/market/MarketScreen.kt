package org.b3m.ui.market

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import org.b3m.data.market.DividendSort
import org.b3m.data.market.rankedBy
import org.b3m.ui.Factories
import org.b3m.ui.arrowPct
import org.b3m.ui.brl
import org.b3m.ui.components.AppCard
import org.b3m.ui.components.ChartSeries
import org.b3m.ui.components.ChipRow
import org.b3m.ui.components.CompanyLogo
import org.b3m.ui.components.ErrorLine
import org.b3m.ui.components.LineChart
import org.b3m.ui.components.QuoteRow
import org.b3m.ui.components.RangeSelector
import org.b3m.ui.components.SectionTitle
import org.b3m.ui.components.TaxNote
import org.b3m.ui.components.UpdatedLine
import org.b3m.ui.components.trendColor
import org.b3m.ui.num
import org.b3m.ui.pct
import org.b3m.ui.theme.AppColors
import org.b3m.data.quotes.ChartRange
import org.b3m.ui.timeFormatter

@Composable
fun MarketScreen(
    onOpen: (String) -> Unit,
    vm: MarketViewModel = viewModel(factory = Factories.market),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val searching = ui.query.isNotBlank()

    // Só consulta a internet enquanto a tela está à vista; ao voltar, busca tudo de novo.
    LifecycleStartEffect(vm) {
        vm.start()
        onStopOrDispose { vm.stop() }
    }

    val ranked = remember(ui.dividends.data, ui.dividendSort, ui.taxes) {
        ui.dividends.data.orEmpty().rankedBy(ui.dividendSort, ui.taxes).distinctBy { it.ticker }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppColors.Background).statusBarsPadding(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Mercado", fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = vm::refresh) { Icon(Icons.Default.Refresh, contentDescription = "Atualizar") }
            }
        }

        item {
            OutlinedTextField(
                value = ui.query,
                onValueChange = vm::onQuery,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar ativos (ex.: PETR, VALE)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searching) IconButton(onClick = { vm.onQuery("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Limpar")
                    }
                },
                singleLine = true,
            )
        }

        if (searching) {
            if (ui.results.loading) item { CircularProgressIndicator(Modifier.height(28.dp)) }
            ui.results.error?.let { msg -> item { ErrorLine(msg) } }
            val list = ui.results.data.orEmpty().distinctBy { it.ticker }
            if (list.isEmpty() && !ui.results.loading && ui.results.error == null) {
                item { Text("Nenhum ativo encontrado.", color = AppColors.Neutral) }
            }
            items(list, key = { it.ticker }) { q ->
                QuoteRow(q.ticker, q.name, q.price, q.changePct) { onOpen(q.ticker) }
            }
            return@LazyColumn
        }

        // Índices
        item { SectionTitle("Índices") }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CompanyLogo("IBOV")
                    Column(Modifier.padding(start = 12.dp)) {
                        Text("IBOV", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Ibovespa", color = AppColors.Neutral, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                val ibov = ui.ibov.data
                if (ibov != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        Text("${ibov.price.num(0)} pts", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text(ibov.changePct.arrowPct(), color = AppColors.forChange(ibov.changePct), fontWeight = FontWeight.Medium)
                    }
                } else if (ui.ibov.loading) {
                    CircularProgressIndicator(Modifier.height(28.dp))
                }
                ui.ibov.error?.let { ErrorLine(it, vm::refresh) }
                UpdatedLine(ui.ibov.updatedAt, ui.ibov.stale)
                val points = ui.ibovChart.data.orEmpty()
                // No gráfico do dia a cor segue a variação do dia; nos demais, início x fim do período.
                val color = if (ui.ibovRange == ChartRange.D1 && ibov != null) AppColors.forChange(ibov.changePct) else trendColor(points)
                Spacer(Modifier.height(6.dp))
                LineChart(
                    series = listOf(ChartSeries("IBOV", points, color, fill = true)),
                    valueFormat = { it.num(0) },
                    timeFormat = timeFormatter(ui.ibovRange),
                    height = 160.dp,
                )
                ui.ibovChart.error?.let { ErrorLine(it, vm::refresh) }
                UpdatedLine(ui.ibovChart.updatedAt, ui.ibovChart.stale, onlyWhenStale = true)
                Spacer(Modifier.height(8.dp))
                RangeSelector(ui.ibovRange, vm::selectIbovRange)
            }
        }

        // Favoritos
        if (ui.favorites.isNotEmpty()) {
            item { SectionTitle("Favoritos") }
            items(ui.favorites.distinctBy { it.ticker }, key = { "f-" + it.ticker }) { f ->
                val q = f.quote
                if (q != null) {
                    QuoteRow(q.ticker, q.name, q.price, q.changePct) { onOpen(f.ticker) }
                } else {
                    AppCard(onClick = { onOpen(f.ticker) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CompanyLogo(f.ticker)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(f.ticker, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("Sem cotação agora", color = AppColors.Warning, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
            item { UpdatedLine(ui.favoritesAt, ui.favoritesStale) }
        }

        // Destaques
        item { SectionTitle("Destaques") }
        item {
            ChipRow(Highlight.entries, ui.highlight, { it.label }, vm::selectHighlight)
        }
        val sec = ui.highlights[ui.highlight]
        if (sec?.loading == true && sec.data == null) item { CircularProgressIndicator(Modifier.height(28.dp)) }
        sec?.error?.let { msg -> item { ErrorLine(msg, vm::refresh) } }
        items(sec?.data.orEmpty().distinctBy { it.ticker }, key = { "h-" + it.ticker }) { q ->
            QuoteRow(q.ticker, q.name, q.price, q.changePct) { onOpen(q.ticker) }
        }
        item {
            Column {
                UpdatedLine(sec?.updatedAt, sec?.stale == true)
                Text(
                    "Entre os ativos mais negociados do dia.",
                    color = AppColors.Neutral, fontSize = 11.sp,
                )
            }
        }

        // Melhores dividendos
        item { SectionTitle("Melhores dividendos") }
        item {
            ChipRow(
                DividendSort.entries, ui.dividendSort,
                { if (it == DividendSort.RETORNO) "Retorno" else "% Retorno" },
                vm::selectDividendSort,
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "Retorno: proventos dos últimos 6 meses ÷ 6, por ação e por mês. " +
                        "% Retorno: o Retorno ÷ a cotação atual.",
                    color = AppColors.Neutral, fontSize = 12.sp,
                )
                TaxNote(ui.taxes)
            }
        }
        if (ui.dividends.loading && ui.dividends.data == null) item { CircularProgressIndicator(Modifier.height(28.dp)) }
        ui.dividends.error?.let { msg -> item { ErrorLine(msg, vm::refresh) } }
        if (ui.dividends.data != null && ranked.isEmpty()) {
            item { Text("Nenhum papel com proventos nos últimos 6 meses.", color = AppColors.Neutral) }
        }
        items(ranked, key = { "d-" + it.ticker }) { r ->
            val res = r.result(ui.taxes)
            AppCard(onClick = { onOpen(r.ticker) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CompanyLogo(r.ticker)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(r.ticker, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            "${r.price.brl()} · D.Y. 12m ${r.dividendYield.pct()}",
                            color = AppColors.Neutral, fontSize = 12.sp,
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${res.retorno.brl()}/mês", color = AppColors.Positive, fontWeight = FontWeight.Bold)
                        Text("${res.percentRetorno.pct()} ao mês", color = AppColors.Positive, fontSize = 13.sp)
                    }
                }
            }
        }
        item { UpdatedLine(ui.dividends.updatedAt, ui.dividends.stale) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
