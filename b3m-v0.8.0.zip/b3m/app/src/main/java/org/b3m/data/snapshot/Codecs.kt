package org.b3m.data.snapshot

import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import org.b3m.data.fundamentus.Detalhes
import org.b3m.data.market.DividendRank
import org.b3m.data.quotes.ChartPoint
import org.b3m.domain.Provento
import org.b3m.domain.Quote

/** Codecs JSON dos dados que ficam guardados em disco ([Snapshots]). */
object Codecs : DataCodecs {
    // encodeDefaults: campos com valor padrão (ex.: Quote.fetchedAt) precisam ser gravados.
    private val json = Json { encodeDefaults = true; ignoreUnknownKeys = true }

    fun <T> of(serializer: KSerializer<T>): Codec<T> =
        Codec(
            encode = { json.encodeToString(serializer, it) },
            decode = { json.decodeFromString(serializer, it) },
        )

    override val quote: Codec<Quote> = of(Quote.serializer())
    override val quotes: Codec<List<Quote>> = of(ListSerializer(Quote.serializer()))
    override val chart: Codec<List<ChartPoint>> = of(ListSerializer(ChartPoint.serializer()))
    override val proventos: Codec<List<Provento>> = of(ListSerializer(Provento.serializer()))
    override val detalhes: Codec<Detalhes> = of(Detalhes.serializer())
    override val ranking: Codec<List<DividendRank>> = of(ListSerializer(DividendRank.serializer()))
}
