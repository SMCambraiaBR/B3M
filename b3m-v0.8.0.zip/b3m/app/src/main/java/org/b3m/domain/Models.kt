package org.b3m.domain

import java.time.LocalDate
import kotlinx.serialization.Serializable

enum class ProventoTipo { DIVIDENDO, JCP, RENDIMENTO }

fun ProventoTipo.label(): String = when (this) {
    ProventoTipo.DIVIDENDO -> "Dividendo"
    ProventoTipo.JCP -> "JCP"
    ProventoTipo.RENDIMENTO -> "Rendimento"
}

/** Provento. [valorBruto] é por ação/cota; [dataCom] é a data em que era preciso ter o ativo. */
@Serializable
data class Provento(
    val ticker: String,
    val tipo: ProventoTipo,
    @Serializable(with = LocalDateSerializer::class) val dataPagamento: LocalDate,
    val valorBruto: Double,
    @Serializable(with = LocalDateSerializer::class) val dataCom: LocalDate? = null,
)

/**
 * Cotação. [fetchedAt] é o instante (ms) em que o dado foi coletado da fonte; é ele que a tela
 * mostra como "atualizado às ...", mesmo quando a cotação vem do cache ou do disco.
 */
@Serializable
data class Quote(
    val ticker: String,
    val price: Double,
    val changePct: Double,
    val open: Double? = null,
    val high: Double? = null,
    val low: Double? = null,
    val previousClose: Double? = null,
    val trades: Long? = null,
    val quantity: Long? = null,
    val volume: Double? = null,
    val name: String? = null,
    val fetchedAt: Long = System.currentTimeMillis(),
)

/** Cotação utilizável: preço finito e maior que zero (fontes às vezes devolvem 0 fora do pregão). */
fun Quote.isValid(): Boolean = price.isFinite() && price > 0.0

/** Resultado das métricas próprias do app. */
data class RetornoResult(
    val retorno: Double,        // R$ por ação por mês, líquido de imposto
    val percentRetorno: Double, // % sobre a cotação atual
)

/** Tolerância para comparar quantidades em ponto flutuante (0,1 + 0,2 − 0,3 não é zero). */
const val QTY_EPS = 1e-9

/** Posição do usuário em um ativo (calculada dos lançamentos cadastrados). */
data class Position(
    val ticker: String,
    val quantity: Double,
    val averagePrice: Double,
) {
    val invested: Double get() = quantity * averagePrice
}
