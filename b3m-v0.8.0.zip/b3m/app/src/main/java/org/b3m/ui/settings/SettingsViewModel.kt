package org.b3m.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.b3m.data.db.LancamentoRepository
import org.b3m.data.safely
import org.b3m.data.settings.SettingsStore
import org.b3m.domain.LancamentoCsv
import org.b3m.domain.TaxRates

/**
 * Ajustes: alíquotas de imposto (valem para o app todo), chaves das fontes de dados,
 * backup da carteira em CSV e limpeza do cache.
 */
class SettingsViewModel(
    private val settings: SettingsStore,
    private val lancamentos: LancamentoRepository,
    private val clearCaches: suspend () -> Unit,
) : ViewModel() {

    val taxes: StateFlow<TaxRates> get() = settings.taxRates

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    val savedBrapiToken: String get() = settings.savedBrapiToken
    val savedHgKey: String get() = settings.savedHgKey

    fun dismissMessage() {
        _message.value = null
    }

    fun report(text: String) {
        _message.value = text
    }

    fun saveTaxes(rates: TaxRates) {
        settings.setTaxRates(rates)
        _message.value = "Impostos salvos. Os valores líquidos do app já usam ${settings.taxRates.value.summary()}."
    }

    fun saveKeys(brapi: String, hg: String) {
        settings.setKeys(brapi, hg)
        _message.value = "Chaves salvas. Valem na próxima atualização das telas."
    }

    /** Texto do CSV com todos os lançamentos (a tela grava no arquivo escolhido). */
    suspend fun csv(): String = LancamentoCsv.encode(lancamentos.all())

    /** Importa o conteúdo de um CSV. Linhas inválidas são apontadas e ignoradas; o que já existe não duplica. */
    fun importCsv(text: String) {
        viewModelScope.launch {
            val parsed = LancamentoCsv.decode(text)
            val problems = parsed.errors.take(5).joinToString("\n")
            val more = if (parsed.errors.size > 5) "\n… e mais ${parsed.errors.size - 5} linha(s) com erro." else ""
            if (parsed.items.isEmpty()) {
                _message.value = if (parsed.errors.isEmpty()) "O arquivo não tem lançamentos." else "Nada importado.\n$problems$more"
                return@launch
            }
            safely { lancamentos.import(parsed.items) }
                .onSuccess { r ->
                    val ignored = if (parsed.errors.isEmpty()) "" else "\n${parsed.errors.size} linha(s) ignorada(s):\n$problems$more"
                    _message.value = "${r.added} lançamento(s) importado(s); ${r.alreadyThere} já existiam.$ignored"
                }
                .onFailure { e -> _message.value = e.message ?: "Não foi possível importar o arquivo." }
        }
    }

    fun clearCache() {
        viewModelScope.launch {
            safely { clearCaches() }
                .onSuccess { _message.value = "Dados guardados apagados. As telas buscam tudo de novo ao abrir." }
                .onFailure { _message.value = "Não foi possível limpar agora." }
        }
    }
}
