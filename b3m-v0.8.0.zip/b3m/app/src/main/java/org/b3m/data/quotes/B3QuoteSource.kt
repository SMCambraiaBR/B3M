package org.b3m.data.quotes

import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import okhttp3.OkHttpClient
import org.b3m.data.safely
import org.b3m.domain.Quote

/**
 * Endpoint público que o próprio site da B3 usa (cotação com atraso). Sem chave, sem gráfico.
 * O formato não é documentado: o parser procura os campos pelo nome em qualquer
 * profundidade, e a fonte simplesmente perde a corrida se algo vier diferente.
 */
class B3QuoteSource(private val http: OkHttpClient) : QuoteSource {

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun quote(ticker: String): Quote {
        if (Symbols.isIndex(ticker)) error("B3: índices não suportados")
        val root = json.parseToJsonElement(
            http.getString("https://cotacao.b3.com.br/mds/api/v1/instrumentQuotation/${ticker.uppercase()}")
        )
        val price = root.findNumber("curPrc")?.takeIf { it > 0.0 } ?: error("B3: sem preço para $ticker")
        return Quote(
            ticker = ticker.uppercase(),
            price = price,
            changePct = root.findNumber("prcFlcn") ?: 0.0,
            open = root.findNumber("opngPric"),
            high = root.findNumber("maxPric"),
            low = root.findNumber("minPric"),
        )
    }

    override suspend fun quotes(tickers: List<String>): List<Quote> = coroutineScope {
        tickers.map { t -> async { safely { quote(t) }.getOrNull() } }.mapNotNull { it.await() }
    }

    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> =
        throw UnsupportedOperationException("B3 não fornece histórico por este endpoint")

    private fun JsonElement.findNumber(key: String): Double? = when (this) {
        is JsonObject -> (this[key] as? JsonPrimitive)?.doubleOrNull
            ?: values.firstNotNullOfOrNull { it.findNumber(key) }
        is JsonArray -> firstNotNullOfOrNull { it.findNumber(key) }
        else -> null
    }
}
