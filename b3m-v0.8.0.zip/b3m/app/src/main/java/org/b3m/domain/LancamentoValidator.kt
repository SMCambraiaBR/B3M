package org.b3m.domain

import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** Formato dos códigos da B3: 4 caracteres (o primeiro é letra) + 1 ou 2 dígitos. Ex.: PETR4, B3SA3, BOVA11, M1TA34. */
object TickerRules {
    private val regex = Regex("^[A-Z][A-Z0-9]{3}\\d{1,2}$")

    fun normalize(ticker: String): String = ticker.trim().uppercase()

    fun isValid(ticker: String): Boolean = regex.matches(normalize(ticker))
}

/** Venda que, na ordem cronológica, ultrapassaria o que o usuário tinha na carteira. */
data class Inconsistency(val ticker: String, val date: LocalDate, val held: Double, val sold: Double)

object LancamentoValidator {

    private val dayFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    /** Campos isolados: código, quantidade, preço e data. Devolve a mensagem de erro ou null. */
    fun validateFields(l: Lancamento, today: LocalDate = LocalDate.now()): String? = when {
        !TickerRules.isValid(l.ticker) -> "Código inválido. Exemplos: PETR4, B3SA3, BOVA11."
        !(l.quantidade.isFinite() && l.quantidade > 0.0) -> "A quantidade deve ser maior que zero."
        !(l.preco.isFinite() && l.preco > 0.0) -> "O preço deve ser maior que zero."
        l.data.isAfter(today) -> "A data não pode ser futura."
        else -> null
    }

    /** Campos + consistência com os lançamentos que já existem (não vende mais do que tem). */
    fun validate(existing: List<Lancamento>, novo: Lancamento, today: LocalDate = LocalDate.now()): String? {
        validateFields(novo, today)?.let { return it }
        // O lançamento novo recebe o maior id: no mesmo dia ele vale depois dos que já existem.
        val problem = firstInconsistency(existing + novo.copy(id = Long.MAX_VALUE)) ?: return null
        return describe(problem)
    }

    /** Frase para a tela: "Venda de 11 PETR4 em 01/02/2026 maior que a posição de 10 nessa data." */
    fun describe(problem: Inconsistency): String =
        "Venda de ${qtyText(problem.sold)} ${problem.ticker} em ${problem.date.format(dayFmt)} " +
            "maior que a posição de ${qtyText(problem.held)} nessa data."

    /** Excluir um lançamento não pode deixar uma venda posterior sem ações para vender. */
    fun validateRemoval(existing: List<Lancamento>, id: Long): String? {
        val problem = firstInconsistency(existing.filterNot { it.id == id }) ?: return null
        return "Não dá para excluir: a venda de ${qtyText(problem.sold)} ${problem.ticker} em " +
            "${problem.date.format(dayFmt)} passaria a ser maior que a posição (${qtyText(problem.held)})."
    }

    /** Primeira venda que excede a posição, em ordem cronológica; null se tudo fecha. */
    fun firstInconsistency(list: List<Lancamento>): Inconsistency? {
        for ((ticker, ls) in list.groupBy { it.ticker.uppercase() }) {
            var qty = 0.0
            for (l in ls.sortedWith(compareBy({ it.data }, { it.id }))) {
                if (l.tipo == LancamentoTipo.COMPRA) {
                    qty += l.quantidade
                } else {
                    if (l.quantidade > qty + QTY_EPS) return Inconsistency(ticker, l.data, qty, l.quantidade)
                    qty -= l.quantidade
                    if (qty < QTY_EPS) qty = 0.0
                }
            }
        }
        return null
    }

    private fun qtyText(q: Double): String =
        if (kotlin.math.abs(q - Math.rint(q)) < 1e-9) Math.rint(q).toLong().toString()
        else q.toString().trimEnd('0').trimEnd('.')
}
