package org.b3m.data.market

import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.OkHttpClient
import org.b3m.data.quotes.ChartPoint
import org.b3m.data.quotes.getString
import org.b3m.domain.SeriesMath

/** Séries oficiais do Banco Central (SGS): CDI diário (12) e IPCA mensal (433). */
class BcbClient(private val http: OkHttpClient) : BenchmarkSource {

    private val json = Json { ignoreUnknownKeys = true }
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    private suspend fun series(code: Int, from: LocalDate): List<Pair<LocalDate, Double>> {
        val url = "https://api.bcb.gov.br/dados/serie/bcdata.sgs.$code/dados" +
            "?formato=json&dataInicial=${from.format(fmt)}&dataFinal=${LocalDate.now().format(fmt)}"
        val body = http.getString(url)
        return withContext(Dispatchers.Default) {
            val arr = json.parseToJsonElement(body) as? JsonArray ?: error("BCB: resposta inesperada")
            arr.mapNotNull { e ->
                val o = e as? JsonObject ?: return@mapNotNull null
                val date = runCatching { LocalDate.parse((o["data"] as JsonPrimitive).content, fmt) }.getOrNull()
                val value = (o["valor"] as? JsonPrimitive)?.content?.toDoubleOrNull()
                if (date != null && value != null) date to value else null
            }
        }
    }

    private fun LocalDate.toMillis() = atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()

    /** CDI acumulado (%) desde [from]; começa em 0. */
    override suspend fun cdiAccumulated(from: LocalDate): List<ChartPoint> {
        val daily = series(12, from).map { it.first.toMillis() to it.second }
        return SeriesMath.accumulate(from.toMillis(), daily)
    }

    /** IPCA acumulado (%) desde [from]; cada mês entra no início do mês seguinte. */
    override suspend fun ipcaAccumulated(from: LocalDate): List<ChartPoint> {
        val monthly = series(433, from.withDayOfMonth(1)).map {
            it.first.plusMonths(1).toMillis() to it.second
        }
        return SeriesMath.accumulate(from.toMillis(), monthly)
    }
}
