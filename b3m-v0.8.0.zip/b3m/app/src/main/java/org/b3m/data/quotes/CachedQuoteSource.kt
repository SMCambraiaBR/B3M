package org.b3m.data.quotes

import org.b3m.data.AsyncCache
import org.b3m.data.InFlight
import org.b3m.domain.Quote

/**
 * Cache em memória com validade curta, mais a junção de chamadas idênticas simultâneas.
 *
 * A validade da cotação (5 s) é menor que o intervalo de atualização das telas (10–15 s), então
 * cada atualização das telas vai mesmo à rede; o cache serve para telas que pedem o mesmo dado
 * ao mesmo tempo e para a lista de ativos aberta em vários blocos. Ao abrir uma tela, o app
 * chama [invalidateQuotes] (cotações e gráficos) para garantir dado novo.
 */
class CachedQuoteSource(
    private val delegate: QuoteSource,
    private val quoteTtlMs: Long = 5_000,
    private val intradayChartTtlMs: Long = 45_000,
    private val longChartTtlMs: Long = 5 * 60_000,
    clock: () -> Long = System::currentTimeMillis,
) : QuoteSource {

    private val quoteCache = AsyncCache<Quote>(quoteTtlMs, clock)
    private val chartCache = AsyncCache<List<ChartPoint>>(longChartTtlMs, clock)
    private val batches = InFlight<List<Quote>>()

    override suspend fun quote(ticker: String): Quote {
        val key = ticker.trim().uppercase()
        return quoteCache.get(key) { delegate.quote(key) }
    }

    override suspend fun quotes(tickers: List<String>): List<Quote> {
        if (tickers.isEmpty()) return emptyList()
        val requested = tickers.map { it.trim().uppercase() }
        val resolved = HashMap<String, Quote>()
        val missing = linkedSetOf<String>()
        requested.forEach { key ->
            val cached = quoteCache.fresh(key)
            if (cached != null) resolved[key] = cached else missing += key
        }
        if (missing.isNotEmpty()) {
            val list = missing.toList()
            val fetched = batches.run("batch:" + list.sorted().joinToString(",")) { delegate.quotes(list) }
            for (q in fetched) {
                val key = q.ticker.trim().uppercase()
                quoteCache.put(key, q)
                resolved[key] = q
            }
        }
        // Preserva a ordem solicitada e não perde duplicatas por causa do cache.
        return requested.mapNotNull { resolved[it] }
    }

    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> {
        val key = "${ticker.trim().uppercase()}:${range.name}"
        val ttl = if (range.isIntraday) intradayChartTtlMs else longChartTtlMs
        return chartCache.get(key, ttl) { delegate.chart(ticker.trim().uppercase(), range) }
    }

    /** Cotações e gráficos: ao abrir uma tela o dado vem da rede, e o horário de coleta mostrado é real. */
    override fun invalidateQuotes() {
        quoteCache.invalidateAll()
        chartCache.invalidateAll()
        delegate.invalidateQuotes()
    }
}
