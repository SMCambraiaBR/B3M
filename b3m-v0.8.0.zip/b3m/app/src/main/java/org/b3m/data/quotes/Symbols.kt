package org.b3m.data.quotes

object Symbols {
    /** Símbolo do Ibovespa nas fontes (Yahoo e brapi usam o mesmo). */
    const val IBOV = "^BVSP"

    fun isIndex(ticker: String) = ticker.startsWith("^")

    /** Yahoo: ações da B3 levam ".SA"; índices começam com "^" e ficam como estão. */
    fun yahoo(ticker: String): String =
        if (isIndex(ticker)) ticker.uppercase() else "${ticker.uppercase()}.SA"

    /** Logo da empresa (SVG) pelo código; se não existir, a UI mostra as iniciais. */
    fun logoUrl(ticker: String): String = "https://icons.brapi.dev/icons/${ticker.uppercase()}.svg"
}
