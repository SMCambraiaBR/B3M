package org.b3m.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import java.time.LocalDate
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.b3m.data.snapshot.SnapshotStore
import org.b3m.data.snapshot.StoredSnapshot
import org.b3m.domain.Lancamento
import org.b3m.domain.LancamentoTipo
import org.b3m.domain.LancamentoValidator

@Entity(tableName = "lancamentos")
data class LancamentoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ticker: String,
    val tipo: String,
    val quantidade: Double,
    val preco: Double,
    val dataEpochDay: Long,
)

/** Última coleta bem-sucedida de cada dado (cotação, gráfico, proventos...), para mostrar sem internet. */
@Entity(tableName = "snapshots")
data class SnapshotEntity(
    @PrimaryKey val cacheKey: String,
    val json: String,
    val fetchedAt: Long,
)

/** Ativos favoritos (lista de acompanhamento). */
@Entity(tableName = "watchlist")
data class WatchEntity(
    @PrimaryKey val ticker: String,
    val addedAt: Long,
)

@Dao
interface LancamentoDao {
    @Query("SELECT * FROM lancamentos ORDER BY dataEpochDay DESC, id DESC")
    fun observeAll(): Flow<List<LancamentoEntity>>

    @Query("SELECT * FROM lancamentos ORDER BY dataEpochDay ASC, id ASC")
    suspend fun all(): List<LancamentoEntity>

    @Insert
    suspend fun insert(entity: LancamentoEntity): Long

    @Insert
    suspend fun insertAll(entities: List<LancamentoEntity>)

    @Query("DELETE FROM lancamentos WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface SnapshotDao {
    @Query("SELECT * FROM snapshots WHERE cacheKey = :key")
    suspend fun get(key: String): SnapshotEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: SnapshotEntity)

    @Query("DELETE FROM snapshots WHERE fetchedAt < :before")
    suspend fun prune(before: Long)

    @Query("DELETE FROM snapshots")
    suspend fun clear()
}

@Dao
interface WatchDao {
    @Query("SELECT * FROM watchlist ORDER BY addedAt ASC")
    fun observeAll(): Flow<List<WatchEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: WatchEntity)

    @Query("DELETE FROM watchlist WHERE ticker = :ticker")
    suspend fun delete(ticker: String)
}

@Database(
    entities = [LancamentoEntity::class, SnapshotEntity::class, WatchEntity::class],
    version = 2,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lancamentoDao(): LancamentoDao
    abstract fun snapshotDao(): SnapshotDao
    abstract fun watchDao(): WatchDao
}

/**
 * v1 -> v2: acrescenta as tabelas de snapshots e de favoritos. A tabela de lançamentos (os dados
 * que o usuário digitou) não é tocada. Toda mudança futura de schema precisa de uma migração
 * nova aqui — sem ela o Room recusa abrir o banco em vez de apagar a carteira.
 */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `snapshots` (`cacheKey` TEXT NOT NULL, `json` TEXT NOT NULL, " +
                "`fetchedAt` INTEGER NOT NULL, PRIMARY KEY(`cacheKey`))"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `watchlist` (`ticker` TEXT NOT NULL, `addedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`ticker`))"
        )
    }
}

class RoomSnapshotStore(private val dao: SnapshotDao) : SnapshotStore {
    override suspend fun load(key: String): StoredSnapshot? =
        dao.get(key)?.let { StoredSnapshot(it.json, it.fetchedAt) }

    override suspend fun save(key: String, json: String, fetchedAt: Long) =
        dao.put(SnapshotEntity(key, json, fetchedAt))

    override suspend fun prune(olderThan: Long) = dao.prune(olderThan)

    override suspend fun clear() = dao.clear()
}

/** Resultado de uma importação de CSV. */
data class ImportResult(val added: Int, val alreadyThere: Int)

class LancamentoRepository(private val dao: LancamentoDao) {

    fun observe(): Flow<List<Lancamento>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun all(): List<Lancamento> = dao.all().map { it.toDomain() }

    /** Valida (campos e posição) e grava. Lança [IllegalArgumentException] com a mensagem para a tela. */
    suspend fun add(l: Lancamento) {
        LancamentoValidator.validate(all(), l)?.let { throw IllegalArgumentException(it) }
        dao.insert(l.toEntity())
    }

    /** Não deixa excluir uma compra que sustenta uma venda posterior. */
    suspend fun remove(id: Long) {
        LancamentoValidator.validateRemoval(all(), id)?.let { throw IllegalArgumentException(it) }
        dao.deleteById(id)
    }

    /**
     * Acrescenta lançamentos de um CSV. O que já existe (mesmo ativo, tipo, quantidade, preço e
     * data) não é duplicado, então importar o mesmo arquivo duas vezes não muda nada. Se o
     * conjunto final ficaria inconsistente (venda maior que a posição), nada é gravado.
     */
    suspend fun import(items: List<Lancamento>): ImportResult {
        val existing = all()
        fun key(l: Lancamento) = listOf(l.ticker.uppercase(), l.tipo, l.quantidade, l.preco, l.data)
        val remaining = HashMap<List<Any>, Int>()
        existing.forEach { remaining.merge(key(it), 1, Int::plus) }
        val novos = ArrayList<Lancamento>()
        for (l in items) {
            val k = key(l)
            val left = remaining[k] ?: 0
            if (left > 0) remaining[k] = left - 1 else novos += l
        }
        LancamentoValidator.firstInconsistency(existing + novos)?.let {
            throw IllegalArgumentException("Importação cancelada. " + LancamentoValidator.describe(it))
        }
        dao.insertAll(novos.map { it.toEntity() })
        return ImportResult(added = novos.size, alreadyThere = items.size - novos.size)
    }

    private fun Lancamento.toEntity() = LancamentoEntity(
        ticker = ticker.trim().uppercase(),
        tipo = tipo.name,
        quantidade = quantidade,
        preco = preco,
        dataEpochDay = data.toEpochDay(),
    )

    private fun LancamentoEntity.toDomain() = Lancamento(
        id = id,
        ticker = ticker,
        tipo = LancamentoTipo.valueOf(tipo),
        quantidade = quantidade,
        preco = preco,
        data = LocalDate.ofEpochDay(dataEpochDay),
    )
}

/** Para as telas: devolve a mensagem de erro (para mostrar ao usuário) em vez de lançar. Null = deu certo. */
suspend fun LancamentoRepository.tryAdd(l: Lancamento): String? =
    try {
        add(l)
        null
    } catch (e: IllegalArgumentException) {
        e.message ?: "Lançamento inválido."
    }

suspend fun LancamentoRepository.tryRemove(id: Long): String? =
    try {
        remove(id)
        null
    } catch (e: IllegalArgumentException) {
        e.message ?: "Não foi possível excluir."
    }

class WatchlistRepository(private val dao: WatchDao) {
    fun observe(): Flow<List<String>> = dao.observeAll().map { list -> list.map { it.ticker } }

    suspend fun add(ticker: String) = dao.insert(WatchEntity(ticker.trim().uppercase(), System.currentTimeMillis()))

    suspend fun remove(ticker: String) = dao.delete(ticker.trim().uppercase())
}
