package org.b3m.data.market

import java.time.LocalDate
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.b3m.data.fundamentus.FundamentusApi
import org.b3m.data.safely

/**
 * "Melhores dividendos": pega os papéis líquidos com maior dividend yield da tabela
 * geral do Fundamentus, baixa os proventos de cada candidato e deixa o ranking para a tela,
 * que calcula Retorno e % Retorno (líquidos de imposto) com a regra própria do app.
 */
class DividendRanking(
    private val fundamentus: FundamentusApi,
    private val candidates: Int = 30,
    private val minLiquidity: Double = 1_000_000.0,
    private val maxYield: Double = 40.0, // descarta DYs absurdos (dado ruim ou evento pontual)
    private val keepMonths: Long = 14,   // só os proventos recentes interessam; economiza disco
) : RankingSource {
    override suspend fun load(): List<DividendRank> = candidates()

    suspend fun candidates(today: LocalDate = LocalDate.now()): List<DividendRank> = coroutineScope {
        val rows = fundamentus.resultado()
            .filter { it.liquidity >= minLiquidity && it.dividendYield in 0.01..maxYield && it.price > 0 }
            .sortedByDescending { it.dividendYield }
            .take(candidates)
        val gate = Semaphore(4)
        val since = today.minusMonths(keepMonths)
        rows.map { row ->
            async {
                gate.withPermit {
                    safely {
                        val prov = fundamentus.proventos(row.ticker).filter { it.dataPagamento.isAfter(since) }
                        DividendRank(row.ticker, row.price, row.dividendYield, prov)
                    }.getOrNull()
                }
            }
        }.awaitAll().filterNotNull()
    }
}
