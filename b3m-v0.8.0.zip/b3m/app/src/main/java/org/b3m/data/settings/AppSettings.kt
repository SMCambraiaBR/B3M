package org.b3m.data.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.b3m.BuildConfig
import org.b3m.domain.TaxRates

/**
 * Configurações do usuário.
 *  - Alíquotas de imposto sobre proventos: valem para o app inteiro (todo valor "líquido").
 *  - Chaves das fontes de dados (brapi, HG Brasil): ficam só neste aparelho, em arquivo separado
 *    que NÃO entra no backup automático do Android (veja res/xml/backup_rules.xml).
 */
class AppSettings(context: Context) : SettingsStore {

    private val prefs = context.applicationContext.getSharedPreferences("b3m_settings", Context.MODE_PRIVATE)
    private val secrets = context.applicationContext.getSharedPreferences("b3m_secrets", Context.MODE_PRIVATE)

    private val _taxRates = MutableStateFlow(readTaxRates())
    override val taxRates: StateFlow<TaxRates> = _taxRates

    private fun readTaxRates(): TaxRates {
        val d = TaxRates()
        fun rate(key: String, default: Double): Double =
            prefs.getString(key, null)?.toDoubleOrNull()?.let { TaxRates.sanitize(it) } ?: default
        return TaxRates(
            dividendo = rate(KEY_DIVIDENDO, d.dividendo),
            jcp = rate(KEY_JCP, d.jcp),
            rendimento = rate(KEY_RENDIMENTO, d.rendimento),
        )
    }

    override fun setTaxRates(rates: TaxRates) {
        val clean = TaxRates(
            dividendo = TaxRates.sanitize(rates.dividendo),
            jcp = TaxRates.sanitize(rates.jcp),
            rendimento = TaxRates.sanitize(rates.rendimento),
        )
        prefs.edit()
            .putString(KEY_DIVIDENDO, clean.dividendo.toString())
            .putString(KEY_JCP, clean.jcp.toString())
            .putString(KEY_RENDIMENTO, clean.rendimento.toString())
            .apply()
        _taxRates.value = clean
    }

    /** Token digitado em Ajustes (vazio se não houver). */
    override val savedBrapiToken: String get() = secrets.getString(KEY_BRAPI, "").orEmpty()

    /** Token em uso: o de Ajustes ou, na falta, o de local.properties usado na compilação. */
    val brapiToken: String get() = savedBrapiToken.ifBlank { BuildConfig.BRAPI_TOKEN }

    override val savedHgKey: String get() = secrets.getString(KEY_HG, "").orEmpty()
    val hgKey: String get() = savedHgKey.ifBlank { BuildConfig.HGBRASIL_KEY }

    override fun setKeys(brapi: String, hg: String) {
        secrets.edit().putString(KEY_BRAPI, brapi.trim()).putString(KEY_HG, hg.trim()).apply()
    }

    private companion object {
        const val KEY_DIVIDENDO = "tax_dividendo"
        const val KEY_JCP = "tax_jcp"
        const val KEY_RENDIMENTO = "tax_rendimento"
        const val KEY_BRAPI = "brapi_token"
        const val KEY_HG = "hgbrasil_key"
    }
}
