package org.b3m.ui.market

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import org.b3m.data.db.WatchlistRepository
import org.b3m.data.fundamentus.FundamentusApi
import org.b3m.data.market.DividendRank
import org.b3m.data.market.DividendSort
import org.b3m.data.market.RankingSource
import org.b3m.data.quotes.ChartPoint
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.MarketListSource
import org.b3m.data.quotes.QuoteRepository
import org.b3m.data.quotes.Symbols
import org.b3m.data.safely
import org.b3m.data.snapshot.DataCodecs
import org.b3m.data.snapshot.Snapshots
import org.b3m.data.snapshot.Stamped
import org.b3m.domain.Quote
import org.b3m.domain.TaxRates
import org.b3m.ui.Section
import org.b3m.ui.toSection

enum class Highlight(val label: String) {
    GAINERS("Maiores altas"), LOSERS("Maiores quedas"), TRADED("Mais negociadas")
}

/** Um favorito: [quote] é null enquanto nunca houve cotação; [stale] = a coleta nova falhou. */
data class FavoriteUi(val ticker: String, val quote: Quote?, val stale: Boolean)

data class MarketUi(
    val query: String = "",
    val results: Section<List<Quote>> = Section(emptyList(), loading = false),
    val ibov: Section<Quote> = Section(),
    val ibovRange: ChartRange = ChartRange.D1,
    val ibovChart: Section<List<ChartPoint>> = Section(),
    val highlights: Map<Highlight, Section<List<Quote>>> = Highlight.entries.associateWith { Section<List<Quote>>() },
    val highlight: Highlight = Highlight.GAINERS,
    val favorites: List<FavoriteUi> = emptyList(),
    val favoritesAt: Long? = null, // coleta mais antiga entre as cotações dos favoritos
    val favoritesStale: Boolean = false,
    val dividends: Section<List<DividendRank>> = Section(),
    val dividendSort: DividendSort = DividendSort.RETORNO,
    val taxes: TaxRates = TaxRates(),
)

/**
 * Tela Mercado. Só trabalha enquanto a tela está visível: [start] ao aparecer (descarta os
 * caches e busca tudo de novo, mostrando já o último dado guardado em disco) e [stop] ao sumir.
 */
@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class MarketViewModel(
    private val quotes: QuoteRepository,
    private val market: MarketListSource,
    private val ranking: RankingSource,
    private val fundamentus: FundamentusApi,
    private val snapshots: Snapshots,
    private val codecs: DataCodecs,
    private val watchlist: WatchlistRepository,
    taxes: StateFlow<TaxRates>,
    private val clock: () -> Long = System::currentTimeMillis,
    private val refreshMs: Long = 30_000,
    private val retryMs: Long = RETRY_MS,
    private val rankingReuseMs: Long = RANKING_REUSE_MS,
) : ViewModel() {

    private val _ui = MutableStateFlow(MarketUi(taxes = taxes.value))
    val ui: StateFlow<MarketUi> = _ui

    private val query = MutableStateFlow("")
    private var job: Job? = null
    private var chartJob: Job? = null

    @Volatile
    private var favorites: List<String> = emptyList()

    init {
        // Alíquotas: o ranking é recalculado na hora quando mudam em Ajustes.
        viewModelScope.launch { taxes.collect { t -> _ui.update { it.copy(taxes = t) } } }
        // Busca com sugestões a cada letra (com uma pequena espera para não disparar a cada toque).
        viewModelScope.launch {
            query.debounce(200).distinctUntilChanged().collectLatest { q ->
                if (q.isBlank()) {
                    _ui.update { it.copy(results = Section(emptyList(), loading = false)) }
                } else {
                    _ui.update { it.copy(results = it.results.copy(loading = true, error = null)) }
                    safely { market.search(q) }
                        .onSuccess { r -> _ui.update { it.copy(results = Section(r, loading = false)) } }
                        .onFailure { _ui.update { s -> s.copy(results = Section(emptyList(), false, "Busca indisponível agora.")) } }
                }
            }
        }
    }

    fun onQuery(text: String) {
        _ui.update { it.copy(query = text) }
        query.value = text
    }

    fun selectHighlight(h: Highlight) = _ui.update { it.copy(highlight = h) }
    fun selectDividendSort(s: DividendSort) = _ui.update { it.copy(dividendSort = s) }

    fun selectIbovRange(range: ChartRange) {
        if (range == _ui.value.ibovRange && _ui.value.ibovChart.data != null) return
        _ui.update { it.copy(ibovRange = range, ibovChart = Section()) }
        if (job != null) launchChart(range)
    }

    // ---- ciclo de vida da tela ---------------------------------------------------------

    /** A tela apareceu: busca tudo de novo e continua atualizando enquanto ela estiver visível. */
    fun start() = launchAll(forceRanking = false)

    /** A tela saiu de vista: para de consultar a internet. */
    fun stop() {
        job?.cancel()
        chartJob?.cancel()
        job = null
        chartJob = null
    }

    /** Botão "atualizar": refaz tudo, inclusive o ranking de dividendos (que normalmente se reaproveita por 15 min). */
    fun refresh() {
        if (job == null) return
        stop()
        fundamentus.invalidateAll()
        launchAll(forceRanking = true)
    }

    private fun launchAll(forceRanking: Boolean) {
        if (job?.isActive == true) return
        quotes.invalidateQuotes()
        market.invalidate()
        job = viewModelScope.launch {
            supervisorScope {
                launch { pollQuotes() }
                launch { pollHighlights() }
                launch { pollRanking(forceRanking) }
                launch { watchFavorites() }
            }
        }
        launchChart(_ui.value.ibovRange)
    }

    // ---- cotações: IBOV e favoritos -----------------------------------------------------

    private suspend fun pollQuotes() {
        quotes.lastKnownQuote(Symbols.IBOV)?.let { s ->
            _ui.update { if (it.ibov.data == null) it.copy(ibov = s.toSection()) else it }
        }
        while (true) {
            loadIbov()
            val tickers = favorites
            if (tickers.isNotEmpty()) loadFavorites(tickers)
            delay(refreshMs)
        }
    }

    private suspend fun loadIbov() {
        safely { quotes.quote(Symbols.IBOV) }
            .onSuccess { s -> _ui.update { it.copy(ibov = s.toSection()) } }
            .onFailure { _ui.update { s -> s.copy(ibov = s.ibov.failed("Sem cotação do Ibovespa agora.")) } }
    }

    private suspend fun watchFavorites() {
        watchlist.observe().collectLatest { list ->
            val tickers = list.map { it.trim().uppercase() }.distinct()
            favorites = tickers
            publishFavorites(tickers, quotes.lastKnownQuotes(tickers))
            loadFavorites(tickers)
        }
    }

    private suspend fun loadFavorites(tickers: List<String>) {
        if (tickers.isEmpty()) {
            publishFavorites(tickers, emptyMap())
            return
        }
        publishFavorites(tickers, quotes.quotes(tickers))
    }

    private fun publishFavorites(tickers: List<String>, found: Map<String, Stamped<Quote>>) {
        if (tickers != favorites) return // a lista mudou enquanto a consulta rodava: o resultado é de uma lista antiga
        val items = tickers.map { t -> FavoriteUi(t, found[t]?.value, stale = found[t]?.stale ?: true) }
        _ui.update {
            it.copy(
                favorites = items,
                favoritesAt = found.values.minOfOrNull { s -> s.fetchedAt },
                favoritesStale = items.any { f -> f.stale },
            )
        }
    }

    // ---- destaques ----------------------------------------------------------------------

    private suspend fun pollHighlights() {
        Highlight.entries.forEach { h ->
            snapshots.lastKnown(highlightKey(h), codecs.quotes)?.let { s ->
                setHighlight(h) { cur -> if (cur.data == null) s.toSection() else cur }
            }
        }
        while (true) {
            coroutineScope { Highlight.entries.map { h -> async { loadHighlight(h) } }.awaitAll() }
            delay(refreshMs * 2) // a lista da brapi tem cota mensal gratuita: não vale consultar a cada 30 s
        }
    }

    private suspend fun loadHighlight(h: Highlight) {
        safely {
            snapshots.fetch(highlightKey(h), codecs.quotes) {
                when (h) {
                    Highlight.GAINERS -> market.topGainers(9)
                    Highlight.LOSERS -> market.topLosers(9)
                    Highlight.TRADED -> market.mostTraded(9)
                }.also { check(it.isNotEmpty()) { "lista vazia" } }
            }
        }
            .onSuccess { s -> setHighlight(h) { s.toSection() } }
            .onFailure { setHighlight(h) { cur -> cur.failed("Destaques indisponíveis agora. Veja o token da brapi em Ajustes.") } }
    }

    private fun setHighlight(h: Highlight, change: (Section<List<Quote>>) -> Section<List<Quote>>) {
        _ui.update { s -> s.copy(highlights = s.highlights + (h to change(s.highlights[h] ?: Section()))) }
    }

    private fun highlightKey(h: Highlight) = "market:highlight:${h.name}"

    // ---- ranking de dividendos ----------------------------------------------------------

    private suspend fun pollRanking(force: Boolean) {
        var forced = force
        while (true) {
            val waitMs = loadRanking(forced)
            forced = false
            delay(waitMs)
        }
    }

    /**
     * Mostra o ranking guardado em disco na hora. Ele é caro de montar (uma página do
     * Fundamentus por candidato), então é reaproveitado por [rankingReuseMs] (15 min) — a tela mostra a
     * hora em que foi coletado. Devolve quanto esperar até a próxima tentativa.
     */
    private suspend fun loadRanking(force: Boolean): Long {
        val last = snapshots.lastKnown(RANKING_KEY, codecs.ranking)
        if (last != null) {
            _ui.update { if (it.dividends.data == null) it.copy(dividends = last.toSection()) else it }
            val age = clock() - last.fetchedAt
            if (!force && age in 0 until rankingReuseMs) return rankingReuseMs - age
        }
        return safely {
            snapshots.fetch(RANKING_KEY, codecs.ranking) {
                ranking.load().also { check(it.isNotEmpty()) { "ranking vazio" } }
            }
        }.fold(
            onSuccess = { s ->
                _ui.update { it.copy(dividends = s.toSection()) }
                if (s.stale) retryMs else rankingReuseMs
            },
            onFailure = {
                _ui.update { it.copy(dividends = it.dividends.failed("Não foi possível carregar os dividendos do Fundamentus.")) }
                retryMs
            },
        )
    }

    // ---- gráfico do IBOV ----------------------------------------------------------------

    private fun launchChart(range: ChartRange) {
        chartJob?.cancel()
        chartJob = viewModelScope.launch {
            quotes.lastKnownChart(Symbols.IBOV, range)?.let { s ->
                _ui.update { if (it.ibovRange == range && it.ibovChart.data == null) it.copy(ibovChart = s.toSection()) else it }
            }
            while (true) {
                safely { quotes.chart(Symbols.IBOV, range) }
                    .onSuccess { s -> _ui.update { if (it.ibovRange == range) it.copy(ibovChart = s.toSection()) else it } }
                    .onFailure {
                        _ui.update { if (it.ibovRange == range) it.copy(ibovChart = it.ibovChart.failed("Gráfico indisponível agora.")) else it }
                    }
                if (!range.isIntraday) break // só os gráficos do dia e da semana mudam sozinhos
                delay(60_000)
            }
        }
    }

    companion object {
        const val RANKING_KEY = "market:ranking"
        const val RANKING_REUSE_MS = 15 * 60_000L
        const val RETRY_MS = 60_000L
    }
}
