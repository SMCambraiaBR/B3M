package org.b3m.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.b3m.ui.theme.AppColors

/** Largura reservada à direita para os valores dos eixos. */
private val Gutter = 68.dp

data class BarItem(val label: String, val value: Double)

/**
 * Barras por período (ex.: proventos por mês). Toque em uma barra para ver o valor exato.
 * [average] desenha uma linha tracejada de referência (ex.: média dos últimos 6 meses).
 */
@Composable
fun BarChart(
    items: List<BarItem>,
    valueFormat: (Double) -> String,
    modifier: Modifier = Modifier,
    average: Double? = null,
    averageLabel: String = "média",
    color: Color = AppColors.Positive,
    emptyText: String = "Sem dados no período",
    height: Dp = 170.dp,
) {
    if (items.isEmpty() || items.all { it.value <= 0.0 }) {
        Box(modifier.height(height), contentAlignment = Alignment.Center) {
            Text(emptyText, color = AppColors.Neutral)
        }
        return
    }

    val measurer = rememberTextMeasurer()
    var selected by remember { mutableStateOf<Int?>(null) }
    val labelStyle = TextStyle(color = AppColors.Neutral, fontSize = 10.sp)
    val tipStyle = TextStyle(color = Color.White, fontSize = 12.sp)

    Canvas(
        modifier
            .height(height)
            .pointerInput(items.size) {
                detectTapGestures { offset ->
                    val plotW = size.width - Gutter.toPx()
                    val idx = (offset.x / (plotW / items.size)).toInt()
                    selected = if (idx in items.indices && selected != idx) idx else null
                }
            }
    ) {
        val gutter = Gutter.toPx()
        val labelArea = 18.dp.toPx()
        val plotW = size.width - gutter
        val plotH = size.height - labelArea
        val maxV = maxOf(items.maxOf { it.value }, average ?: 0.0).coerceAtLeast(1e-9) * 1.15
        fun y(v: Double): Float = (plotH * (1.0 - v / maxV)).toFloat()

        // base (0) e topo
        drawLine(Color(0x22FFFFFF), Offset(0f, plotH), Offset(plotW, plotH), strokeWidth = 1f)
        drawLine(Color(0x22FFFFFF), Offset(0f, 0f), Offset(plotW, 0f), strokeWidth = 1f)
        measurer.measure(valueFormat(maxV), labelStyle).let { drawText(it, topLeft = Offset(plotW + 6.dp.toPx(), 0f)) }
        measurer.measure(valueFormat(0.0), labelStyle).let {
            drawText(it, topLeft = Offset(plotW + 6.dp.toPx(), plotH - it.size.height))
        }

        val slot = plotW / items.size
        val barW = slot * 0.6f
        items.forEachIndexed { i, item ->
            val left = slot * i + (slot - barW) / 2f
            if (item.value > 0.0) {
                val top = y(item.value)
                drawRoundRect(
                    color = if (selected == i) color else color.copy(alpha = 0.8f),
                    topLeft = Offset(left, top),
                    size = Size(barW, plotH - top),
                    cornerRadius = CornerRadius(4.dp.toPx()),
                )
            }
            val layout = measurer.measure(item.label, labelStyle)
            val lx = (slot * i + slot / 2f - layout.size.width / 2f).coerceIn(0f, plotW - layout.size.width)
            drawText(layout, topLeft = Offset(lx, plotH + 3.dp.toPx()))
        }

        if (average != null && average > 0.0) {
            val ay = y(average)
            drawLine(
                Color(0xCCFFFFFF), Offset(0f, ay), Offset(plotW, ay), strokeWidth = 1.5f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)),
            )
            val layout = measurer.measure("$averageLabel ${valueFormat(average)}", labelStyle)
            val ly = (ay - layout.size.height - 2.dp.toPx()).coerceAtLeast(0f)
            drawText(layout, topLeft = Offset((plotW - layout.size.width).coerceAtLeast(0f), ly))
        }

        selected?.let { i ->
            val item = items[i]
            val layout = measurer.measure("${item.label}: ${valueFormat(item.value)}", tipStyle)
            val pad = 6.dp.toPx()
            val boxW = layout.size.width + pad * 2
            val boxH = layout.size.height + pad * 2
            val cx = slot * i + slot / 2f
            val bx = (cx - boxW / 2f).coerceIn(0f, (plotW - boxW).coerceAtLeast(0f))
            drawRoundRect(AppColors.CardAlt, Offset(bx, 0f), Size(boxW, boxH), CornerRadius(8.dp.toPx()))
            drawText(layout, topLeft = Offset(bx + pad, pad))
        }
    }
}
