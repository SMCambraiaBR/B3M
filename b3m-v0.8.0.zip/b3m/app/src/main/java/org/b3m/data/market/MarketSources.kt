package org.b3m.data.market

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import okhttp3.OkHttpClient
import org.b3m.data.AsyncCache
import org.b3m.data.fundamentus.FundamentusApi
import org.b3m.data.quotes.MarketListSource
import org.b3m.data.quotes.QuoteSource
import org.b3m.data.quotes.getString
import org.b3m.data.safely
import org.b3m.domain.Quote

/**
 * Busca e destaques do dia pela listagem da brapi.dev (precisa do token gratuito, informado
 * em Ajustes). Uma única consulta traz os ativos mais negociados e as três listas (altas,
 * quedas, mais negociadas) saem dela, em vez de uma consulta por lista a cada 30 s.
 * Por isso "maiores altas/quedas" são entre os ~120 ativos mais negociados, o que também
 * evita que papéis sem liquidez dominem as listas.
 */
class BrapiMarketSource(
    private val http: OkHttpClient,
    private val token: () -> String,
) : MarketListSource {

    private val json = Json { ignoreUnknownKeys = true }
    private val fractional = Regex("\\d+F$") // ex.: EMBJ3F (mercado fracionário)
    private val universeCache = AsyncCache<List<Quote>>(30_000)

    private suspend fun list(query: String, limit: Int, keepFractional: Boolean = false): List<Quote> {
        val tk = token().trim()
        if (tk.isEmpty()) error("brapi: sem token (veja Ajustes)")
        val url = "https://brapi.dev/api/quote/list?$query&limit=${limit + 10}&token=$tk"
        val body = http.getString(url)
        return withContext(Dispatchers.Default) {
            val root = json.parseToJsonElement(body).jsonObject
            val arr = root["stocks"] as? JsonArray ?: error("brapi: listagem indisponível")
            arr.mapNotNull { e ->
                val o = e as? JsonObject ?: return@mapNotNull null
                val ticker = (o["stock"] as? JsonPrimitive)?.content ?: return@mapNotNull null
                if (!keepFractional && fractional.containsMatchIn(ticker)) return@mapNotNull null
                val price = (o["close"] as? JsonPrimitive)?.doubleOrNull?.takeIf { it > 0.0 } ?: return@mapNotNull null
                Quote(
                    ticker = ticker.uppercase(),
                    price = price,
                    changePct = (o["change"] as? JsonPrimitive)?.doubleOrNull ?: 0.0,
                    volume = (o["volume"] as? JsonPrimitive)?.doubleOrNull,
                    name = (o["name"] as? JsonPrimitive)?.content,
                )
            }.take(limit)
        }
    }

    private suspend fun universe(): List<Quote> = universeCache.get("mais-negociadas") {
        list("sortBy=volume&sortOrder=desc&type=stock", 120).also { check(it.isNotEmpty()) { "brapi: lista vazia" } }
    }

    override suspend fun search(prefix: String): List<Quote> =
        list("search=${prefix.trim()}&sortBy=volume&sortOrder=desc", 12, keepFractional = true)

    override suspend fun topGainers(limit: Int) = universe().sortedByDescending { it.changePct }.take(limit)
    override suspend fun topLosers(limit: Int) = universe().sortedBy { it.changePct }.take(limit)
    override suspend fun mostTraded(limit: Int) = universe().take(limit)
    override fun invalidate() = universeCache.invalidateAll()
}

/**
 * Reserva sem token: usa a tabela geral do Fundamentus (liquidez) para escolher os ~40
 * papéis mais negociados e pede a cotação deles às fontes de cotação do app. Dali saem
 * a busca (com variação do dia real) e as três listas de destaques.
 */
class FundamentusMarketSource(
    private val fundamentus: FundamentusApi,
    private val quotes: QuoteSource,
    private val universeSize: Int = 40,
) : MarketListSource {

    private val universeCache = AsyncCache<List<Quote>>(60_000)

    private suspend fun universe(): List<Quote> = universeCache.get("liquidos") {
        val tickers = fundamentus.resultado().sortedByDescending { it.liquidity }.take(universeSize).map { it.ticker }
        val order = tickers.withIndex().associate { it.value to it.index }
        val list = quotes.quotes(tickers).sortedBy { order[it.ticker.uppercase()] ?: Int.MAX_VALUE }
        check(list.isNotEmpty()) { "Sem cotações para montar os destaques" }
        list
    }

    override suspend fun search(prefix: String): List<Quote> {
        val p = prefix.trim().uppercase()
        if (p.isEmpty()) return emptyList()
        val rows = fundamentus.resultado()
            .filter { it.ticker.startsWith(p) }
            .sortedByDescending { it.liquidity }
            .take(12)
        val live = safely { quotes.quotes(rows.map { it.ticker }) }.getOrNull().orEmpty().associateBy { it.ticker.uppercase() }
        return rows.map { live[it.ticker] ?: Quote(it.ticker, it.price, 0.0) }
    }

    override suspend fun topGainers(limit: Int) = universe().sortedByDescending { it.changePct }.take(limit)
    override suspend fun topLosers(limit: Int) = universe().sortedBy { it.changePct }.take(limit)
    override suspend fun mostTraded(limit: Int) = universe().take(limit)
    override fun invalidate() = universeCache.invalidateAll()
}

/** Tenta as fontes na ordem; a primeira que responder vale. */
class FallbackMarketSource(private val sources: List<MarketListSource>) : MarketListSource {
    private suspend fun <T> first(block: suspend (MarketListSource) -> T): T {
        var last: Throwable? = null
        for (s in sources) {
            try {
                return block(s)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Sem fontes de mercado")
    }

    override suspend fun search(prefix: String) = first { it.search(prefix) }
    override suspend fun topGainers(limit: Int) = first { it.topGainers(limit) }
    override suspend fun topLosers(limit: Int) = first { it.topLosers(limit) }
    override suspend fun mostTraded(limit: Int) = first { it.mostTraded(limit) }
    override fun invalidate() = sources.forEach { it.invalidate() }
}
