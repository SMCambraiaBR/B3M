package org.b3m.data.settings

import kotlinx.coroutines.flow.StateFlow
import org.b3m.domain.TaxRates

/** O que a tela de Ajustes lê e grava. [AppSettings] guarda no aparelho; os testes usam uma versão em memória. */
interface SettingsStore {
    val taxRates: StateFlow<TaxRates>
    fun setTaxRates(rates: TaxRates)

    /** Token/chave digitados em Ajustes (vazio se não houver). */
    val savedBrapiToken: String
    val savedHgKey: String
    fun setKeys(brapi: String, hg: String)
}
