package org.b3m.data.market

import java.time.LocalDate
import kotlinx.serialization.Serializable
import org.b3m.domain.Provento
import org.b3m.domain.RetornoResult
import org.b3m.domain.ReturnCalculator
import org.b3m.domain.TaxRates

/**
 * Candidato do ranking: guarda os PROVENTOS (brutos) e não o resultado pronto, então o
 * Retorno é calculado na hora com as alíquotas de imposto atuais (Ajustes).
 */
@Serializable
data class DividendRank(
    val ticker: String,
    val price: Double,
    val dividendYield: Double, // % dos últimos 12 meses, como o Fundamentus informa
    val proventos: List<Provento>,
) {
    fun result(taxes: TaxRates, today: LocalDate = LocalDate.now()): RetornoResult =
        ReturnCalculator.calculate(proventos, price, today, taxes)
}

/** De onde vem a lista de candidatos do ranking (o Fundamentus no app; um dado de mentira nos testes). */
fun interface RankingSource {
    suspend fun load(): List<DividendRank>
}

enum class DividendSort { RETORNO, PERCENT }

/** Ordena pelo Retorno (R$/ação/mês) ou % Retorno, líquidos de imposto; só entra quem teve provento. */
fun List<DividendRank>.rankedBy(
    sort: DividendSort,
    taxes: TaxRates,
    today: LocalDate = LocalDate.now(),
    limit: Int = 9,
): List<DividendRank> {
    val scored = map { it to it.result(taxes, today) }.filter { it.second.retorno > 0 }
    return when (sort) {
        DividendSort.RETORNO -> scored.sortedByDescending { it.second.retorno }
        DividendSort.PERCENT -> scored.sortedByDescending { it.second.percentRetorno }
    }.take(limit).map { it.first }
}
