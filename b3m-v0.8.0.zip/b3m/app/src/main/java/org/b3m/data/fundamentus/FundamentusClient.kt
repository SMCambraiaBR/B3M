package org.b3m.data.fundamentus

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import org.b3m.data.AsyncCache
import org.b3m.data.quotes.getString
import org.b3m.domain.Provento
import org.b3m.domain.ProventoTipo
import org.jsoup.Jsoup

/**
 * Cliente do Fundamentus (sem API oficial: lemos o HTML).
 *
 * ATENÇÃO: parsers escritos pela estrutura conhecida das páginas e AINDA NÃO validados
 * contra o site real. Se o layout mudar, só este arquivo precisa de ajuste.
 *  - detalhes.php?papel=TICKER             dados e indicadores
 *  - proventos.php?papel=TICKER&tipo=2     histórico de proventos
 *  - resultado.php                         todos os papéis (cotação, DY, liquidez)
 *
 * Os dados valem por pouco tempo na memória (2 min / 5 min / 15 min) e pedidos idênticos
 * simultâneos viram uma requisição só. As telas chamam [invalidate] ao abrir para buscar de novo.
 * O parsing roda fora da thread principal.
 */
class FundamentusClient(private val http: OkHttpClient) : FundamentusApi {

    private val base = "https://www.fundamentus.com.br"
    private val detalhesCache = AsyncCache<Detalhes>(2 * 60_000L)
    private val proventosCache = AsyncCache<List<Provento>>(5 * 60_000L)
    private val resultadoCache = AsyncCache<List<ResultadoRow>>(15 * 60_000L)

    override fun invalidate(ticker: String) {
        val key = ticker.trim().uppercase()
        detalhesCache.invalidate(key)
        proventosCache.invalidate(key)
    }

    override fun invalidateAll() {
        detalhesCache.invalidateAll()
        proventosCache.invalidateAll()
        resultadoCache.invalidateAll()
    }

    override suspend fun detalhes(ticker: String): Detalhes {
        val key = ticker.trim().uppercase()
        return detalhesCache.get(key) {
            val html = http.getString("$base/detalhes.php?papel=$key")
            withContext(Dispatchers.Default) { parseDetalhes(html, key) }
        }
    }

    private fun parseDetalhes(html: String, ticker: String): Detalhes {
        val doc = Jsoup.parse(html)
        val sections = ArrayList<DetalhesSection>()
        var title = "Geral"
        var items = ArrayList<Pair<String, String>>()
        fun flush() {
            if (items.isNotEmpty()) sections += DetalhesSection(title, items)
            items = ArrayList()
        }
        doc.select("table.w728 tr").forEach { row ->
            val cells = row.select("td")
            val header = cells.firstOrNull { it.hasClass("nivel1") }
            if (header != null) {
                flush()
                title = header.text().trim()
                return@forEach
            }
            var i = 0
            while (i + 1 < cells.size) {
                if (cells[i].hasClass("label")) {
                    val label = cells[i].select("span.txt").lastOrNull()?.text()?.trim().orEmpty()
                    val value = cells[i + 1].text().trim()
                    if (label.isNotEmpty() && label != "?") items += label to value
                    i += 2
                } else {
                    i += 1
                }
            }
        }
        flush()
        check(sections.isNotEmpty()) { "Fundamentus: papel $ticker não encontrado" }
        return Detalhes(sections)
    }

    override suspend fun proventos(ticker: String): List<Provento> {
        val key = ticker.trim().uppercase()
        return proventosCache.get(key) {
            val html = http.getString("$base/proventos.php?papel=$key&tipo=2")
            withContext(Dispatchers.Default) { parseProventos(html, key) }
        }
    }

    private fun parseProventos(html: String, ticker: String): List<Provento> {
        val doc = Jsoup.parse(html)
        val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        return doc.select("table#resultado tbody tr").mapNotNull { tr ->
            val td = tr.select("td")
            if (td.size < 4) return@mapNotNull null
            runCatching {
                val per = td.getOrNull(4)?.text()?.let { parseBR(it) }?.takeIf { it > 0 } ?: 1.0
                Provento(
                    ticker = ticker,
                    tipo = when (td[2].text().trim().uppercase()) {
                        "JRS CAP PROPRIO", "JCP" -> ProventoTipo.JCP
                        "RENDIMENTO" -> ProventoTipo.RENDIMENTO
                        else -> ProventoTipo.DIVIDENDO
                    },
                    dataPagamento = LocalDate.parse(td[3].text().trim(), fmt),
                    valorBruto = parseBR(td[1].text())!! / per,
                    dataCom = runCatching { LocalDate.parse(td[0].text().trim(), fmt) }.getOrNull(),
                )
            }.getOrNull()
        }
    }

    /** Todos os papéis com cotação, dividend yield e liquidez. */
    override suspend fun resultado(): List<ResultadoRow> = resultadoCache.get("all") {
        val html = http.getString("$base/resultado.php")
        withContext(Dispatchers.Default) { parseResultado(html) }
    }

    private fun parseResultado(html: String): List<ResultadoRow> {
        val doc = Jsoup.parse(html)
        val heads = doc.select("table#resultado thead th").map { it.text().lowercase().replace(" ", "") }
        val iPapel = heads.indexOfFirst { it.startsWith("papel") }
        val iCot = heads.indexOfFirst { it.startsWith("cota") }
        val iDy = heads.indexOfFirst { it.startsWith("div") }
        val iLiq = heads.indexOfFirst { it.startsWith("liq.2") }
        check(iPapel >= 0 && iCot >= 0 && iDy >= 0) { "Fundamentus: layout de resultado.php mudou" }
        return doc.select("table#resultado tbody tr").mapNotNull { tr ->
            val td = tr.select("td")
            val price = td.getOrNull(iCot)?.text()?.let { parseBR(it) } ?: return@mapNotNull null
            ResultadoRow(
                ticker = td.getOrNull(iPapel)?.text()?.trim()?.uppercase() ?: return@mapNotNull null,
                price = price,
                dividendYield = td.getOrNull(iDy)?.text()?.let { parseBR(it) } ?: 0.0,
                liquidity = if (iLiq >= 0) td.getOrNull(iLiq)?.text()?.let { parseBR(it) } ?: 0.0 else 0.0,
            )
        }
    }
}
