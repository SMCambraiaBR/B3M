package org.b3m.domain

import java.time.LocalDate
import java.time.YearMonth

/** Um provento efetivamente recebido: o que a empresa pagou ([gross]) e o que sobrou após o imposto ([net]). */
data class IncomeEvent(
    val ticker: String,
    val tipo: ProventoTipo,
    val date: LocalDate, // data de pagamento
    val gross: Double,
    val net: Double,
) {
    val tax: Double get() = gross - net
}

data class MonthValue(val month: YearMonth, val value: Double)

object DividendCalculator {

    /** Quantidade em carteira ao fim de [date] (compras e vendas até o dia, inclusive). */
    fun quantityAt(lancamentos: List<Lancamento>, date: LocalDate): Double {
        val q = lancamentos.filter { !it.data.isAfter(date) }
            .sumOf { if (it.tipo == LancamentoTipo.COMPRA) it.quantidade else -it.quantidade }
        return if (q < QTY_EPS) 0.0 else q
    }

    /**
     * Proventos que o usuário recebeu de UM ativo: quantidade que tinha na data com × valor por
     * ação, só dos já pagos até [today]. (Sem data com, usa a data de pagamento.)
     * [lancamentos] deve conter só lançamentos do ativo.
     */
    fun events(
        lancamentos: List<Lancamento>,
        proventos: List<Provento>,
        today: LocalDate = LocalDate.now(),
        taxes: TaxRates = TaxRates(),
    ): List<IncomeEvent> = proventos
        .filter { !it.dataPagamento.isAfter(today) }
        .mapNotNull { p ->
            val qty = quantityAt(lancamentos, p.dataCom ?: p.dataPagamento)
            if (qty <= QTY_EPS) null
            else IncomeEvent(p.ticker, p.tipo, p.dataPagamento, qty * p.valorBruto, qty * ReturnCalculator.net(p, taxes))
        }
        .sortedBy { it.date }

    /** Igual a [events], para vários ativos de uma vez (proventos indexados pelo código). */
    fun eventsAll(
        lancamentos: List<Lancamento>,
        proventos: Map<String, List<Provento>>,
        today: LocalDate = LocalDate.now(),
        taxes: TaxRates = TaxRates(),
    ): List<IncomeEvent> {
        val byTicker = lancamentos.groupBy { it.ticker.uppercase() }
        return proventos.flatMap { (ticker, list) ->
            events(byTicker[ticker.uppercase()].orEmpty(), list, today, taxes)
        }.sortedBy { it.date }
    }

    /** Total líquido de imposto recebido de um ativo. */
    fun received(
        lancamentos: List<Lancamento>,
        proventos: List<Provento>,
        today: LocalDate = LocalDate.now(),
        taxes: TaxRates = TaxRates(),
    ): Double = events(lancamentos, proventos, today, taxes).sumOf { it.net }
}

object IncomeMath {

    /** Soma por mês dos últimos [months] meses (o mês de [today] é o último); meses sem valor vêm com 0. */
    fun monthly(items: List<Pair<LocalDate, Double>>, today: LocalDate = LocalDate.now(), months: Int = 12): List<MonthValue> {
        val end = YearMonth.from(today)
        val start = end.minusMonths((months - 1).toLong())
        val sums = items.groupBy { YearMonth.from(it.first) }.mapValues { (_, v) -> v.sumOf { it.second } }
        return (0 until months).map { i ->
            val m = start.plusMonths(i.toLong())
            MonthValue(m, sums[m] ?: 0.0)
        }
    }

    /** Média mensal dos últimos [n] meses da lista (total ÷ n). */
    fun average(values: List<MonthValue>, n: Int = 6): Double =
        if (values.isEmpty()) 0.0 else values.takeLast(n).sumOf { it.value } / n
}
