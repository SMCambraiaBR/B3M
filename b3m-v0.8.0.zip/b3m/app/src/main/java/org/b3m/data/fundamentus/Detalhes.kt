package org.b3m.data.fundamentus

import kotlinx.serialization.Serializable
import org.b3m.domain.Provento

@Serializable
data class DetalhesSection(val title: String, val items: List<Pair<String, String>>)

/** Um dos indicadores da tela do ativo, com o nome por extenso e uma explicação curta. */
data class Indicador(val short: String, val source: String, val name: String, val hint: String)

val INDICADORES_PRINCIPAIS = listOf(
    Indicador("D.Y", "Div. Yield", "Dividend Yield", "Proventos dos últimos 12 meses ÷ preço da ação."),
    Indicador("P/L", "P/L", "Preço / Lucro", "Quantos anos de lucro o preço atual paga. Menor tende a ser mais barato."),
    Indicador("ROE", "ROE", "Retorno sobre o patrimônio", "Lucro líquido ÷ patrimônio líquido: rentabilidade para o acionista."),
    Indicador("ROIC", "ROIC", "Retorno sobre o capital investido", "Lucro operacional após impostos ÷ capital investido."),
    Indicador("VPA", "VPA", "Valor patrimonial por ação", "Patrimônio líquido ÷ número de ações."),
    Indicador("LPA", "LPA", "Lucro por ação", "Lucro líquido ÷ número de ações."),
    Indicador("P/VP", "P/VP", "Preço / Valor patrimonial", "Preço ÷ VPA. Abaixo de 1: negocia abaixo do patrimônio."),
    Indicador("M. EBIT", "Marg. EBIT", "Margem EBIT", "Lucro operacional ÷ receita líquida."),
)

/** Página de detalhes de um papel, organizada por seção do site. */
@Serializable
data class Detalhes(val sections: List<DetalhesSection>) {
    /** Valor de um rótulo; se o rótulo aparece em mais de uma seção, a 1ª ocorrência vence. */
    operator fun get(label: String): String? =
        sections.firstNotNullOfOrNull { s -> s.items.firstOrNull { it.first == label }?.second }

    val empresa: String? get() = this["Empresa"]
    val setor: String? get() = this["Setor"]
    val subsetor: String? get() = this["Subsetor"]

    /** Os 8 indicadores da tela do ativo, na ordem exibida (só os que o site trouxe). */
    fun indicadoresPrincipais(): List<Pair<Indicador, String>> =
        INDICADORES_PRINCIPAIS.mapNotNull { ind -> this[ind.source]?.let { ind to it } }
}

/** Linha da tabela geral do Fundamentus (todos os papéis). */
data class ResultadoRow(
    val ticker: String,
    val price: Double,
    val dividendYield: Double, // em %
    val liquidity: Double,     // volume médio 2 meses, R$
)

fun parseBR(text: String): Double? =
    text.trim().removeSuffix("%").trim().replace(".", "").replace(',', '.').toDoubleOrNull()

/**
 * O que as telas precisam do Fundamentus. Existe como interface para as telas (ViewModels)
 * poderem ser testadas com um dado de mentira, sem rede.
 */
interface FundamentusApi {
    suspend fun detalhes(ticker: String): Detalhes
    suspend fun proventos(ticker: String): List<Provento>
    suspend fun resultado(): List<ResultadoRow>

    /** Esquece os dados deste papel: o próximo pedido vai ao site. */
    fun invalidate(ticker: String)

    /** Esquece tudo (inclusive a tabela geral usada no ranking de dividendos). */
    fun invalidateAll()
}
