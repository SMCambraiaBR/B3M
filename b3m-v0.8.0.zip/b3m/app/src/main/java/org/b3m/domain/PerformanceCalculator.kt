package org.b3m.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import org.b3m.data.quotes.ChartPoint

/** Retrato da carteira em um instante: patrimônio, valor investido e fluxos do período. */
data class PortfolioPoint(
    val epochMillis: Long,
    val value: Double,    // patrimônio ao preço de fechamento
    val invested: Double, // custo (preço médio × quantidade)
    val flow: Double,     // compras − vendas desde o ponto anterior
    val income: Double = 0.0, // proventos líquidos recebidos desde o ponto anterior
)

object PerformanceCalculator {

    private class Holding(var qty: Double = 0.0, var avg: Double = 0.0)

    /**
     * Reconstrói a carteira ao longo do tempo com os lançamentos e os preços históricos.
     * Antes do primeiro preço de um ativo usa-se o primeiro preço disponível; entre
     * pontos repete-se o último preço conhecido. [income] são os proventos líquidos já
     * recebidos: entram como retorno na data de pagamento.
     *
     * Percorre lançamentos e proventos uma única vez (custo linear), em vez de recalcular a
     * carteira inteira a cada ponto do gráfico.
     */
    fun series(
        lancamentos: List<Lancamento>,
        closes: Map<String, List<ChartPoint>>,
        income: List<IncomeEvent> = emptyList(),
        zone: ZoneId = ZoneId.systemDefault(),
    ): List<PortfolioPoint> {
        val timeline = closes.values.flatten().map { it.epochMillis }.distinct().sorted()
        if (timeline.isEmpty()) return emptyList()
        val sorted = lancamentos.sortedWith(compareBy({ it.data }, { it.id }))
        val incomes = income.sortedBy { it.date }
        fun dateOf(t: Long): LocalDate = Instant.ofEpochMilli(t).atZone(zone).toLocalDate()

        val holdings = LinkedHashMap<String, Holding>()
        var li = 0
        var ii = 0
        val out = ArrayList<PortfolioPoint>(timeline.size)
        timeline.forEachIndexed { i, t ->
            val date = dateOf(t)
            var flow = 0.0
            while (li < sorted.size && !sorted[li].data.isAfter(date)) {
                val l = sorted[li++]
                val h = holdings.getOrPut(l.ticker.uppercase()) { Holding() }
                if (l.tipo == LancamentoTipo.COMPRA) {
                    val total = h.qty * h.avg + l.quantidade * l.preco
                    h.qty += l.quantidade
                    h.avg = if (h.qty > 0) total / h.qty else 0.0
                    if (i > 0) flow += l.quantidade * l.preco
                } else {
                    h.qty -= l.quantidade
                    if (h.qty < QTY_EPS) {
                        h.qty = 0.0
                        h.avg = 0.0
                    }
                    if (i > 0) flow -= l.quantidade * l.preco
                }
            }
            var inc = 0.0
            while (ii < incomes.size && !incomes[ii].date.isAfter(date)) {
                if (i > 0) inc += incomes[ii].net
                ii++
            }
            var value = 0.0
            var invested = 0.0
            for ((ticker, h) in holdings) {
                if (h.qty <= QTY_EPS) continue
                val s = closes[ticker].orEmpty()
                val price = SeriesMath.lastAtOrBefore(s, t)?.value ?: s.firstOrNull()?.value ?: h.avg
                value += h.qty * price
                invested += h.qty * h.avg
            }
            out += PortfolioPoint(t, value, invested, flow, inc)
        }
        return out
    }

    /**
     * Rentabilidade ponderada pelo tempo (%), que não é distorcida por aportes e resgates.
     * Os proventos recebidos contam como retorno (dinheiro que saiu da carteira, mas é ganho).
     */
    fun twr(points: List<PortfolioPoint>): List<ChartPoint> {
        if (points.isEmpty()) return emptyList()
        var cum = 1.0
        val out = ArrayList<ChartPoint>(points.size)
        out += ChartPoint(points[0].epochMillis, 0.0)
        for (i in 1 until points.size) {
            val prev = points[i - 1].value
            val r = if (prev > 0) (points[i].value - points[i].flow + points[i].income) / prev - 1.0 else 0.0
            cum *= 1.0 + r
            out += ChartPoint(points[i].epochMillis, (cum - 1.0) * 100.0)
        }
        return out
    }
}
