package org.b3m.domain

import java.math.BigDecimal
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * Exportação/importação dos lançamentos em CSV (separador ";", ponto decimal, data ISO), para
 * backup e para trocar de aparelho. Exemplo:
 *
 *     ticker;tipo;quantidade;preco;data
 *     PETR4;COMPRA;100;35.5;2026-01-10
 */
object LancamentoCsv {

    const val HEADER = "ticker;tipo;quantidade;preco;data"

    data class Parsed(val items: List<Lancamento>, val errors: List<String>)

    private val brDate = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    fun encode(list: List<Lancamento>): String {
        val rows = list.sortedWith(compareBy({ it.data }, { it.id })).map { l ->
            listOf(l.ticker.uppercase(), l.tipo.name, plain(l.quantidade), plain(l.preco), l.data.toString())
                .joinToString(";")
        }
        return (listOf(HEADER) + rows).joinToString("\n") + "\n"
    }

    fun decode(text: String, today: LocalDate = LocalDate.now()): Parsed {
        val items = ArrayList<Lancamento>()
        val errors = ArrayList<String>()
        text.removePrefix("﻿").lines().forEachIndexed { index, raw ->
            val line = raw.trim()
            if (line.isEmpty()) return@forEachIndexed
            val sep = if (line.contains(';')) ';' else ','
            val f = line.split(sep).map { it.trim() }
            if (index == 0 && f.firstOrNull()?.lowercase() == "ticker") return@forEachIndexed
            val n = index + 1
            if (f.size != 5) {
                errors += "Linha $n: esperado 5 colunas (ticker;tipo;quantidade;preco;data)."
                return@forEachIndexed
            }
            val tipo = when (f[1].uppercase()) {
                "COMPRA", "C" -> LancamentoTipo.COMPRA
                "VENDA", "V" -> LancamentoTipo.VENDA
                else -> {
                    errors += "Linha $n: tipo \"${f[1]}\" inválido (use COMPRA ou VENDA)."
                    return@forEachIndexed
                }
            }
            val qty = parsePlainNumber(f[2])
            val price = parsePlainNumber(f[3])
            val date = parseDate(f[4])
            if (qty == null || price == null || date == null) {
                errors += "Linha $n: quantidade, preço ou data inválidos."
                return@forEachIndexed
            }
            val l = Lancamento(ticker = TickerRules.normalize(f[0]), tipo = tipo, quantidade = qty, preco = price, data = date)
            val problem = LancamentoValidator.validateFields(l, today)
            if (problem != null) errors += "Linha $n: $problem" else items += l
        }
        return Parsed(items, errors)
    }

    private fun parseDate(s: String): LocalDate? =
        runCatching { LocalDate.parse(s) }.getOrNull() ?: runCatching { LocalDate.parse(s, brDate) }.getOrNull()

    private fun plain(d: Double): String = BigDecimal.valueOf(d).stripTrailingZeros().toPlainString()
}
