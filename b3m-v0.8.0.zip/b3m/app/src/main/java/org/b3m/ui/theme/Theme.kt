package org.b3m.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Regra do projeto: verde = positivo, vermelho = negativo, em TODA a interface. */
object AppColors {
    val Positive = Color(0xFF2EE59D)
    val Negative = Color(0xFFFF5A5F)
    val Neutral = Color(0xFF9A9A9A)
    val Warning = Color(0xFFFFB74D) // dado desatualizado / aviso
    val Background = Color(0xFF000000)
    val Card = Color(0xFF161616)
    val CardAlt = Color(0xFF262626)

    fun forChange(value: Double): Color = when {
        value > 0 -> Positive
        value < 0 -> Negative
        else -> Neutral
    }
}

private val Dark = darkColorScheme(
    background = AppColors.Background,
    surface = AppColors.Card,
    primary = AppColors.Positive,
    onBackground = Color.White,
    onSurface = Color.White,
)

@Composable
fun B3MTheme(content: @Composable () -> Unit) {
    // O app é escuro como nas telas de referência, independente do tema do sistema.
    MaterialTheme(colorScheme = Dark, content = content)
}
