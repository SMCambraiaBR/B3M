package org.b3m.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import org.b3m.AppGraph
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.Symbols
import org.b3m.domain.TaxRates
import org.b3m.ui.arrowPct
import org.b3m.ui.brl
import org.b3m.ui.formatCollected
import org.b3m.ui.theme.AppColors

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(AppColors.Card)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(16.dp),
        content = content,
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = modifier)
}

@Composable
fun ErrorLine(message: String, onRetry: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(message, color = AppColors.Neutral, fontSize = 13.sp, modifier = Modifier.weight(1f))
        if (onRetry != null) TextButton(onClick = onRetry) { Text("Tentar de novo") }
    }
}

/** Logo da empresa (SVG da brapi); se não carregar, mostra as iniciais do código. */
@Composable
fun CompanyLogo(ticker: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(10.dp)
    SubcomposeAsyncImage(
        model = Symbols.logoUrl(ticker),
        contentDescription = ticker,
        imageLoader = AppGraph.imageLoader(ctx),
        contentScale = ContentScale.Fit,
        modifier = Modifier.size(size).clip(shape).background(Color.White),
        loading = { Initials(ticker, size) },
        error = { Initials(ticker, size) },
    )
}

@Composable
private fun Initials(ticker: String, size: Dp) {
    Box(
        Modifier.size(size).background(AppColors.CardAlt),
        contentAlignment = Alignment.Center,
    ) {
        Text(ticker.removePrefix("^").take(2), fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

/** Linha de ativo: logo, código, descrição, preço e variação (verde/vermelho). */
@Composable
fun QuoteRow(
    ticker: String,
    subtitle: String?,
    price: Double,
    changePct: Double,
    onClick: () -> Unit,
) {
    AppCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            CompanyLogo(ticker)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(ticker, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, color = AppColors.Neutral, fontSize = 13.sp, maxLines = 1)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(price.brl(), fontWeight = FontWeight.Bold)
                Text(changePct.arrowPct(), color = AppColors.forChange(changePct), fontSize = 13.sp)
            }
        }
    }
}

/** Seletor de período usado por todo gráfico do app. */
@Composable
fun RangeSelector(
    selected: ChartRange,
    onSelect: (ChartRange) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        ChartRange.entries.forEach { r ->
            val sel = r == selected
            Box(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (sel) Color.White else Color.Transparent)
                    .clickable { onSelect(r) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(r.label, color = if (sel) Color.Black else AppColors.Neutral, fontSize = 14.sp)
            }
        }
    }
}

/** Fileira de opções (abas ou filtros) com a selecionada em destaque. */
@Composable
fun <T> ChipRow(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { o ->
            val sel = o == selected
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (sel) Color.White else AppColors.Card)
                    .clickable { onSelect(o) }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(label(o), color = if (sel) Color.Black else Color.White, fontSize = 14.sp)
            }
        }
    }
}

/** Fileira de opções com seleção múltipla (ex.: comparativos do gráfico). */
@Composable
fun <T> ToggleChips(
    options: List<T>,
    selected: Set<T>,
    label: (T) -> String,
    color: (T) -> Color,
    onToggle: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { o ->
            val on = o in selected
            Row(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (on) AppColors.CardAlt else AppColors.Card)
                    .clickable { onToggle(o) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(if (on) color(o) else AppColors.Neutral))
                Text(label(o), Modifier.padding(start = 8.dp), color = if (on) Color.White else AppColors.Neutral, fontSize = 14.sp)
            }
        }
    }
}

/** Par rótulo/valor em duas colunas, como o "Resumo" das telas de referência. */
@Composable
fun StatGrid(items: List<Pair<String, String>>, valueColors: Map<String, Color> = emptyMap()) {
    items.chunked(2).forEach { pair ->
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            pair.forEach { (label, value) ->
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(label, color = AppColors.Neutral, fontSize = 14.sp)
                    Text(value, fontWeight = FontWeight.Medium, color = valueColors[label] ?: Color.White)
                }
            }
            if (pair.size == 1) Box(Modifier.weight(1f)) {}
        }
    }
}


/** Estado vazio amigável (carteira sem ativos, busca sem resultado, etc.). */
@Composable
fun EmptyState(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = AppColors.Neutral)
        if (subtitle != null) {
            Text(
                subtitle,
                fontSize = 14.sp,
                color = AppColors.Neutral.copy(alpha = 0.8f),
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}

/**
 * Quando o dado foi coletado. Normal: "Atualizado hoje às 14:32:10". Se a coleta nova falhou
 * ([stale]): aviso em destaque com a data e a hora do último dado coletado.
 */
@Composable
fun UpdatedLine(
    updatedAt: Long?,
    stale: Boolean,
    modifier: Modifier = Modifier,
    onlyWhenStale: Boolean = false,
) {
    if (updatedAt == null) return
    if (onlyWhenStale && !stale) return
    val whenText = formatCollected(updatedAt)
    if (stale) {
        Text(
            "Sem atualização agora. Último dado coletado $whenText.",
            color = AppColors.Warning, fontSize = 12.sp, modifier = modifier,
        )
    } else {
        Text("Atualizado $whenText", color = AppColors.Neutral, fontSize = 11.sp, modifier = modifier)
    }
}

/** Aviso fixo de que os valores mostrados já estão líquidos de imposto, com a alíquota de cada tipo. */
@Composable
fun TaxNote(taxes: TaxRates, modifier: Modifier = Modifier) {
    Text(
        "Valores líquidos: imposto já descontado (${taxes.summary()}). Altere em Ajustes.",
        color = AppColors.Neutral, fontSize = 12.sp, modifier = modifier,
    )
}

/** Linha "rótulo ........ valor", com uma observação opcional embaixo do rótulo. */
@Composable
fun InfoRow(
    label: String,
    value: String,
    color: Color = Color.White,
    note: String? = null,
    noteColor: Color = AppColors.Neutral,
) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label, color = AppColors.Neutral)
            if (note != null) Text(note, color = noteColor, fontSize = 11.sp)
        }
        Text(value, color = color, fontWeight = FontWeight.Medium)
    }
}

/** Aviso em destaque (cor de atenção), para dados que faltam ou estão antigos. */
@Composable
fun WarningLine(text: String, modifier: Modifier = Modifier) {
    Text(text, color = AppColors.Warning, fontSize = 12.sp, modifier = modifier)
}
