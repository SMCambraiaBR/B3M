package org.b3m.data.snapshot

import org.b3m.data.fundamentus.Detalhes
import org.b3m.data.market.DividendRank
import org.b3m.data.quotes.ChartPoint
import org.b3m.domain.Provento
import org.b3m.domain.Quote

/** Todos os formatos de dado que ficam guardados em disco. [Codecs] é a versão real (JSON). */
interface DataCodecs {
    val quote: Codec<Quote>
    val quotes: Codec<List<Quote>>
    val chart: Codec<List<ChartPoint>>
    val proventos: Codec<List<Provento>>
    val detalhes: Codec<Detalhes>
    val ranking: Codec<List<DividendRank>>
}
