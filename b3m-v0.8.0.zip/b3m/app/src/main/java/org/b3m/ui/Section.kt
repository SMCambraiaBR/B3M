package org.b3m.ui

import org.b3m.data.snapshot.Stamped

/**
 * Um bloco de tela que carrega e falha por conta própria.
 *  - [updatedAt]: quando o dado mostrado foi coletado (a tela escreve "Atualizado hoje às ...").
 *  - [stale]: a coleta nova falhou e o que aparece é o último dado guardado (a tela avisa com a hora).
 *  - [error]: nunca houve dado para mostrar.
 */
data class Section<T>(
    val data: T? = null,
    val loading: Boolean = true,
    val error: String? = null,
    val updatedAt: Long? = null,
    val stale: Boolean = false,
) {
    /** A coleta falhou: mantém o que já havia na tela (marcado como desatualizado) e registra o aviso. */
    fun failed(message: String): Section<T> =
        if (data != null) copy(loading = false, stale = true, error = null)
        else copy(loading = false, error = message)
}

fun <T> Stamped<T>.toSection(): Section<T> = Section(value, loading = false, error = null, updatedAt = fetchedAt, stale = stale)
