package org.b3m.domain

import org.b3m.data.quotes.ChartPoint

object SeriesMath {

    /**
     * Acumula passos percentuais (ex.: CDI diário 0,05 = 0,05%) a partir de [startMs].
     * Retorna o ponto inicial (0%) seguido do acumulado depois de cada passo.
     */
    fun accumulate(startMs: Long, steps: List<Pair<Long, Double>>): List<ChartPoint> {
        var factor = 1.0
        val out = ArrayList<ChartPoint>(steps.size + 1)
        out += ChartPoint(startMs, 0.0)
        steps.sortedBy { it.first }.forEach { (t, pct) ->
            factor *= 1.0 + pct / 100.0
            out += ChartPoint(t, (factor - 1.0) * 100.0)
        }
        return out
    }

    /** Preços viram variação percentual desde o primeiro ponto. */
    fun rebasePct(points: List<ChartPoint>): List<ChartPoint> {
        val base = points.firstOrNull()?.value?.takeIf { it != 0.0 } ?: return emptyList()
        return points.map { ChartPoint(it.epochMillis, (it.value / base - 1.0) * 100.0) }
    }

    /** Último ponto com tempo <= [t] (a série precisa estar ordenada). */
    fun lastAtOrBefore(points: List<ChartPoint>, t: Long): ChartPoint? {
        var lo = 0
        var hi = points.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) / 2
            if (points[mid].epochMillis <= t) {
                ans = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        return if (ans >= 0) points[ans] else null
    }

    /** Valor da série em cada instante da linha do tempo (repete o último valor conhecido). */
    fun align(timeline: List<Long>, series: List<ChartPoint>): List<ChartPoint> =
        timeline.mapNotNull { t -> lastAtOrBefore(series, t)?.let { ChartPoint(t, it.value) } }
}
