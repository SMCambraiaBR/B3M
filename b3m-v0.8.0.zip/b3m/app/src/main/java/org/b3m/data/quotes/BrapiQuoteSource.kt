package org.b3m.data.quotes

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull
import okhttp3.OkHttpClient
import org.b3m.domain.Quote

/**
 * brapi.dev. Sem token só responde para alguns tickers de teste; com token
 * (gratuito, informado em Ajustes) atende todos. Se falhar, perde a corrida e outra fonte responde.
 * [token] é uma função para que mudar o token em Ajustes valha na hora, sem reiniciar o app.
 */
class BrapiQuoteSource(
    private val http: OkHttpClient,
    private val token: () -> String? = { null },
) : QuoteSource {

    private val json = Json { ignoreUnknownKeys = true }

    private fun url(tickers: String, extra: String = ""): String {
        val t = token()?.takeIf { it.isNotBlank() }?.let { "&token=$it" }.orEmpty()
        return "https://brapi.dev/api/quote/$tickers?${extra.removePrefix("&")}$t"
    }

    private suspend fun results(url: String): List<JsonObject> {
        val root = json.parseToJsonElement(http.getString(url)).jsonObject
        val arr = root["results"] as? JsonArray ?: error("brapi: resposta sem resultados")
        return arr.map { it.jsonObject }
    }

    private fun JsonObject.num(key: String): Double? = (this[key] as? JsonPrimitive)?.doubleOrNull

    private fun JsonObject.toQuote(): Quote? {
        val symbol = (this["symbol"] as? JsonPrimitive)?.content ?: return null
        val price = num("regularMarketPrice")?.takeIf { it > 0.0 } ?: return null
        return Quote(
            ticker = symbol,
            price = price,
            changePct = num("regularMarketChangePercent") ?: 0.0,
            open = num("regularMarketOpen"),
            high = num("regularMarketDayHigh"),
            low = num("regularMarketDayLow"),
            previousClose = num("regularMarketPreviousClose"),
            volume = num("regularMarketVolume"),
        )
    }

    override suspend fun quote(ticker: String): Quote =
        results(url(ticker.uppercase())).firstNotNullOfOrNull { it.toQuote() }
            ?: error("brapi: sem dados para $ticker")

    override suspend fun quotes(tickers: List<String>): List<Quote> =
        if (tickers.isEmpty()) emptyList()
        else results(url(tickers.joinToString(",") { it.uppercase() })).mapNotNull { it.toQuote() }

    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> {
        val r = results(url(ticker.uppercase(), "range=${range.range}&interval=${range.interval}"))
            .firstOrNull() ?: return emptyList()
        val hist = r["historicalDataPrice"] as? JsonArray ?: return emptyList()
        val points = hist.mapNotNull { e ->
            val o = e.jsonObject
            val date = (o["date"] as? JsonPrimitive)?.longOrNull ?: return@mapNotNull null
            val close = o.num("close") ?: return@mapNotNull null
            ChartPoint(date * 1000, close)
        }
        return range.trim(points)
    }
}
