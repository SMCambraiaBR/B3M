package org.b3m.data.quotes

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import okhttp3.OkHttpClient
import org.b3m.domain.Quote

/**
 * HG Brasil Finance (chave gratuita em hgbrasil.com). Só cotação; sem gráfico.
 * Parser baseado na documentação pública, ainda não validado com a API real.
 */
class HgBrasilQuoteSource(
    private val http: OkHttpClient,
    private val key: () -> String,
) : QuoteSource {

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun quotes(tickers: List<String>): List<Quote> {
        if (tickers.isEmpty()) return emptyList()
        val apiKey = key().trim()
        if (apiKey.isEmpty()) error("HG Brasil: sem chave (Ajustes)")
        val symbols = tickers.joinToString(",") { it.uppercase() }
        val url = "https://api.hgbrasil.com/finance/stock_price?key=$apiKey&symbol=$symbols"
        val results = json.parseToJsonElement(http.getString(url)).jsonObject["results"]?.jsonObject
            ?: error("HG Brasil: resposta sem resultados")
        return results.mapNotNull { (symbol, value) ->
            val o = value as? JsonObject ?: return@mapNotNull null
            if ((o["error"] as? JsonPrimitive)?.content == "true") return@mapNotNull null
            val price = (o["price"] as? JsonPrimitive)?.doubleOrNull?.takeIf { it > 0.0 } ?: return@mapNotNull null
            Quote(
                ticker = symbol.uppercase(),
                price = price,
                changePct = (o["change_percent"] as? JsonPrimitive)?.doubleOrNull ?: 0.0,
            )
        }
    }

    override suspend fun quote(ticker: String): Quote =
        quotes(listOf(ticker)).firstOrNull() ?: error("HG Brasil: sem dados para $ticker")

    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> =
        throw UnsupportedOperationException("HG Brasil não fornece histórico")
}
