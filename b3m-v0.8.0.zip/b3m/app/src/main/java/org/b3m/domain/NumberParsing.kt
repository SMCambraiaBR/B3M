package org.b3m.domain

private val THOUSANDS = Regex("^[1-9]\\d{0,2}(\\.\\d{3})+$")
private val PLAIN = Regex("^\\d+(\\.\\d+)?$")

/**
 * Número digitado no formato brasileiro.
 *  - "1.234,56" -> 1234.56      - "10,5" -> 10.5       - "35.5" -> 35.5
 *  - "1.000"    -> 1000 (ponto seguido de exatamente 3 dígitos é separador de milhar)
 * Devolve null para texto inválido, negativo ou ambíguo ("1,2,3", "1,234.56").
 */
fun parseBrNumber(text: String): Double? {
    val s = text.trim().removePrefix("R$").trim().replace(" ", "")
    if (s.isEmpty()) return null
    val normalized = when {
        s.contains(',') -> {
            if (s.count { it == ',' } > 1) return null
            if (s.contains('.') && s.indexOf('.') > s.indexOf(',')) return null
            s.replace(".", "").replace(',', '.')
        }
        THOUSANDS.matches(s) -> s.replace(".", "")
        else -> s
    }
    if (!PLAIN.matches(normalized)) return null
    return normalized.toDoubleOrNull()?.takeIf { it.isFinite() }
}

/** Número em formato "de máquina" (ponto decimal), como o do CSV; aceita vírgula decimal também. */
fun parsePlainNumber(text: String): Double? {
    val s = text.trim()
    if (s.contains(',')) return parseBrNumber(s)
    if (!PLAIN.matches(s)) return null
    return s.toDoubleOrNull()?.takeIf { it.isFinite() }
}
