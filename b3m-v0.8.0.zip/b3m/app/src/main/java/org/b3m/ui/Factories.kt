package org.b3m.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import org.b3m.AppGraph
import org.b3m.ui.asset.AssetViewModel
import org.b3m.ui.market.MarketViewModel
import org.b3m.ui.portfolio.PortfolioViewModel
import org.b3m.ui.settings.SettingsViewModel

/** Monta cada ViewModel com as dependências reais do app ([AppGraph]). */
object Factories {

    private fun factory(build: () -> ViewModel): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <V : ViewModel> create(modelClass: Class<V>): V = build() as V
    }

    val market: ViewModelProvider.Factory = factory {
        MarketViewModel(
            quotes = AppGraph.quoteRepo,
            market = AppGraph.market,
            ranking = AppGraph.dividends,
            fundamentus = AppGraph.fundamentus,
            snapshots = AppGraph.snapshots,
            codecs = AppGraph.codecs,
            watchlist = AppGraph.watchlist,
            taxes = AppGraph.taxRates,
        )
    }

    fun asset(ticker: String): ViewModelProvider.Factory = factory {
        AssetViewModel(
            ticker = ticker,
            quotes = AppGraph.quoteRepo,
            fundamentus = AppGraph.fundamentus,
            snapshots = AppGraph.snapshots,
            codecs = AppGraph.codecs,
            repo = AppGraph.lancamentos,
            watchlist = AppGraph.watchlist,
            taxes = AppGraph.taxRates,
        )
    }

    val portfolio: ViewModelProvider.Factory = factory {
        PortfolioViewModel(
            repository = AppGraph.lancamentos,
            quotes = AppGraph.quoteRepo,
            fundamentus = AppGraph.fundamentus,
            bcb = AppGraph.bcb,
            snapshots = AppGraph.snapshots,
            codecs = AppGraph.codecs,
            taxes = AppGraph.taxRates,
        )
    }

    val settings: ViewModelProvider.Factory = factory {
        SettingsViewModel(
            settings = AppGraph.settings,
            lancamentos = AppGraph.lancamentos,
            clearCaches = { AppGraph.clearCaches() },
        )
    }
}
