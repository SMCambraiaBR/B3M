package org.b3m.data.market

import java.time.LocalDate
import org.b3m.data.quotes.ChartPoint

/** Índices de referência para comparar com a carteira (CDI e IPCA). */
interface BenchmarkSource {
    /** CDI acumulado (%) desde [from]; começa em 0. */
    suspend fun cdiAccumulated(from: LocalDate): List<ChartPoint>

    /** IPCA acumulado (%) desde [from]; começa em 0. */
    suspend fun ipcaAccumulated(from: LocalDate): List<ChartPoint>
}
