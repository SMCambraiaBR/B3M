package org.b3m.domain

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LancamentoValidatorTest {

    private val today = LocalDate.parse("2026-10-28")

    private fun l(id: Long, t: String, tipo: LancamentoTipo, q: Double, d: String, p: Double = 10.0) =
        Lancamento(id, t, tipo, q, p, LocalDate.parse(d))

    @Test
    fun `codigos reais da B3 sao aceitos`() {
        listOf("PETR4", "VALE3", "B3SA3", "BOVA11", "IVVB11", "AAPL34", "M1TA34", "B5P211", "taee11").forEach {
            assertTrue("$it deveria ser válido", TickerRules.isValid(it))
        }
    }

    @Test
    fun `codigos invalidos sao recusados`() {
        listOf("", "PETR", "PETR444", "123456", "PET4", "PETR-4", "^BVSP").forEach {
            assertFalse("$it não deveria ser válido", TickerRules.isValid(it))
        }
    }

    @Test
    fun `venda acima da posicao e recusada com mensagem`() {
        val existing = listOf(l(1, "PETR4", LancamentoTipo.COMPRA, 10.0, "2026-01-10"))
        val msg = LancamentoValidator.validate(existing, l(0, "PETR4", LancamentoTipo.VENDA, 11.0, "2026-02-01"), today)
        assertNotNull(msg)
        assertTrue(msg!!.contains("PETR4"))
        assertTrue(msg.contains("posição de 10"))
    }

    @Test
    fun `venda de toda a posicao e aceita`() {
        val existing = listOf(l(1, "PETR4", LancamentoTipo.COMPRA, 10.0, "2026-01-10"))
        assertNull(LancamentoValidator.validate(existing, l(0, "PETR4", LancamentoTipo.VENDA, 10.0, "2026-02-01"), today))
    }

    @Test
    fun `venda no mesmo dia da compra e aceita`() {
        val existing = listOf(l(5, "PETR4", LancamentoTipo.COMPRA, 10.0, "2026-02-01"))
        assertNull(LancamentoValidator.validate(existing, l(0, "PETR4", LancamentoTipo.VENDA, 4.0, "2026-02-01"), today))
    }

    @Test
    fun `venda antes da compra e recusada`() {
        val existing = listOf(l(1, "PETR4", LancamentoTipo.COMPRA, 10.0, "2026-03-01"))
        assertNotNull(LancamentoValidator.validate(existing, l(0, "PETR4", LancamentoTipo.VENDA, 1.0, "2026-02-01"), today))
    }

    @Test
    fun `compra retroativa cobre venda posterior`() {
        val existing = listOf(l(1, "PETR4", LancamentoTipo.VENDA, 5.0, "2026-03-01"))
        // sozinha, a venda já é inconsistente; uma compra anterior resolve
        assertNull(LancamentoValidator.validate(emptyList(), l(0, "PETR4", LancamentoTipo.COMPRA, 5.0, "2026-02-01"), today))
        assertNotNull(LancamentoValidator.firstInconsistency(existing))
    }

    @Test
    fun `campos invalidos`() {
        assertNotNull(LancamentoValidator.validate(emptyList(), l(0, "XX", LancamentoTipo.COMPRA, 1.0, "2026-01-01"), today))
        assertNotNull(LancamentoValidator.validate(emptyList(), l(0, "PETR4", LancamentoTipo.COMPRA, 0.0, "2026-01-01"), today))
        assertNotNull(LancamentoValidator.validate(emptyList(), l(0, "PETR4", LancamentoTipo.COMPRA, 1.0, "2026-01-01", p = 0.0), today))
        assertNotNull(LancamentoValidator.validate(emptyList(), l(0, "PETR4", LancamentoTipo.COMPRA, 1.0, "2026-12-01"), today))
    }

    @Test
    fun `excluir compra que sustenta uma venda e recusado`() {
        val ls = listOf(
            l(1, "VALE3", LancamentoTipo.COMPRA, 10.0, "2026-01-01"),
            l(2, "VALE3", LancamentoTipo.VENDA, 6.0, "2026-02-01"),
        )
        assertNotNull(LancamentoValidator.validateRemoval(ls, 1))
        assertNull(LancamentoValidator.validateRemoval(ls, 2))
    }

    @Test
    fun `ativos diferentes nao se misturam`() {
        val existing = listOf(l(1, "VALE3", LancamentoTipo.COMPRA, 10.0, "2026-01-01"))
        assertNotNull(LancamentoValidator.validate(existing, l(0, "PETR4", LancamentoTipo.VENDA, 1.0, "2026-02-01"), today))
    }

    @Test
    fun `quantidade fracionada com residuo nao gera erro falso`() {
        val ls = listOf(
            l(1, "XPTO3", LancamentoTipo.COMPRA, 0.1, "2026-01-01"),
            l(2, "XPTO3", LancamentoTipo.COMPRA, 0.2, "2026-01-02"),
            l(3, "XPTO3", LancamentoTipo.VENDA, 0.3, "2026-01-03"),
        )
        assertNull(LancamentoValidator.firstInconsistency(ls))
        assertEquals(0, PositionCalculator.calculate(ls).size)
    }
}
