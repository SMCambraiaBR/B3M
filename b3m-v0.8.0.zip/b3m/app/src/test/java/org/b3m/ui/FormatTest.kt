package org.b3m.ui

import java.time.LocalDateTime
import java.time.ZoneOffset
import org.junit.Assert.assertEquals
import org.junit.Test

class FormatTest {

    private fun ms(s: String) = LocalDateTime.parse(s).toInstant(ZoneOffset.UTC).toEpochMilli()

    @Test
    fun `data e hora da coleta em portugues`() {
        val now = ms("2026-10-29T15:00:00")
        assertEquals("hoje às 14:32:10", formatCollected(ms("2026-10-29T14:32:10"), now, ZoneOffset.UTC))
        assertEquals("ontem às 18:05:44", formatCollected(ms("2026-10-28T18:05:44"), now, ZoneOffset.UTC))
        assertEquals("em 27/10/2026 às 09:01:12", formatCollected(ms("2026-10-27T09:01:12"), now, ZoneOffset.UTC))
    }

    @Test
    fun `setas acompanham o sinal`() {
        assertEquals("▲ 1,50%", 1.5.arrowPct())
        assertEquals("▼ 1,50%", (-1.5).arrowPct())
        assertEquals("0,00%", 0.0.arrowPct())
    }

    @Test
    fun `numeros enormes do fundamentus ficam legiveis`() {
        assertEquals("489,44 bi", prettyValue("489.435.000.000"))
        assertEquals("13,04 bi", prettyValue("13.044.496.000"))
        assertEquals("2,50 mi", prettyValue("2.500.000"))
        assertEquals("1,20 tri", prettyValue("1.200.000.000.000"))
        // não mexe no que não é número grande
        assertEquals("12,34%", prettyValue("12,34%"))
        assertEquals("30/09/2026", prettyValue("30/09/2026"))
        assertEquals("123.456", prettyValue("123.456"))
        assertEquals("Petrobras", prettyValue("Petrobras"))
    }
}
