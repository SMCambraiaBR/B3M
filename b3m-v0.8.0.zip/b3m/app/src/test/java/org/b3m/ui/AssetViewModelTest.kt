package org.b3m.ui

import java.time.LocalDate
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.runBlocking
import org.b3m.domain.TaxRates
import org.b3m.ui.asset.AssetViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AssetViewModelTest {

    init {
        installTestMain()
    }

    private val today = LocalDate.now()

    private fun vm(w: World, ticker: String = "ITSA4") = AssetViewModel(
        ticker = ticker, quotes = w.quotes, fundamentus = w.fundamentus, snapshots = w.snapshots,
        codecs = w.codecs, repo = w.repo, watchlist = w.watch, taxes = w.taxes,
        quoteRefreshMs = 40, retryMs = 40,
    )

    /** 100 ITSA4 comprados há 1 ano; JCP de 0,50 e dividendo de 0,20 por ação já pagos. */
    private suspend fun cenario(): World {
        val w = World()
        w.source.prices["ITSA4"] = 10.0
        w.repo.add(compra("ITSA4", 100.0, 8.0, today.minusYears(1)))
        w.fundamentus.proventosByTicker["ITSA4"] = listOf(
            jcp("ITSA4", 0.50, today.minusDays(30)),
            dividendo("ITSA4", 0.20, today.minusDays(60)),
        )
        return w
    }

    @Test
    fun `posicao mostra proventos liquidos e o imposto retido`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.start()
        val ui = vm.ui.await { it.position != null && it.proventos.data != null && it.quote.data != null }
        val p = ui.position!!
        assertEquals(100 * (0.50 * 0.85 + 0.20), p.dividendsNet, 1e-9) // JCP com 15% descontado
        assertEquals(100 * 0.50 * 0.15, p.taxPaid, 1e-9)
        assertEquals(1000.0, p.value, 1e-9)
        assertEquals(200.0, p.result, 1e-9)
        assertEquals(200.0 + p.dividendsNet, p.totalResult, 1e-9)
        assertEquals((0.50 * 0.85 + 0.20) / 6, ui.retorno!!.retorno, 1e-9)
        vm.stop()
    }

    @Test
    fun `mudar a aliquota recalcula na hora`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.start()
        vm.ui.await { it.position != null && it.proventos.data != null }
        w.taxes.value = TaxRates(jcp = 0.0)
        val p = vm.ui.await { it.taxes.jcp == 0.0 && it.position?.taxPaid == 0.0 }.position!!
        assertEquals(100 * 0.70, p.dividendsNet, 1e-9)
        vm.stop()
    }

    @Test
    fun `cotacao antiga fica marcada como desatualizada`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.start()
        vm.ui.await { it.quote.data != null }
        vm.stop()
        w.source.failing = true
        vm.start()
        val ui = vm.ui.await { it.quote.stale }
        assertTrue(ui.position!!.priceStale)
        assertEquals(1_000L, ui.quote.updatedAt)
        vm.stop()
    }

    @Test
    fun `proventos que falham nao viram sem proventos e a tela tenta de novo`() = runBlocking {
        val w = cenario()
        w.fundamentus.failing = true
        val vm = vm(w)
        vm.start()
        val bad = vm.ui.await { it.proventos.error != null }
        assertNull(bad.proventos.data)
        assertNull(bad.retorno) // sem dado: nao mostra "0,00"

        w.fundamentus.failing = false
        val ok = vm.ui.await { it.proventos.data != null }
        assertNotNull(ok.proventos.data)
        vm.ui.await { it.retorno != null }
        vm.stop()
    }

    @Test
    fun `venda maior que a posicao volta com mensagem e nao grava`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        val result = CompletableDeferred<String?>()
        vm.addLancamento(venda("ITSA4", 500.0, 10.0, today)) { result.complete(it) }
        val msg = result.await()
        assertNotNull(msg)
        assertTrue(msg!!.contains("maior que a posição"))
        assertEquals(1, w.lancDao.state.value.size)
    }

    @Test
    fun `compra valida e gravada e a mensagem vem nula`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        val result = CompletableDeferred<String?>()
        vm.addLancamento(compra("ITSA4", 10.0, 9.0, today)) { result.complete(it) }
        assertNull(result.await())
        assertEquals(2, w.lancDao.state.value.size)
    }

    @Test
    fun `favoritar e desfavoritar`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.ui.await { !it.favorite }
        vm.toggleFavorite()
        vm.ui.await { it.favorite }
        vm.toggleFavorite()
        val ui = vm.ui.await { !it.favorite }
        assertFalse(ui.favorite)
    }
}
