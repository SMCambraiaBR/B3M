package org.b3m.ui

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.withTimeout
import org.b3m.data.db.LancamentoDao
import org.b3m.data.db.LancamentoEntity
import org.b3m.data.db.LancamentoRepository
import org.b3m.data.db.WatchDao
import org.b3m.data.db.WatchEntity
import org.b3m.data.db.WatchlistRepository
import org.b3m.data.fundamentus.Detalhes
import org.b3m.data.fundamentus.DetalhesSection
import org.b3m.data.fundamentus.FundamentusApi
import org.b3m.data.fundamentus.ResultadoRow
import org.b3m.data.market.BenchmarkSource
import org.b3m.data.market.DividendRank
import org.b3m.data.market.RankingSource
import org.b3m.data.quotes.ChartPoint
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.MarketListSource
import org.b3m.data.quotes.QuoteRepository
import org.b3m.data.quotes.QuoteSource
import org.b3m.data.snapshot.Codec
import org.b3m.data.snapshot.DataCodecs
import org.b3m.data.snapshot.MemorySnapshotStore
import org.b3m.data.snapshot.Snapshots
import org.b3m.domain.Lancamento
import org.b3m.domain.LancamentoTipo
import org.b3m.domain.Provento
import org.b3m.domain.ProventoTipo
import org.b3m.domain.Quote
import org.b3m.domain.TaxRates

/**
 * O viewModelScope do Android roda em Dispatchers.Main, que não existe em teste de JVM.
 * Troca por Default (cada teste de ViewModel chama isto ao ser criado).
 */
fun installTestMain() {
    Dispatchers.setMain(Dispatchers.Default)
}

/** Codec de mentira: guarda o próprio objeto na memória e devolve um código no lugar do JSON. */
class ObjCodec<T> {
    private val store = ConcurrentHashMap<String, T>()
    private val n = AtomicInteger()
    val codec = Codec<T>(
        encode = { v -> "o${n.incrementAndGet()}".also { store[it] = v } },
        decode = { store.getValue(it) },
    )
}

class TestCodecs : DataCodecs {
    override val quote = ObjCodec<Quote>().codec
    override val quotes = ObjCodec<List<Quote>>().codec
    override val chart = ObjCodec<List<ChartPoint>>().codec
    override val proventos = ObjCodec<List<Provento>>().codec
    override val detalhes = ObjCodec<Detalhes>().codec
    override val ranking = ObjCodec<List<DividendRank>>().codec
}

/** Fonte de cotações controlável: preços fixos, hora de coleta fixa e botão de "rede fora". */
class FakeQuoteSource : QuoteSource {
    val prices = ConcurrentHashMap<String, Double>()
    @Volatile var failing = false
    @Volatile var stamp = 1_000L
    val calls = AtomicInteger()

    override suspend fun quote(ticker: String): Quote =
        quotes(listOf(ticker)).firstOrNull() ?: error("sem cotação de $ticker")

    override suspend fun quotes(tickers: List<String>): List<Quote> {
        calls.incrementAndGet()
        if (failing) error("rede fora")
        return tickers.mapNotNull { t ->
            prices[t.uppercase()]?.let { Quote(t.uppercase(), it, 1.0, fetchedAt = stamp) }
        }
    }

    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> {
        if (failing) error("rede fora")
        val base = prices[ticker.uppercase()] ?: error("sem gráfico de $ticker")
        val day = 86_400_000L
        val t0 = LocalDate.now().minusDays(5).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        return (0..5).map { ChartPoint(t0 + it * day, base * (1 + 0.01 * it)) }
    }
}

class FakeFundamentus : FundamentusApi {
    val proventosByTicker = ConcurrentHashMap<String, List<Provento>>()
    @Volatile var failing = false
    val proventosCalls = AtomicInteger()

    override suspend fun detalhes(ticker: String): Detalhes {
        if (failing) error("site fora")
        return Detalhes(listOf(DetalhesSection("Geral", listOf("Empresa" to "Empresa $ticker", "Div. Yield" to "9,5%"))))
    }

    override suspend fun proventos(ticker: String): List<Provento> {
        proventosCalls.incrementAndGet()
        if (failing) error("site fora")
        return proventosByTicker[ticker.uppercase()].orEmpty()
    }

    override suspend fun resultado(): List<ResultadoRow> = emptyList()
    override fun invalidate(ticker: String) {}
    override fun invalidateAll() {}
}

class FakeRanking(var items: List<DividendRank> = emptyList()) : RankingSource {
    @Volatile var failing = false
    val calls = AtomicInteger()
    override suspend fun load(): List<DividendRank> {
        calls.incrementAndGet()
        if (failing) error("ranking fora")
        return items
    }
}

class FakeMarket : MarketListSource {
    @Volatile var failing = false
    var list: List<Quote> = emptyList()
    override suspend fun search(prefix: String): List<Quote> = list.filter { it.ticker.startsWith(prefix.uppercase()) }
    override suspend fun topGainers(limit: Int): List<Quote> = pick()
    override suspend fun topLosers(limit: Int): List<Quote> = pick()
    override suspend fun mostTraded(limit: Int): List<Quote> = pick()
    private fun pick(): List<Quote> {
        if (failing) error("lista fora")
        return list
    }
}

class FakeBenchmarks : BenchmarkSource {
    override suspend fun cdiAccumulated(from: LocalDate): List<ChartPoint> = error("sem BCB")
    override suspend fun ipcaAccumulated(from: LocalDate): List<ChartPoint> = error("sem BCB")
}

class FakeLancamentoDao : LancamentoDao {
    val state = MutableStateFlow<List<LancamentoEntity>>(emptyList())
    private val next = AtomicInteger(1)

    override fun observeAll(): Flow<List<LancamentoEntity>> =
        state.map { l -> l.sortedWith(compareByDescending<LancamentoEntity> { it.dataEpochDay }.thenByDescending { it.id }) }

    override suspend fun all(): List<LancamentoEntity> = state.value.sortedWith(compareBy({ it.dataEpochDay }, { it.id }))

    override suspend fun insert(entity: LancamentoEntity): Long {
        val id = next.getAndIncrement().toLong()
        state.update { it + entity.copy(id = id) }
        return id
    }

    override suspend fun insertAll(entities: List<LancamentoEntity>) {
        entities.forEach { insert(it) }
    }

    override suspend fun deleteById(id: Long) {
        state.update { l -> l.filterNot { it.id == id } }
    }
}

class FakeWatchDao : WatchDao {
    val state = MutableStateFlow<List<WatchEntity>>(emptyList())
    override fun observeAll(): Flow<List<WatchEntity>> = state.map { l -> l.sortedBy { it.addedAt } }
    override suspend fun insert(entity: WatchEntity) {
        state.update { l -> if (l.any { it.ticker == entity.ticker }) l else l + entity }
    }
    override suspend fun delete(ticker: String) {
        state.update { l -> l.filterNot { it.ticker == ticker } }
    }
}

/**
 * Tudo o que os ViewModels precisam, montado com dados de mentira.
 * O viewModelScope usa Dispatchers.Main, que não existe em teste de JVM: aponta para o Default.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class World {
    init {
        Dispatchers.setMain(Dispatchers.Default)
    }

    val source = FakeQuoteSource()
    val codecs = TestCodecs()
    val snapshots = Snapshots(MemorySnapshotStore())
    val quotes = QuoteRepository(source, snapshots, codecs.quote, codecs.chart)
    val fundamentus = FakeFundamentus()
    val ranking = FakeRanking()
    val market = FakeMarket()
    val bcb = FakeBenchmarks()
    val lancDao = FakeLancamentoDao()
    val repo = LancamentoRepository(lancDao)
    val watchDao = FakeWatchDao()
    val watch = WatchlistRepository(watchDao)
    val taxes = MutableStateFlow(TaxRates())
}

fun compra(ticker: String, qtd: Double, preco: Double, data: LocalDate) =
    Lancamento(ticker = ticker, tipo = LancamentoTipo.COMPRA, quantidade = qtd, preco = preco, data = data)

fun venda(ticker: String, qtd: Double, preco: Double, data: LocalDate) =
    Lancamento(ticker = ticker, tipo = LancamentoTipo.VENDA, quantidade = qtd, preco = preco, data = data)

fun jcp(ticker: String, bruto: Double, pago: LocalDate) =
    Provento(ticker, ProventoTipo.JCP, pago, bruto, dataCom = pago.minusDays(20))

fun dividendo(ticker: String, bruto: Double, pago: LocalDate) =
    Provento(ticker, ProventoTipo.DIVIDENDO, pago, bruto, dataCom = pago.minusDays(20))

/** Espera (até [ms]) o estado satisfazer a condição; falha com o último estado se não satisfizer. */
suspend fun <T> StateFlow<T>.await(ms: Long = 5_000, cond: (T) -> Boolean): T =
    try {
        withTimeout(ms) { first(cond) }
    } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
        throw AssertionError("tempo esgotado esperando o estado; último valor: $value")
    }
