package org.b3m.ui

import java.time.LocalDate
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.b3m.data.market.DividendRank
import org.b3m.domain.TaxRates
import org.b3m.ui.market.MarketViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MarketViewModelTest {

    init {
        installTestMain()
    }

    private val ibov = "^BVSP"

    private fun vm(w: World) = MarketViewModel(
        quotes = w.quotes, market = w.market, ranking = w.ranking, fundamentus = w.fundamentus,
        snapshots = w.snapshots, codecs = w.codecs, watchlist = w.watch, taxes = w.taxes,
        refreshMs = 40, retryMs = 40,
    )

    @Test
    fun `mostra a cotacao do IBOV com a hora em que foi coletada`() = runBlocking {
        val w = World()
        w.source.prices[ibov] = 130_000.0
        w.source.stamp = 5_000L
        val vm = vm(w)
        vm.start()
        val s = vm.ui.await { it.ibov.data != null }.ibov
        assertEquals(5_000L, s.updatedAt)
        assertFalse(s.stale)
        vm.stop()
    }

    @Test
    fun `se a coleta nova falha mostra o ultimo dado com aviso e a hora antiga`() = runBlocking {
        val w = World()
        w.source.prices[ibov] = 130_000.0
        w.source.stamp = 5_000L
        val vm = vm(w)
        vm.start()
        vm.ui.await { it.ibov.data != null }
        vm.stop()

        w.source.failing = true
        w.source.stamp = 9_000L
        vm.start()
        val s = vm.ui.await { it.ibov.stale }.ibov
        assertNotNull(s.data)
        assertEquals(5_000L, s.updatedAt) // a hora da ULTIMA coleta que deu certo, nao a de agora
        assertNull(s.error)
        vm.stop()
    }

    @Test
    fun `sem internet e sem nada guardado mostra erro e nao um valor zerado`() = runBlocking {
        val w = World()
        w.source.failing = true
        val vm = vm(w)
        vm.start()
        val s = vm.ui.await { it.ibov.error != null }.ibov
        assertNull(s.data)
        assertFalse(s.loading)
        vm.stop()
    }

    @Test
    fun `app reaberto sem internet mostra o dado guardado em disco com aviso`() = runBlocking {
        val w = World()
        w.source.prices[ibov] = 130_000.0
        w.source.stamp = 5_000L
        val first = vm(w)
        first.start()
        first.ui.await { it.ibov.data != null }
        first.stop()

        w.source.failing = true
        val second = vm(w) // outra instancia: como abrir o app de novo
        second.start()
        val s = second.ui.await { it.ibov.stale }.ibov
        assertEquals(5_000L, s.updatedAt)
        assertEquals(130_000.0, s.data!!.price, 0.0)
        second.stop()
    }

    @Test
    fun `ao sair da tela para de consultar a internet`() = runBlocking {
        val w = World()
        w.source.prices[ibov] = 1.0
        val vm = vm(w)
        vm.start()
        vm.ui.await { it.ibov.data != null }
        vm.stop()
        delay(150) // deixa terminar o que estava em andamento
        val before = w.source.calls.get()
        delay(300)
        assertEquals(before, w.source.calls.get())
    }

    @Test
    fun `ranking guardado e reaproveitado ao reabrir a tela e refresh forca nova coleta`() = runBlocking {
        val w = World()
        w.source.prices[ibov] = 1.0
        w.ranking.items = listOf(DividendRank("ITSA4", 10.0, 9.0, listOf(jcp("ITSA4", 0.6, LocalDate.now().minusDays(30)))))
        val vm = vm(w)
        vm.start()
        vm.ui.await { it.dividends.data != null }
        assertEquals(1, w.ranking.calls.get())
        vm.stop()

        vm.start() // reabriu: usa o guardado (tem menos de 15 min)
        delay(250)
        assertEquals(1, w.ranking.calls.get())

        vm.refresh() // pediu atualizar: coleta de novo
        w.ranking.let { r ->
            val limit = System.currentTimeMillis() + 5_000
            while (r.calls.get() < 2 && System.currentTimeMillis() < limit) delay(20)
        }
        assertEquals(2, w.ranking.calls.get())
        vm.stop()
    }

    @Test
    fun `ranking que falha sem nada guardado mostra erro e tenta de novo`() = runBlocking {
        val w = World()
        w.source.prices[ibov] = 1.0
        w.ranking.failing = true
        val vm = vm(w)
        vm.start()
        val s = vm.ui.await { it.dividends.error != null }.dividends
        assertNull(s.data)

        w.ranking.items = listOf(DividendRank("ITSA4", 10.0, 9.0, listOf(jcp("ITSA4", 0.6, LocalDate.now().minusDays(30)))))
        w.ranking.failing = false
        val ok = vm.ui.await { it.dividends.data != null }.dividends
        assertFalse(ok.stale)
        assertNull(ok.error)
        vm.stop()
    }

    @Test
    fun `favoritos aparecem com cotacao e ficam marcados quando a coleta falha`() = runBlocking {
        val w = World()
        w.source.prices[ibov] = 1.0
        w.source.prices["PETR4"] = 30.0
        w.source.stamp = 4_000L
        w.watch.add("petr4")
        val vm = vm(w)
        vm.start()
        val ok = vm.ui.await { it.favorites.firstOrNull()?.quote != null }
        assertEquals("PETR4", ok.favorites.first().ticker)
        assertFalse(ok.favoritesStale)
        assertEquals(4_000L, ok.favoritesAt)

        w.source.failing = true
        val bad = vm.ui.await { it.favoritesStale }
        assertEquals(30.0, bad.favorites.first().quote!!.price, 0.0) // continua mostrando o ultimo preco
        assertEquals(4_000L, bad.favoritesAt)
        vm.stop()
    }

    @Test
    fun `mudar a aliquota em Ajustes chega ao ranking`() = runBlocking {
        val w = World()
        val vm = vm(w)
        w.taxes.value = TaxRates(jcp = 0.2)
        val ui = vm.ui.await { it.taxes.jcp == 0.2 }
        assertTrue(ui.taxes.jcp == 0.2)
    }
}
