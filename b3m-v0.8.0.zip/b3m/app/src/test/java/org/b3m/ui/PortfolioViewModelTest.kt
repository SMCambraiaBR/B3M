package org.b3m.ui

import java.time.LocalDate
import java.time.ZoneOffset
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.runBlocking
import org.b3m.ui.portfolio.PortfolioViewModel
import org.b3m.ui.portfolio.PositionSort
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PortfolioViewModelTest {

    init {
        installTestMain()
    }

    private val today = LocalDate.now()

    private fun vm(w: World) = PortfolioViewModel(
        repository = w.repo, quotes = w.quotes, fundamentus = w.fundamentus, bcb = w.bcb,
        snapshots = w.snapshots, codecs = w.codecs, taxes = w.taxes,
        refreshMs = 40, retryMs = 40, zone = ZoneOffset.UTC,
    )

    /** ITSA4: 100 a 8,00 (agora 10,00, com JCP). BBAS3: 50 a 20,00 (agora 18,00). */
    private suspend fun cenario(): World {
        val w = World()
        w.source.prices["ITSA4"] = 10.0
        w.source.prices["BBAS3"] = 18.0
        w.repo.add(compra("ITSA4", 100.0, 8.0, today.minusYears(1)))
        w.repo.add(compra("BBAS3", 50.0, 20.0, today.minusYears(1)))
        w.fundamentus.proventosByTicker["ITSA4"] = listOf(jcp("ITSA4", 0.50, today.minusDays(30)))
        return w
    }

    @Test
    fun `totais com peso de cada ativo e resultado com proventos liquidos`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.start()
        val ui = vm.ui.await { it.positions.size == 2 && it.quotesAt != null && it.income.events.isNotEmpty() }
        assertEquals(1900.0, ui.patrimonio, 1e-9)
        assertEquals(1800.0, ui.investido, 1e-9)
        assertEquals(100.0, ui.resultado, 1e-9)
        assertEquals(42.5, ui.dividends, 1e-9)           // 100 x 0,50 menos 15% de JCP
        assertEquals(7.5, ui.income.totalTax, 1e-9)       // imposto retido
        assertEquals(142.5, ui.resultadoTotal, 1e-9)
        assertEquals(1800.0 - 42.5, ui.gastoReal, 1e-9)
        val itsa = ui.positions.first { it.position.ticker == "ITSA4" }
        assertEquals(1000.0 / 1900.0 * 100, itsa.weight, 1e-9)
        assertEquals("ITSA4", ui.positions.first().position.ticker) // ordenado por valor
        vm.stop()
    }

    @Test
    fun `proventos de posicao vendida por inteiro nao entram`() = runBlocking {
        val w = cenario()
        w.repo.add(compra("VALE3", 10.0, 60.0, today.minusYears(1)))
        w.repo.add(venda("VALE3", 10.0, 70.0, today.minusDays(100)))
        w.fundamentus.proventosByTicker["VALE3"] = listOf(dividendo("VALE3", 1.0, today.minusDays(150)))
        val vm = vm(w)
        vm.start()
        val ui = vm.ui.await { it.positions.size == 2 && it.income.events.isNotEmpty() && !it.income.loading }
        assertEquals(42.5, ui.dividends, 1e-9)
        assertEquals(2, ui.positions.size)
        vm.stop()
    }

    @Test
    fun `ativo sem cotacao usa preco medio e aparece como sem cotacao`() = runBlocking {
        val w = cenario()
        w.source.prices.remove("BBAS3")
        val vm = vm(w)
        vm.start()
        val ui = vm.ui.await { it.positions.size == 2 && it.quotesAt != null }
        assertEquals(listOf("BBAS3"), ui.missingQuotes)
        assertEquals(1000.0, ui.positions.first { it.position.ticker == "BBAS3" }.value, 1e-9) // 50 x 20 (preco medio)
        vm.stop()
    }

    @Test
    fun `quando as cotacoes falham mostra as ultimas guardadas com a hora antiga`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.start()
        vm.ui.await { it.positions.size == 2 && it.quotesAt == 1_000L && !it.quotesStale }
        vm.stop()

        w.source.failing = true
        w.source.stamp = 9_000L
        vm.start()
        val ui = vm.ui.await { it.quotesStale }
        assertEquals(1_000L, ui.quotesAt)
        assertEquals(1900.0, ui.patrimonio, 1e-9) // continua com os ultimos precos, nao com o preco medio
        assertTrue(ui.missingQuotes.isEmpty())
        assertEquals(0.0, ui.dayChange, 1e-9) // variacao de um dia antigo nao conta como a de hoje
        vm.stop()
    }

    @Test
    fun `proventos que falham aparecem como pendentes e sao buscados de novo`() = runBlocking {
        val w = cenario()
        w.fundamentus.failing = true
        val vm = vm(w)
        vm.start()
        val bad = vm.ui.await { it.income.failedTickers.isNotEmpty() }
        assertTrue(bad.income.events.isEmpty())
        assertTrue(bad.income.failedTickers.contains("ITSA4"))

        w.fundamentus.failing = false
        val ok = vm.ui.await { it.income.events.isNotEmpty() && it.income.failedTickers.isEmpty() }
        assertEquals(42.5, ok.dividends, 1e-9)
        vm.stop()
    }

    @Test
    fun `renda mensal tem 12 meses e a media dos ultimos 6`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.start()
        val ui = vm.ui.await { it.income.events.isNotEmpty() }
        assertEquals(12, ui.income.monthly.size)
        assertEquals(42.5, ui.income.last12, 1e-9)
        assertEquals(42.5 / 6, ui.income.average6, 1e-9)
        vm.stop()
    }

    @Test
    fun `ordenacao por codigo`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.start()
        vm.ui.await { it.positions.size == 2 }
        vm.selectSort(PositionSort.TICKER)
        val ui = vm.ui.await { it.sort == PositionSort.TICKER }
        assertEquals(listOf("BBAS3", "ITSA4"), ui.positions.map { it.position.ticker })
        vm.stop()
    }

    @Test
    fun `desempenho inclui proventos e grafico de evolucao tem a hora da coleta`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        vm.start()
        val ui = vm.ui.await { it.performance.twr.size >= 2 && it.evolution.patrimonio.size >= 2 }
        assertNotNull(ui.performance.updatedAt)
        assertNotNull(ui.evolution.updatedAt)
        assertFalse(ui.performance.stale)
        vm.stop()
    }

    @Test
    fun `venda maior que a posicao volta com mensagem`() = runBlocking {
        val w = cenario()
        val vm = vm(w)
        val result = CompletableDeferred<String?>()
        vm.add(venda("BBAS3", 999.0, 18.0, today)) { result.complete(it) }
        val msg = result.await()
        assertNotNull(msg)
        assertEquals(2, w.lancDao.state.value.size)
    }

    @Test
    fun `nao deixa excluir compra que sustenta uma venda`() = runBlocking {
        val w = World()
        w.repo.add(compra("ITSA4", 100.0, 8.0, today.minusDays(30)))
        w.repo.add(venda("ITSA4", 60.0, 9.0, today.minusDays(10)))
        val vm = vm(w)
        val idCompra = w.lancDao.state.value.first { it.tipo == "COMPRA" }.id
        val result = CompletableDeferred<String?>()
        vm.remove(idCompra) { result.complete(it) }
        assertNotNull(result.await())
        assertEquals(2, w.lancDao.state.value.size)
    }
}
