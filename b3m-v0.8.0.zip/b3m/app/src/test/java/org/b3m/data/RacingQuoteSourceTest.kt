package org.b3m.data

import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.b3m.data.quotes.ChartPoint
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.NamedSource
import org.b3m.data.quotes.QuoteSource
import org.b3m.data.quotes.RacingQuoteSource
import org.b3m.domain.Quote
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeSource(
    private val price: Double,
    private val delayMs: Long,
    private val fail: Boolean = false,
    private val only: Set<String>? = null, // se informado, só conhece estes códigos
    private val chartPoints: List<ChartPoint> = listOf(ChartPoint(1L, 1.0)),
) : QuoteSource {
    val batchCalls = AtomicInteger(0)

    override suspend fun quote(ticker: String): Quote {
        delay(delayMs)
        if (fail) error("falhou")
        return Quote(ticker, price, 0.0)
    }

    override suspend fun quotes(tickers: List<String>): List<Quote> {
        batchCalls.incrementAndGet()
        delay(delayMs)
        if (fail) error("falhou")
        return tickers.filter { only == null || it in only }.map { Quote(it, price, 0.0) }
    }

    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> {
        delay(delayMs)
        if (fail) error("falhou")
        return chartPoints
    }
}

/** Como o Yahoo bloqueado: "responde" rápido, mas sem nada. */
private class EmptySource : QuoteSource {
    override suspend fun quote(ticker: String): Quote = error("sem dados")
    override suspend fun quotes(tickers: List<String>): List<Quote> = emptyList()
    override suspend fun chart(ticker: String, range: ChartRange): List<ChartPoint> = emptyList()
}

class RacingQuoteSourceTest {

    @Test
    fun `vence a fonte mais rapida`() = runBlocking {
        val racing = RacingQuoteSource(
            listOf(NamedSource("lenta", FakeSource(1.0, 300)), NamedSource("rapida", FakeSource(2.0, 20)))
        )
        assertEquals(2.0, racing.quote("PETR4").price, 0.0)
    }

    @Test
    fun `ignora fonte que falha e usa a que funciona`() = runBlocking {
        val racing = RacingQuoteSource(
            listOf(
                NamedSource("quebrada", FakeSource(1.0, 5, fail = true)),
                NamedSource("ok", FakeSource(3.0, 50)),
            )
        )
        assertEquals(3.0, racing.quote("VALE3").price, 0.0)
    }

    @Test(expected = IllegalStateException::class)
    fun `falha quando todas falham`() {
        runBlocking {
            RacingQuoteSource(listOf(NamedSource("a", FakeSource(1.0, 1, fail = true)))).quote("X")
        }
    }

    @Test
    fun `depois de amostras consulta so a mais rapida`() = runBlocking {
        val racing = RacingQuoteSource(
            listOf(NamedSource("lenta", FakeSource(1.0, 150)), NamedSource("rapida", FakeSource(2.0, 10)))
        )
        repeat(4) { racing.quote("ITUB4") }
        assertEquals(2.0, racing.quote("ITUB4").price, 0.0)
    }

    @Test
    fun `lista vazia nao vence a corrida`() = runBlocking {
        val racing = RacingQuoteSource(
            listOf(NamedSource("vazia", EmptySource()), NamedSource("ok", FakeSource(7.0, 60)))
        )
        val result = racing.quotes(listOf("PETR4", "VALE3"))
        assertEquals(listOf("PETR4", "VALE3"), result.map { it.ticker })
        assertEquals(7.0, result.first().price, 0.0)
    }

    @Test
    fun `fonte que so devolve vazio nunca vira a preferida`() = runBlocking {
        val racing = RacingQuoteSource(
            listOf(NamedSource("vazia", EmptySource()), NamedSource("ok", FakeSource(7.0, 40)))
        )
        repeat(6) { assertEquals(1, racing.quotes(listOf("PETR4")).size) }
    }

    @Test(expected = IllegalStateException::class)
    fun `preco zero e rejeitado`() {
        runBlocking {
            RacingQuoteSource(listOf(NamedSource("zero", FakeSource(0.0, 1)))).quote("PETR4")
        }
    }

    @Test
    fun `grafico vazio nao vence a corrida`() = runBlocking {
        val racing = RacingQuoteSource(
            listOf(NamedSource("vazia", EmptySource()), NamedSource("ok", FakeSource(1.0, 30)))
        )
        assertEquals(1, racing.chart("PETR4", ChartRange.M1).size)
    }

    @Test
    fun `completa com outra fonte o que faltou no lote`() = runBlocking {
        val racing = RacingQuoteSource(
            listOf(
                NamedSource("parcial", FakeSource(1.0, 5, only = setOf("PETR4"))),
                NamedSource("completa", FakeSource(2.0, 80)),
            )
        )
        val result = racing.quotes(listOf("PETR4", "VALE3")).associateBy { it.ticker }
        assertEquals(setOf("PETR4", "VALE3"), result.keys)
        assertEquals(2.0, result.getValue("VALE3").price, 0.0)
    }

    @Test
    fun `ativo que ninguem tem nao e consultado de novo por 5 minutos`() = runBlocking {
        var now = 1_000_000L
        val a = FakeSource(1.0, 1, only = setOf("PETR4"))
        val racing = RacingQuoteSource(listOf(NamedSource("a", a)), clock = { now })
        racing.quotes(listOf("PETR4", "XXXX3"))
        assertEquals(2, a.batchCalls.get()) // lote + tentativa do que faltou
        racing.quotes(listOf("PETR4", "XXXX3"))
        assertEquals(3, a.batchCalls.get()) // só o lote: XXXX3 está na lista de ausentes
        now += 6 * 60_000
        racing.quotes(listOf("PETR4", "XXXX3"))
        assertTrue(a.batchCalls.get() >= 5) // passou o prazo: tenta de novo
    }
}
