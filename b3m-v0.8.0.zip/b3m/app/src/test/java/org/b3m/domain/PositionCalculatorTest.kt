package org.b3m.domain

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PositionCalculatorTest {

    private fun l(id: Long, t: String, tipo: LancamentoTipo, q: Double, p: Double, d: String) =
        Lancamento(id, t, tipo, q, p, LocalDate.parse(d))

    @Test
    fun `preco medio ponderado nas compras`() {
        val pos = PositionCalculator.calculate(
            listOf(
                l(1, "PETR4", LancamentoTipo.COMPRA, 10.0, 30.0, "2026-01-10"),
                l(2, "PETR4", LancamentoTipo.COMPRA, 10.0, 50.0, "2026-02-10"),
            )
        )
        assertEquals(20.0, pos.single().quantity, 0.0)
        assertEquals(40.0, pos.single().averagePrice, 1e-9)
        assertEquals(800.0, pos.single().invested, 1e-9)
    }

    @Test
    fun `venda reduz quantidade e mantem preco medio`() {
        val pos = PositionCalculator.calculate(
            listOf(
                l(1, "VALE3", LancamentoTipo.COMPRA, 10.0, 60.0, "2026-01-10"),
                l(2, "VALE3", LancamentoTipo.VENDA, 4.0, 80.0, "2026-03-10"),
            )
        )
        assertEquals(6.0, pos.single().quantity, 0.0)
        assertEquals(60.0, pos.single().averagePrice, 1e-9)
    }

    @Test
    fun `posicao zerada some e ordem de insercao nao importa`() {
        val pos = PositionCalculator.calculate(
            listOf(
                l(2, "ITUB4", LancamentoTipo.VENDA, 5.0, 40.0, "2026-04-01"),
                l(1, "ITUB4", LancamentoTipo.COMPRA, 5.0, 35.0, "2026-03-01"),
            )
        )
        assertTrue(pos.isEmpty())
    }

    @Test
    fun `residuo de ponto flutuante nao cria posicao fantasma`() {
        val pos = PositionCalculator.calculate(
            listOf(
                l(1, "XPTO3", LancamentoTipo.COMPRA, 0.1, 10.0, "2026-01-01"),
                l(2, "XPTO3", LancamentoTipo.COMPRA, 0.2, 10.0, "2026-01-02"),
                l(3, "XPTO3", LancamentoTipo.VENDA, 0.3, 12.0, "2026-01-03"),
            )
        )
        assertTrue(pos.isEmpty())
    }

    @Test
    fun `quantidade na data ignora residuo`() {
        val ls = listOf(
            l(1, "XPTO3", LancamentoTipo.COMPRA, 0.1, 10.0, "2026-01-01"),
            l(2, "XPTO3", LancamentoTipo.COMPRA, 0.2, 10.0, "2026-01-02"),
            l(3, "XPTO3", LancamentoTipo.VENDA, 0.3, 12.0, "2026-01-03"),
        )
        assertEquals(0.0, DividendCalculator.quantityAt(ls, LocalDate.parse("2026-01-05")), 0.0)
    }
}
