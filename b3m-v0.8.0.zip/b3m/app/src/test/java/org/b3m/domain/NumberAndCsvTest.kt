package org.b3m.domain

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NumberAndCsvTest {

    @Test
    fun `ponto de milhar e virgula decimal`() {
        assertEquals(1000.0, parseBrNumber("1.000")!!, 0.0)
        assertEquals(1000.5, parseBrNumber("1.000,50")!!, 0.0)
        assertEquals(1234567.0, parseBrNumber("1.234.567")!!, 0.0)
        assertEquals(10.5, parseBrNumber("10,5")!!, 0.0)
        assertEquals(35.5, parseBrNumber("35.5")!!, 0.0)
        assertEquals(0.125, parseBrNumber("0.125")!!, 0.0)
        assertEquals(100.0, parseBrNumber("100")!!, 0.0)
        assertEquals(12.34, parseBrNumber("R$ 12,34")!!, 0.0)
    }

    @Test
    fun `texto ambiguo ou invalido vira nulo`() {
        listOf("", "abc", "-5", "1,2,3", "1,234.56", "1e5", "NaN", "12,", ",5").forEach {
            assertNull("\"$it\" deveria ser inválido", parseBrNumber(it))
        }
    }

    @Test
    fun `numero de maquina nao trata ponto como milhar`() {
        assertEquals(1.234, parsePlainNumber("1.234")!!, 0.0)
        assertEquals(1234.5, parsePlainNumber("1.234,5")!!, 0.0)
        assertEquals(35.5, parsePlainNumber("35.5")!!, 0.0)
    }

    private val today = LocalDate.parse("2026-10-28")

    @Test
    fun `csv exporta e importa sem perder nada`() {
        val original = listOf(
            Lancamento(2, "VALE3", LancamentoTipo.VENDA, 4.0, 80.0, LocalDate.parse("2026-03-10")),
            Lancamento(1, "VALE3", LancamentoTipo.COMPRA, 10.0, 60.125, LocalDate.parse("2026-01-10")),
            Lancamento(3, "B3SA3", LancamentoTipo.COMPRA, 1000.0, 12.34, LocalDate.parse("2026-02-01")),
        )
        val text = LancamentoCsv.encode(original)
        assertTrue(text.startsWith(LancamentoCsv.HEADER))
        val parsed = LancamentoCsv.decode(text, today)
        assertEquals(emptyList<String>(), parsed.errors)
        assertEquals(3, parsed.items.size)
        val sortedOriginal = original.sortedBy { it.data }
        parsed.items.zip(sortedOriginal).forEach { (a, b) ->
            assertEquals(b.ticker, a.ticker)
            assertEquals(b.tipo, a.tipo)
            assertEquals(b.quantidade, a.quantidade, 0.0)
            assertEquals(b.preco, a.preco, 0.0)
            assertEquals(b.data, a.data)
        }
    }

    @Test
    fun `csv aceita data brasileira bom e linhas em branco`() {
        val text = "﻿ticker;tipo;quantidade;preco;data\n\nPETR4;compra;100;35,50;10/01/2026\n"
        val parsed = LancamentoCsv.decode(text, today)
        assertEquals(emptyList<String>(), parsed.errors)
        assertEquals(35.5, parsed.items.single().preco, 0.0)
        assertEquals(LocalDate.parse("2026-01-10"), parsed.items.single().data)
    }

    @Test
    fun `csv relata linhas invalidas e importa as boas`() {
        val text = """
            ticker;tipo;quantidade;preco;data
            PETR4;COMPRA;100;35.5;2026-01-10
            XX;COMPRA;100;35.5;2026-01-10
            VALE3;TROCA;1;1;2026-01-10
            VALE3;COMPRA;abc;1;2026-01-10
            VALE3;COMPRA;1;1
            ITUB4;COMPRA;10;30;2030-01-01
        """.trimIndent()
        val parsed = LancamentoCsv.decode(text, today)
        assertEquals(1, parsed.items.size)
        assertEquals(5, parsed.errors.size)
        assertTrue(parsed.errors.first().startsWith("Linha 3"))
    }
}
