package org.b3m.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import kotlin.random.Random
import org.b3m.data.quotes.ChartPoint
import org.junit.Assert.assertEquals
import org.junit.Test

class PerformanceTest {

    private fun ms(date: String) = LocalDate.parse(date).atTime(12, 0).toInstant(ZoneOffset.UTC).toEpochMilli()

    private fun lanc(id: Long, tipo: LancamentoTipo, q: Double, p: Double, d: String) =
        Lancamento(id, "XPTO3", tipo, q, p, LocalDate.parse(d))

    private val closes = mapOf(
        "XPTO3" to listOf(
            ChartPoint(ms("2026-01-01"), 10.0),
            ChartPoint(ms("2026-01-02"), 11.0),
            ChartPoint(ms("2026-01-03"), 12.0),
        )
    )

    @Test
    fun `twr sem aportes acompanha o preco`() {
        val pts = PerformanceCalculator.series(
            listOf(lanc(1, LancamentoTipo.COMPRA, 10.0, 10.0, "2026-01-01")), closes, zone = ZoneOffset.UTC
        )
        assertEquals(listOf(100.0, 110.0, 120.0), pts.map { it.value })
        val twr = PerformanceCalculator.twr(pts)
        assertEquals(0.0, twr[0].value, 1e-9)
        assertEquals(10.0, twr[1].value, 1e-9)
        assertEquals(20.0, twr[2].value, 1e-9)
    }

    @Test
    fun `aporte nao distorce a rentabilidade`() {
        val pts = PerformanceCalculator.series(
            listOf(
                lanc(1, LancamentoTipo.COMPRA, 10.0, 10.0, "2026-01-01"),
                lanc(2, LancamentoTipo.COMPRA, 10.0, 12.0, "2026-01-03"),
            ),
            closes, zone = ZoneOffset.UTC,
        )
        assertEquals(240.0, pts[2].value, 1e-9)
        assertEquals(120.0, pts[2].flow, 1e-9)
        assertEquals(20.0, PerformanceCalculator.twr(pts)[2].value, 1e-9)
    }

    @Test
    fun `provento recebido conta como retorno`() {
        val flat = mapOf(
            "XPTO3" to listOf(
                ChartPoint(ms("2026-01-01"), 10.0),
                ChartPoint(ms("2026-01-02"), 10.0),
                ChartPoint(ms("2026-01-03"), 10.0),
            )
        )
        val income = listOf(
            IncomeEvent("XPTO3", ProventoTipo.DIVIDENDO, LocalDate.parse("2026-01-02"), gross = 5.0, net = 5.0),
        )
        val pts = PerformanceCalculator.series(
            listOf(lanc(1, LancamentoTipo.COMPRA, 10.0, 10.0, "2026-01-01")), flat, income, ZoneOffset.UTC
        )
        assertEquals(5.0, pts[1].income, 1e-9)
        val twr = PerformanceCalculator.twr(pts)
        assertEquals(5.0, twr[1].value, 1e-9) // 5 sobre 100 investidos
        assertEquals(5.0, twr[2].value, 1e-9) // dia seguinte sem variação
    }

    @Test
    fun `provento anterior ao primeiro ponto nao entra`() {
        val income = listOf(
            IncomeEvent("XPTO3", ProventoTipo.DIVIDENDO, LocalDate.parse("2025-12-01"), gross = 50.0, net = 50.0),
        )
        val pts = PerformanceCalculator.series(
            listOf(lanc(1, LancamentoTipo.COMPRA, 10.0, 10.0, "2025-11-01")), closes, income, ZoneOffset.UTC
        )
        assertEquals(0.0, pts.sumOf { it.income }, 0.0)
    }

    @Test
    fun `acumula cdi em juros compostos`() {
        val s = SeriesMath.accumulate(0L, listOf(1L to 1.0, 2L to 1.0))
        assertEquals(0.0, s[0].value, 1e-9)
        assertEquals(2.01, s[2].value, 1e-9)
    }

    @Test
    fun `rebase em percentual`() {
        val r = SeriesMath.rebasePct(listOf(ChartPoint(1, 50.0), ChartPoint(2, 55.0)))
        assertEquals(10.0, r[1].value, 1e-9)
    }

    @Test
    fun `dividendos recebidos usam a quantidade da data com`() {
        val lancs = listOf(
            lanc(1, LancamentoTipo.COMPRA, 10.0, 10.0, "2026-01-01"),
            lanc(2, LancamentoTipo.COMPRA, 10.0, 10.0, "2026-03-01"),
        )
        val prov = listOf(
            // data com antes da 2ª compra: 10 ações; JCP líquido = 1,00 × 0,85
            Provento("XPTO3", ProventoTipo.JCP, LocalDate.parse("2026-03-15"), 1.0, LocalDate.parse("2026-02-01")),
            // data com depois da 2ª compra: 20 ações; dividendo sem imposto
            Provento("XPTO3", ProventoTipo.DIVIDENDO, LocalDate.parse("2026-05-10"), 0.5, LocalDate.parse("2026-04-01")),
            // ainda não pago
            Provento("XPTO3", ProventoTipo.DIVIDENDO, LocalDate.parse("2026-12-10"), 9.0, LocalDate.parse("2026-11-01")),
        )
        val total = DividendCalculator.received(lancs, prov, today = LocalDate.parse("2026-10-28"))
        assertEquals(10 * 0.85 + 20 * 0.5, total, 1e-9)
    }

    @Test
    fun `eventos informam bruto liquido e imposto retido`() {
        val lancs = listOf(lanc(1, LancamentoTipo.COMPRA, 100.0, 10.0, "2026-01-01"))
        val prov = listOf(
            Provento("XPTO3", ProventoTipo.JCP, LocalDate.parse("2026-03-15"), 1.0, LocalDate.parse("2026-02-01")),
        )
        val e = DividendCalculator.events(lancs, prov, today = LocalDate.parse("2026-10-28")).single()
        assertEquals(100.0, e.gross, 1e-9)
        assertEquals(85.0, e.net, 1e-9)
        assertEquals(15.0, e.tax, 1e-9)
        val custom = DividendCalculator.events(
            lancs, prov, today = LocalDate.parse("2026-10-28"), taxes = TaxRates(jcp = 0.175)
        ).single()
        assertEquals(82.5, custom.net, 1e-9)
    }

    @Test
    fun `proventos por mes somam e preenchem meses vazios`() {
        val today = LocalDate.parse("2026-10-28")
        val m = IncomeMath.monthly(
            listOf(
                LocalDate.parse("2026-10-05") to 10.0,
                LocalDate.parse("2026-10-20") to 5.0,
                LocalDate.parse("2026-08-15") to 30.0,
                LocalDate.parse("2025-01-15") to 99.0, // fora da janela de 12 meses
            ),
            today,
        )
        assertEquals(12, m.size)
        assertEquals(java.time.YearMonth.of(2025, 11), m.first().month)
        assertEquals(java.time.YearMonth.of(2026, 10), m.last().month)
        assertEquals(15.0, m.last().value, 1e-9)
        assertEquals(30.0, m[m.size - 3].value, 1e-9)
        assertEquals(0.0, m[m.size - 2].value, 1e-9)
        assertEquals((15.0 + 0.0 + 30.0 + 0.0 + 0.0 + 0.0) / 6, IncomeMath.average(m, 6), 1e-9)
    }

    // ---- a versão linear precisa dar o mesmo resultado que a versão simples (O(pontos × lançamentos)) ----

    private fun reference(
        lancamentos: List<Lancamento>,
        closes: Map<String, List<ChartPoint>>,
        zone: ZoneId,
    ): List<PortfolioPoint> {
        val timeline = closes.values.flatten().map { it.epochMillis }.distinct().sorted()
        val sorted = lancamentos.sortedWith(compareBy({ it.data }, { it.id }))
        fun dateOf(t: Long): LocalDate = Instant.ofEpochMilli(t).atZone(zone).toLocalDate()
        return timeline.mapIndexed { i, t ->
            val date = dateOf(t)
            val prevDate = if (i == 0) date else dateOf(timeline[i - 1])
            val positions = PositionCalculator.calculate(sorted.filter { !it.data.isAfter(date) })
            val value = positions.sumOf { p ->
                val s = closes[p.ticker].orEmpty()
                val price = SeriesMath.lastAtOrBefore(s, t)?.value ?: s.firstOrNull()?.value ?: p.averagePrice
                p.quantity * price
            }
            val flow = if (i == 0) 0.0 else sorted
                .filter { it.data.isAfter(prevDate) && !it.data.isAfter(date) }
                .sumOf { if (it.tipo == LancamentoTipo.COMPRA) it.quantidade * it.preco else -it.quantidade * it.preco }
            PortfolioPoint(t, value, positions.sumOf { it.invested }, flow)
        }
    }

    @Test
    fun `versao linear da serie bate com a versao simples em cenarios aleatorios`() {
        val rnd = Random(42)
        val tickers = listOf("AAAA3", "BBBB4", "CCCC11")
        val start = LocalDate.parse("2026-01-01")
        repeat(60) {
            val lancs = (1..rnd.nextInt(1, 12)).map { id ->
                Lancamento(
                    id.toLong(), tickers[rnd.nextInt(tickers.size)],
                    if (rnd.nextInt(3) == 0) LancamentoTipo.VENDA else LancamentoTipo.COMPRA,
                    rnd.nextInt(1, 50).toDouble(), 5.0 + rnd.nextInt(0, 400) / 10.0,
                    start.plusDays(rnd.nextLong(0, 40)),
                )
            }
            val closes = tickers.associateWith { t ->
                (0..rnd.nextInt(5, 30)).map { d ->
                    ChartPoint(
                        start.plusDays(d.toLong() + rnd.nextLong(0, 3)).atTime(rnd.nextInt(10, 18), 0)
                            .toInstant(ZoneOffset.UTC).toEpochMilli(),
                        5.0 + rnd.nextDouble() * 40.0,
                    )
                }.sortedBy { it.epochMillis }
            }
            val expected = reference(lancs, closes, ZoneOffset.UTC)
            val actual = PerformanceCalculator.series(lancs, closes, zone = ZoneOffset.UTC)
            assertEquals(expected.size, actual.size)
            expected.zip(actual).forEach { (e, a) ->
                assertEquals(e.epochMillis, a.epochMillis)
                assertEquals(e.value, a.value, 1e-6)
                assertEquals(e.invested, a.invested, 1e-6)
                assertEquals(e.flow, a.flow, 1e-6)
            }
        }
    }
}
