package org.b3m

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import org.b3m.ui.asset.AssetScreen
import org.b3m.ui.market.MarketScreen
import org.b3m.ui.portfolio.PortfolioScreen
import org.b3m.ui.settings.SettingsScreen
import org.b3m.ui.theme.AppColors
import org.b3m.ui.theme.B3MTheme

private enum class Tab(val label: String, val icon: ImageVector) {
    MERCADO("Mercado", Icons.Default.List),
    CARTEIRA("Carteira", Icons.Default.Star),
    AJUSTES("Ajustes", Icons.Default.Settings),
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // Tema Splash (logo) fica até aqui; em seguida aplica o tema normal do app.
        setTheme(R.style.Theme_B3M)
        super.onCreate(savedInstanceState)
        AppGraph.init(this)
        setContent { B3MTheme { App() } }
    }
}

@Composable
private fun App() {
    var tab by rememberSaveable { mutableStateOf(Tab.MERCADO) }
    // Ativo aberto por cima das abas (a partir da busca, destaques, favoritos, dividendos ou carteira).
    var openTicker by rememberSaveable { mutableStateOf<String?>(null) }

    BackHandler(openTicker != null) { openTicker = null }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (openTicker == null) {
                NavigationBar(containerColor = AppColors.Background) {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = AppColors.CardAlt),
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            val ticker = openTicker
            if (ticker != null) {
                AssetScreen(ticker = ticker, onBack = { openTicker = null })
            } else when (tab) {
                Tab.MERCADO -> MarketScreen(onOpen = { openTicker = it })
                Tab.CARTEIRA -> PortfolioScreen(onOpen = { openTicker = it })
                Tab.AJUSTES -> SettingsScreen()
            }
        }
    }
}
