package org.b3m.domain

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

class ReturnCalculatorTest {

    private val today = LocalDate.of(2026, 10, 28)

    @Test
    fun `soma proventos liquidos dos ultimos 12 meses e divide por 12`() {
        val proventos = listOf(
            Provento("PETR4", ProventoTipo.DIVIDENDO, LocalDate.of(2026, 9, 1), 1.20),
            Provento("PETR4", ProventoTipo.JCP, LocalDate.of(2026, 6, 1), 1.00), // líquido 0,85
        )
        val r = ReturnCalculator.calculate(proventos, price = 50.0, today = today)
        assertEquals((1.20 + 0.85) / 12, r.retorno, 1e-9)
        assertEquals(r.retorno / 50.0 * 100, r.percentRetorno, 1e-9)
    }

    @Test
    fun `ignora proventos fora da janela`() {
        val proventos = listOf(
            Provento("VALE3", ProventoTipo.DIVIDENDO, LocalDate.of(2026, 3, 1), 5.0),
            Provento("VALE3", ProventoTipo.DIVIDENDO, LocalDate.of(2026, 12, 1), 5.0),
        )
        val r = ReturnCalculator.calculate(proventos, price = 60.0, today = today)
        assertEquals(0.0, r.retorno, 1e-9)
    }

    @Test
    fun `cotacao zero nao quebra`() {
        val r = ReturnCalculator.calculate(emptyList(), price = 0.0, today = today)
        assertEquals(0.0, r.percentRetorno, 1e-9)
    }

    @Test
    fun `aliquota configurada muda o valor liquido`() {
        val jcp = Provento("PETR4", ProventoTipo.JCP, LocalDate.of(2026, 9, 1), 1.00)
        assertEquals(0.85, ReturnCalculator.net(jcp, TaxRates()), 1e-9)
        assertEquals(0.825, ReturnCalculator.net(jcp, TaxRates(jcp = 0.175)), 1e-9)
        val div = Provento("PETR4", ProventoTipo.DIVIDENDO, LocalDate.of(2026, 9, 1), 2.00)
        assertEquals(1.8, ReturnCalculator.net(div, TaxRates(dividendo = 0.10)), 1e-9)
    }

    @Test
    fun `texto das aliquotas mostra o percentual`() {
        assertEquals("15%", TaxRates().percentText(ProventoTipo.JCP))
        assertEquals("0%", TaxRates().percentText(ProventoTipo.DIVIDENDO))
        assertEquals("17,5%", TaxRates(jcp = 0.175).percentText(ProventoTipo.JCP))
        assertEquals("10%", TaxRates(dividendo = 0.10).percentText(ProventoTipo.DIVIDENDO))
        assertEquals(
            "JCP 15% · dividendos 0% · rendimentos de FIIs 0%",
            TaxRates().summary(),
        )
    }

    @Test
    fun `aliquota invalida e limitada entre 0 e 100 por cento`() {
        assertEquals(1.0, TaxRates().with(ProventoTipo.JCP, 3.0).jcp, 0.0)
        assertEquals(0.0, TaxRates().with(ProventoTipo.JCP, -1.0).jcp, 0.0)
        assertEquals(0.0, TaxRates().with(ProventoTipo.JCP, Double.NaN).jcp, 0.0)
    }
}
