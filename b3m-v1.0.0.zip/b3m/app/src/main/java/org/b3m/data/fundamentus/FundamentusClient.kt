package org.b3m.data.fundamentus

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import org.b3m.data.AsyncCache
import org.b3m.data.quotes.getString
import org.b3m.domain.Provento
import org.b3m.domain.ProventoTipo
import org.jsoup.Jsoup

/**
 * Cliente do Fundamentus (sem API oficial: lemos o HTML).
 *
 * ATENÇÃO: parsers escritos pela estrutura conhecida das páginas e AINDA NÃO validados
 * contra o site real. Se o layout mudar, só este arquivo precisa de ajuste.
 *  - detalhes.php?papel=TICKER             dados e indicadores
 *  - proventos.php?papel=TICKER&tipo=2     histórico de proventos
 *  - resultado.php                         todos os papéis (cotação, DY, liquidez)
 *
 * Os dados valem por pouco tempo na memória (2 min / 5 min / 15 min) e pedidos idênticos
 * simultâneos viram uma requisição só. As telas chamam [invalidate] ao abrir para buscar de novo.
 * O parsing roda fora da thread principal.
 */
class FundamentusClient(private val http: OkHttpClient) : FundamentusApi {

    private val base = "https://www.fundamentus.com.br"
    private val detalhesCache = AsyncCache<Detalhes>(2 * 60_000L)
    private val proventosCache = AsyncCache<List<Provento>>(5 * 60_000L)
    private val resultadoCache = AsyncCache<List<ResultadoRow>>(15 * 60_000L)

    override fun invalidate(ticker: String) {
        val key = ticker.trim().uppercase()
        detalhesCache.invalidate(key)
        proventosCache.invalidate(key)
    }

    override fun invalidateAll() {
        detalhesCache.invalidateAll()
        proventosCache.invalidateAll()
        resultadoCache.invalidateAll()
    }

    override suspend fun detalhes(ticker: String): Detalhes {
        val key = ticker.trim().uppercase()
        return detalhesCache.get(key) {
            val html = http.getString("$base/detalhes.php?papel=$key")
            withContext(Dispatchers.Default) { parseDetalhes(html, key) }
        }
    }

    private fun parseDetalhes(html: String, ticker: String): Detalhes {
        val doc = Jsoup.parse(html)
        val sections = ArrayList<DetalhesSection>()
        var title = "Geral"
        var items = ArrayList<Pair<String, String>>()
        fun flush() {
            if (items.isNotEmpty()) sections += DetalhesSection(title, items)
            items = ArrayList()
        }
        doc.select("table.w728 tr").forEach { row ->
            val cells = row.select("td")
            val header = cells.firstOrNull { it.hasClass("nivel1") }
            if (header != null) {
                flush()
                title = header.text().trim()
                return@forEach
            }
            var i = 0
            while (i + 1 < cells.size) {
                if (cells[i].hasClass("label")) {
                    val label = cells[i].select("span.txt").lastOrNull()?.text()?.trim().orEmpty()
                    val value = cells[i + 1].text().trim()
                    if (label.isNotEmpty() && label != "?") items += label to value
                    i += 2
                } else {
                    i += 1
                }
            }
        }
        flush()
        check(sections.isNotEmpty()) { "Fundamentus: papel $ticker não encontrado" }
        return Detalhes(sections)
    }

    override suspend fun proventos(ticker: String): List<Provento> {
        val key = ticker.trim().uppercase()
        return proventosCache.get(key) {
            // FII: histórico de rendimentos em fii_proventos.php (colunas diferentes das ações).
            if (isFiiTicker(key)) {
                val fiiHtml = runCatching {
                    http.getString("$base/fii_proventos.php?papel=$key&tipo=2")
                }.getOrDefault("")
                val fii = withContext(Dispatchers.Default) { parseFiiProventos(fiiHtml, key) }
                if (fii.isNotEmpty()) return@get fii
            }

            // Ações (e fallback): proventos.php
            val primary = safelyParseProventos(http.getString("$base/proventos.php?papel=$key&tipo=2"), key)
            if (primary.isNotEmpty()) return@get primary
            val alt = safelyParseProventos(
                runCatching { http.getString("$base/proventos.php?papel=$key&tipo=1") }.getOrDefault(""),
                key,
            )
            if (alt.isNotEmpty()) return@get alt

            // FII sem fii_proventos: tenta detalhes + Status Invest
            if (isFiiTicker(key)) {
                val detHtml = runCatching { http.getString("$base/detalhes.php?papel=$key") }.getOrDefault("")
                val fromDet = withContext(Dispatchers.Default) { parseProventosFromDetalhes(detHtml, key) }
                if (fromDet.isNotEmpty()) return@get fromDet
                val si = runCatching {
                    http.getString("https://statusinvest.com.br/fundos-imobiliarios/${key.lowercase()}")
                }.getOrDefault("")
                return@get withContext(Dispatchers.Default) { parseStatusInvestFii(si, key) }
            }
            emptyList()
        }
    }

    private fun isFiiTicker(ticker: String): Boolean =
        ticker.endsWith("11") || ticker.endsWith("11B")

    private suspend fun safelyParseProventos(html: String, ticker: String): List<Provento> =
        if (html.isBlank()) emptyList()
        else withContext(Dispatchers.Default) { parseProventos(html, ticker) }

    private fun parseProventos(html: String, ticker: String): List<Provento> {
        val doc = Jsoup.parse(html)
        val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        val rows = doc.select("table#resultado tbody tr")
        if (rows.isEmpty()) return emptyList()
        return rows.mapNotNull { tr ->
            val td = tr.select("td")
            if (td.size < 4) return@mapNotNull null
            runCatching {
                val tipoRaw = td[2].text().trim().uppercase()
                val per = td.getOrNull(4)?.text()?.let { parseBR(it) }?.takeIf { it > 0 } ?: 1.0
                val valor = parseBR(td[1].text()) ?: return@runCatching null
                Provento(
                    ticker = ticker,
                    tipo = when {
                        "JCP" in tipoRaw || "JRS" in tipoRaw -> ProventoTipo.JCP
                        "REND" in tipoRaw -> ProventoTipo.RENDIMENTO
                        else -> if (ticker.endsWith("11")) ProventoTipo.RENDIMENTO else ProventoTipo.DIVIDENDO
                    },
                    dataPagamento = LocalDate.parse(td[3].text().trim(), fmt),
                    valorBruto = valor / per,
                    dataCom = runCatching { LocalDate.parse(td[0].text().trim(), fmt) }.getOrNull(),
                )
            }.getOrNull()
        }
    }

    /**
     * Fundamentus FII — fii_proventos.php
     * Colunas: Última Data Com | Tipo | Data de Pagamento | Valor
     * (ordem diferente de proventos.php das ações).
     */
    private fun parseFiiProventos(html: String, ticker: String): List<Provento> {
        if (html.isBlank()) return emptyList()
        val doc = Jsoup.parse(html)
        val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        val rows = doc.select("table#resultado tbody tr")
        if (rows.isEmpty()) return emptyList()
        return rows.mapNotNull { tr ->
            val td = tr.select("td")
            if (td.size < 4) return@mapNotNull null
            runCatching {
                val dataCom = runCatching { LocalDate.parse(td[0].text().trim(), fmt) }.getOrNull()
                val tipoRaw = td[1].text().trim().uppercase()
                val dataPag = LocalDate.parse(td[2].text().trim(), fmt)
                val valor = parseBR(td[3].text()) ?: return@runCatching null
                if (valor <= 0.0) return@runCatching null
                Provento(
                    ticker = ticker,
                    tipo = when {
                        "JCP" in tipoRaw || "JRS" in tipoRaw -> ProventoTipo.JCP
                        "REND" in tipoRaw -> ProventoTipo.RENDIMENTO
                        "AMORT" in tipoRaw -> ProventoTipo.RENDIMENTO
                        else -> ProventoTipo.RENDIMENTO
                    },
                    dataPagamento = dataPag,
                    valorBruto = valor,
                    dataCom = dataCom,
                )
            }.getOrNull()
        }.sortedByDescending { it.dataPagamento }
    }

    /**
     * Em alguns FIIs o Fundamentus só mostra proventos na tabela de detalhes
     * (colunas Data / Valor / Tipo ou semelhante).
     */
    private fun parseProventosFromDetalhes(html: String, ticker: String): List<Provento> {
        if (html.isBlank()) return emptyList()
        val doc = Jsoup.parse(html)
        val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        val out = ArrayList<Provento>()
        doc.select("table").forEach { table ->
            val heads = table.select("thead th, tr").firstOrNull()?.select("th, td")
                ?.map { it.text().lowercase() }.orEmpty()
            val looksLikeProv = heads.any { h ->
                h.contains("provento") || h.contains("rendimento") || h.contains("pagamento") ||
                    (h.contains("data") && heads.any { it.contains("valor") })
            } || table.select("td").any { td ->
                val s = td.text().uppercase()
                s.contains("RENDIMENTO") || s.contains("DIVIDENDO")
            }
            if (!looksLikeProv) return@forEach
            table.select("tbody tr, tr").forEach { tr ->
                val td = tr.select("td")
                if (td.size < 3) return@forEach
                runCatching {
                    // tenta achar data e valor em qualquer ordem comum
                    val texts = td.map { it.text().trim() }
                    val dates = texts.mapNotNull { runCatching { LocalDate.parse(it, fmt) }.getOrNull() }
                    val valores = texts.mapNotNull { parseBR(it)?.takeIf { v -> v > 0 && v < 1000 } }
                    val tipoTxt = texts.firstOrNull { t ->
                        val u = t.uppercase()
                        "REND" in u || "DIV" in u || "JCP" in u || "JRS" in u
                    }?.uppercase().orEmpty()
                    if (dates.isEmpty() || valores.isEmpty()) return@runCatching
                    val pag = dates.last()
                    val com = dates.firstOrNull()
                    out += Provento(
                        ticker = ticker,
                        tipo = when {
                            "JCP" in tipoTxt || "JRS" in tipoTxt -> ProventoTipo.JCP
                            "REND" in tipoTxt || ticker.endsWith("11") -> ProventoTipo.RENDIMENTO
                            else -> ProventoTipo.DIVIDENDO
                        },
                        dataPagamento = pag,
                        valorBruto = valores.first(),
                        dataCom = com,
                    )
                }
            }
        }
        return out.distinctBy { listOf(it.dataPagamento, it.valorBruto, it.tipo) }
            .sortedByDescending { it.dataPagamento }
    }

    /** Ações + FIIs (resultado.php e fii_resultado.php). */
    override suspend fun resultado(): List<ResultadoRow> = resultadoCache.get("all") {
        coroutineScope {
            val acoes = async {
                val html = http.getString("$base/resultado.php")
                withContext(Dispatchers.Default) { parseResultado(html, stock = true) }
            }
            val fiis = async {
                runCatching {
                    val html = http.getString("$base/fii_resultado.php")
                    withContext(Dispatchers.Default) { parseResultado(html, stock = false) }
                }.getOrDefault(emptyList())
            }
            acoes.await() + fiis.await()
        }
    }

    private fun parseResultado(html: String, stock: Boolean): List<ResultadoRow> {
        val doc = Jsoup.parse(html)
        val heads = doc.select("table#resultado thead th").map { it.text().lowercase().replace(" ", "") }
        val iPapel = heads.indexOfFirst { it.startsWith("papel") }
        val iCot = heads.indexOfFirst { it.startsWith("cota") }
        // Ações: Div.Yield · FIIs: Dividend Yield / DY
        val iDy = heads.indexOfFirst { it.startsWith("div") || it == "dy" || it.contains("yield") }
        val iLiq = heads.indexOfFirst { it.startsWith("liq") }
        check(iPapel >= 0 && iCot >= 0 && iDy >= 0) {
            "Fundamentus: layout de ${if (stock) "resultado" else "fii_resultado"}.php mudou"
        }
        return doc.select("table#resultado tbody tr").mapNotNull { tr ->
            val td = tr.select("td")
            val price = td.getOrNull(iCot)?.text()?.let { parseBR(it) } ?: return@mapNotNull null
            ResultadoRow(
                ticker = td.getOrNull(iPapel)?.text()?.trim()?.uppercase() ?: return@mapNotNull null,
                price = price,
                dividendYield = td.getOrNull(iDy)?.text()?.let { parseBR(it) } ?: 0.0,
                liquidity = if (iLiq >= 0) td.getOrNull(iLiq)?.text()?.let { parseBR(it) } ?: 0.0 else 0.0,
            )
        }
    }

    /**
     * Status Invest — proventos de FII (datas dd/MM/yyyy e valores BR).
     */
    private fun parseStatusInvestFii(html: String, ticker: String): List<Provento> {
        if (html.isBlank()) return emptyList()
        val doc = Jsoup.parse(html)
        val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
        val out = ArrayList<Provento>()
        doc.select("table tbody tr, div.list div.item").forEach { row ->
            val text = row.text()
            val dates = Regex("""(\d{2}/\d{2}/\d{4})""").findAll(text).map { it.groupValues[1] }.toList()
            val vals = Regex("""(\d+,\d{2,8})""").findAll(text).mapNotNull { parseBR(it.groupValues[1]) }.filter { it in 0.001..50.0 }.toList()
            if (dates.isEmpty() || vals.isEmpty()) return@forEach
            runCatching {
                val pag = LocalDate.parse(dates.last(), fmt)
                val com = dates.firstOrNull()?.let { LocalDate.parse(it, fmt) }
                out += Provento(
                    ticker = ticker,
                    tipo = ProventoTipo.RENDIMENTO,
                    dataPagamento = pag,
                    valorBruto = vals.first(),
                    dataCom = com,
                )
            }
        }
        return out.distinctBy { it.dataPagamento to it.valorBruto }
            .sortedByDescending { it.dataPagamento }
            .take(48)
    }

}
