package org.b3m.ui.portfolio

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.b3m.data.db.LancamentoRepository
import org.b3m.data.db.tryAdd
import org.b3m.data.db.tryRemove
import org.b3m.data.fundamentus.FundamentusApi
import org.b3m.data.market.BenchmarkSource
import org.b3m.data.quotes.ChartPoint
import org.b3m.data.quotes.ChartRange
import org.b3m.data.quotes.QuoteRepository
import org.b3m.data.quotes.Symbols
import org.b3m.data.safely
import org.b3m.data.snapshot.DataCodecs
import org.b3m.data.snapshot.Snapshots
import org.b3m.data.snapshot.Stamped
import org.b3m.domain.DividendCalculator
import org.b3m.domain.IncomeEvent
import org.b3m.domain.IncomeMath
import org.b3m.domain.Lancamento
import org.b3m.domain.MonthValue
import org.b3m.domain.PerformanceCalculator
import org.b3m.domain.Position
import org.b3m.domain.PositionCalculator
import org.b3m.domain.Provento
import org.b3m.domain.Quote
import org.b3m.domain.SeriesMath
import org.b3m.domain.TaxRates

enum class PositionSort(val label: String) {
    VALUE("Valor"), RESULT("Resultado"), DAY("Dia"), TICKER("A–Z")
}

/** Séries que podem ser sobrepostas ao desempenho da carteira (a cor de cada uma fica na tela). */
enum class Benchmark(val label: String) { IBOV("IBOV"), CDI("CDI"), IPCA("IPCA") }

/**
 * Um ativo da carteira. [quote] é null quando nunca houve cotação (aí vale o preço médio e a
 * tela avisa); [stale] = a coleta nova falhou e a cotação é a última guardada.
 */
data class PositionUi(
    val position: Position,
    val quote: Quote?,
    val stale: Boolean,
    val weight: Double, // % do patrimônio
    val dividendsNet: Double = 0.0, // proventos líquidos desde a compra
) {
    val price: Double get() = quote?.price ?: position.averagePrice
    val value: Double get() = position.quantity * price
    /** Só cotações (marcação a mercado vs preço médio). */
    val result: Double get() = value - position.invested
    val resultPct: Double get() = if (position.invested > 0) result / position.invested * 100 else 0.0
    /** Cotações + proventos líquidos. */
    val totalResult: Double get() = result + dividendsNet
    val totalResultPct: Double get() = if (position.invested > 0) totalResult / position.invested * 100 else 0.0

    /** Variação do dia em R$, deduzida da % do dia e da cotação. */
    val dayChange: Double
        get() = quote?.takeIf { !stale }?.let {
            position.quantity * it.price * (it.changePct / 100) / (1 + it.changePct / 100)
        } ?: 0.0
}

data class PerformanceState(
    val range: ChartRange = ChartRange.M1,
    val loading: Boolean = true,
    val error: String? = null,
    val twr: List<ChartPoint> = emptyList(),
    val benchmarks: Map<Benchmark, List<ChartPoint>> = emptyMap(),
    val enabled: Set<Benchmark> = setOf(Benchmark.IBOV, Benchmark.CDI),
    val note: String? = null,
    val updatedAt: Long? = null,
    val stale: Boolean = false,
)

data class EvolutionState(
    val range: ChartRange = ChartRange.M6,
    val loading: Boolean = true,
    val error: String? = null,
    val patrimonio: List<ChartPoint> = emptyList(),
    val investido: List<ChartPoint> = emptyList(),
    val updatedAt: Long? = null,
    val stale: Boolean = false,
)

/**
 * Proventos recebidos dos ativos que estão na carteira. Todos os valores são líquidos do
 * imposto das Ajustes ([events] guarda bruto e líquido de cada pagamento).
 * Proventos de posições já vendidas por inteiro não entram (regra do app).
 */
data class IncomeUi(
    val events: List<IncomeEvent> = emptyList(),
    val future: List<IncomeEvent> = emptyList(),
    val monthly: List<MonthValue> = emptyList(), // últimos 12 meses, líquido
    val loading: Boolean = true,
    val failedTickers: List<String> = emptyList(), // sem proventos e sem coleta anterior: tentando de novo
    val updatedAt: Long? = null,
    val stale: Boolean = false,
) {
    val totalNet: Double get() = events.sumOf { it.net }
    val totalTax: Double get() = events.sumOf { it.tax }
    val futureNet: Double get() = future.sumOf { it.net }

    /** Renda mensal estimada: média dos últimos 12 meses (o mês atual entra). */
    val average6: Double get() = IncomeMath.average(monthly, 12)
    val last12: Double get() = monthly.sumOf { it.value }
}

data class PortfolioUi(
    val loaded: Boolean = false,
    val positions: List<PositionUi> = emptyList(),
    val sort: PositionSort = PositionSort.VALUE,
    val lancamentos: List<Lancamento> = emptyList(),
    val taxes: TaxRates = TaxRates(),
    val quotesAt: Long? = null,
    val quotesStale: Boolean = false,
    val missingQuotes: List<String> = emptyList(),
    val income: IncomeUi = IncomeUi(),
    val performance: PerformanceState = PerformanceState(),
    val evolution: EvolutionState = EvolutionState(),
) {
    val patrimonio: Double get() = positions.sumOf { it.value }
    val investido: Double get() = positions.sumOf { it.position.invested }
    val resultado: Double get() = patrimonio - investido
    val resultadoPct: Double get() = if (investido > 0) resultado / investido * 100 else 0.0
    val dividends: Double get() = income.totalNet
    val resultadoTotal: Double get() = resultado + dividends
    val resultadoTotalPct: Double get() = if (investido > 0) resultadoTotal / investido * 100 else 0.0
    val gastoReal: Double get() = investido - dividends
    /** (investido − proventos) ÷ quantidade total. */
    val gastoRealPorAcao: Double
        get() {
            val q = positions.sumOf { it.position.quantity }
            return if (q > 0) gastoReal / q else 0.0
        }
    val dayChange: Double get() = positions.sumOf { it.dayChange }
    val dayChangePct: Double
        get() = (patrimonio - dayChange).takeIf { it > 0 }?.let { dayChange / it * 100 } ?: 0.0
}

/**
 * Tela Carteira. [start] quando a tela aparece (descarta os caches e busca tudo de novo,
 * mostrando antes o último dado guardado) e [stop] quando ela sai de vista.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class PortfolioViewModel(
    private val repository: LancamentoRepository,
    private val quotes: QuoteRepository,
    private val fundamentus: FundamentusApi,
    private val bcb: BenchmarkSource,
    private val snapshots: Snapshots,
    private val codecs: DataCodecs,
    taxes: StateFlow<TaxRates>,
    private val refreshMs: Long = 15_000,
    private val retryMs: Long = RETRY_MS,
    private val zone: ZoneId = ZoneId.systemDefault(),
) : ViewModel() {

    private class Closes(
        val map: Map<String, List<ChartPoint>>,
        val missing: List<String>,
        val updatedAt: Long?,
        val stale: Boolean,
    )

    /** Base do gráfico de desempenho; o TWR em si é calculado junto com os proventos, em [buildPerformance]. */
    private data class PerfBase(
        val range: ChartRange = ChartRange.M1,
        val loading: Boolean = true,
        val error: String? = null,
        val lancamentos: List<Lancamento> = emptyList(),
        val closes: Map<String, List<ChartPoint>> = emptyMap(),
        val benchmarks: Map<Benchmark, List<ChartPoint>> = emptyMap(),
        val note: String? = null,
        val updatedAt: Long? = null,
        val stale: Boolean = false,
    )

    private data class ProventosState(
        val byTicker: Map<String, Stamped<List<Provento>>> = emptyMap(),
        val failed: Set<String> = emptySet(),
        val loading: Boolean = true,
    )

    private val quoteMap = MutableStateFlow<Map<String, Stamped<Quote>>>(emptyMap())
    private val proventos = MutableStateFlow(ProventosState())
    private val perf = MutableStateFlow(PerfBase())
    private val evo = MutableStateFlow(EvolutionState())
    private val perfRange = MutableStateFlow(ChartRange.M1)
    private val evoRange = MutableStateFlow(ChartRange.M6)
    private val enabled = MutableStateFlow(setOf(Benchmark.IBOV, Benchmark.CDI))
    private val sort = MutableStateFlow(PositionSort.VALUE)

    private var job: Job? = null

    /** null até a primeira leitura do banco (para a tela não piscar "carteira vazia"). */
    private val lancamentos: StateFlow<List<Lancamento>?> = repository.observe()
        .map<List<Lancamento>, List<Lancamento>?> { it }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private data class Base(
        val lancamentos: List<Lancamento>?,
        val quotes: Map<String, Stamped<Quote>>,
        val proventos: ProventosState,
        val sort: PositionSort,
        val taxes: TaxRates,
    )

    val ui: StateFlow<PortfolioUi> = combine(
        combine(lancamentos, quoteMap, proventos, sort, taxes) { l, q, p, s, t -> Base(l, q, p, s, t) },
        perf, evo, enabled,
    ) { b, pf, ev, en -> derive(b, pf, ev, en) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PortfolioUi(taxes = taxes.value))

    private fun derive(b: Base, pf: PerfBase, ev: EvolutionState, en: Set<Benchmark>): PortfolioUi {
        val list = b.lancamentos ?: return PortfolioUi(loaded = false, taxes = b.taxes, sort = b.sort)
        val open = PositionCalculator.calculate(list)
        val openTickers = open.map { it.ticker }.toSet()

        // cotações
        val used = openTickers.mapNotNull { t -> b.quotes[t]?.let { t to it } }.toMap()
        val totalValue = open.sumOf { p -> p.quantity * (used[p.ticker]?.value?.price ?: p.averagePrice) }
        // proventos por ticker (só de quem está em carteira) — calculados antes para anexar em cada posição
        val provMapEarly = b.proventos.byTicker.filterKeys { it in openTickers }
        val eventsEarly = incomeEvents(list, provMapEarly, b.taxes)
        val divByTicker = eventsEarly.groupBy { it.ticker.uppercase() }.mapValues { (_, v) -> v.sumOf { it.net } }

        val positions = open.map { p ->
            val q = used[p.ticker]
            val value = p.quantity * (q?.value?.price ?: p.averagePrice)
            PositionUi(
                p, q?.value, q?.stale ?: false,
                if (totalValue > 0) value / totalValue * 100 else 0.0,
                dividendsNet = divByTicker[p.ticker] ?: 0.0,
            )
        }.let { ps ->
            when (b.sort) {
                PositionSort.VALUE -> ps.sortedByDescending { it.value }
                PositionSort.RESULT -> ps.sortedByDescending { it.result }
                PositionSort.DAY -> ps.sortedByDescending { it.dayChange }
                PositionSort.TICKER -> ps.sortedBy { it.position.ticker }
            }
        }

        // proventos (só de quem está em carteira)
        val provMap = b.proventos.byTicker.filterKeys { it in openTickers }
        val events = incomeEvents(list, provMap, b.taxes)
        val future = incomeFutureEvents(list, provMap, b.taxes)
        val monthly = IncomeMath.monthly(events.map { it.date to it.net }, LocalDate.now(zone), 12)
        val income = IncomeUi(
            events = events,
            future = future,
            monthly = monthly,
            loading = b.proventos.loading && openTickers.any { it !in b.proventos.byTicker },
            failedTickers = openTickers.filter { it in b.proventos.failed && it !in b.proventos.byTicker }.sorted(),
            updatedAt = provMap.values.minOfOrNull { it.fetchedAt },
            stale = provMap.values.any { it.stale },
        )

        return PortfolioUi(
            loaded = true,
            positions = positions,
            sort = b.sort,
            lancamentos = list,
            taxes = b.taxes,
            quotesAt = used.values.minOfOrNull { it.fetchedAt },
            quotesStale = used.values.any { it.stale },
            missingQuotes = openTickers.filter { it !in used }.sorted(),
            income = income,
            performance = buildPerformance(pf, en, incomeEvents(pf.lancamentos, provMap, b.taxes)),
            evolution = ev,
        )
    }

    private fun incomeEvents(
        list: List<Lancamento>,
        provMap: Map<String, Stamped<List<Provento>>>,
        taxes: TaxRates,
    ): List<IncomeEvent> = DividendCalculator.eventsAll(
        list, provMap.mapValues { it.value.value }, LocalDate.now(zone), taxes,
    )

    private fun incomeFutureEvents(
        list: List<Lancamento>,
        provMap: Map<String, Stamped<List<Provento>>>,
        taxes: TaxRates,
    ): List<IncomeEvent> = DividendCalculator.futureEventsAll(
        list, provMap.mapValues { it.value.value }, LocalDate.now(zone), taxes,
    )

    /** TWR com os proventos líquidos recebidos contando como retorno (na data de pagamento). */
    private fun buildPerformance(base: PerfBase, en: Set<Benchmark>, income: List<IncomeEvent>): PerformanceState {
        val twr = if (base.error != null || base.closes.isEmpty()) {
            emptyList()
        } else {
            val points = PerformanceCalculator.series(base.lancamentos, base.closes, income, zone).dropWhile { it.value <= 0 }
            PerformanceCalculator.twr(points)
        }
        return PerformanceState(
            range = base.range,
            loading = base.loading,
            error = base.error,
            twr = twr,
            benchmarks = base.benchmarks,
            enabled = en,
            note = base.note,
            updatedAt = base.updatedAt,
            stale = base.stale,
        )
    }

    // ---- ciclo de vida da tela ---------------------------------------------------------

    fun start() {
        if (job?.isActive == true) return
        quotes.invalidateQuotes()
        job = viewModelScope.launch {
            supervisorScope {
                launch { quotesLoop() }
                launch { proventosLoop() }
                launch { performanceLoop() }
                launch { evolutionLoop() }
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    /** Botão "atualizar". */
    fun refresh() {
        if (job == null) return
        stop()
        start()
    }

    private fun tickersOf(list: List<Lancamento>) = PositionCalculator.calculate(list).map { it.ticker }

    // ---- cotações -----------------------------------------------------------------------

    private suspend fun quotesLoop() {
        lancamentos.filterNotNull().map { tickersOf(it) }.distinctUntilChanged().collectLatest { tickers ->
            if (tickers.isEmpty()) {
                quoteMap.value = emptyMap()
                return@collectLatest
            }
            // Mostra já o último dado guardado; o que já está na memória (mais novo) tem prioridade.
            val restored = quotes.lastKnownQuotes(tickers)
            quoteMap.update { cur -> restored + cur.filterKeys { it in tickers } }
            while (true) {
                quoteMap.value = quotes.quotes(tickers)
                delay(refreshMs)
            }
        }
    }

    // ---- proventos ----------------------------------------------------------------------

    private suspend fun proventosLoop() {
        lancamentos.filterNotNull().map { tickersOf(it) }.distinctUntilChanged().collectLatest { tickers ->
            if (tickers.isEmpty()) {
                proventos.value = ProventosState(loading = false)
                return@collectLatest
            }
            val restored = tickers.mapNotNull { t ->
                snapshots.lastKnown(proventosKey(t), codecs.proventos)?.let { t to it }
            }.toMap()
            proventos.update { cur -> ProventosState(restored + cur.byTicker.filterKeys { it in tickers }, cur.failed, loading = true) }

            var pending = tickers
            var first = true
            while (pending.isNotEmpty()) {
                val gate = Semaphore(4)
                val failed = coroutineScope {
                    pending.map { t ->
                        async { gate.withPermit { t to loadProventos(t, invalidate = first) } }
                    }.awaitAll()
                }.filter { !it.second }.map { it.first }
                proventos.update { it.copy(loading = false, failed = failed.toSet()) }
                first = false
                pending = failed
                if (pending.isNotEmpty()) delay(retryMs) // tenta de novo só o que falhou, sem marcar "sem proventos"
            }
        }
    }

    /** true = coleta nova funcionou. false = falhou (fica o último dado guardado, se houver). */
    private suspend fun loadProventos(ticker: String, invalidate: Boolean): Boolean {
        if (invalidate) fundamentus.invalidate(ticker)
        return safely {
            snapshots.fetch(proventosKey(ticker), codecs.proventos) { fundamentus.proventos(ticker) }
        }.fold(
            onSuccess = { s ->
                proventos.update { it.copy(byTicker = it.byTicker + (ticker to s)) }
                !s.stale
            },
            onFailure = { false },
        )
    }

    private fun proventosKey(t: String) = "proventos:${t.uppercase()}"

    // ---- gráficos -----------------------------------------------------------------------

    private suspend fun performanceLoop() {
        combine(lancamentos.filterNotNull(), perfRange) { l, r -> l to r }
            .collectLatest { (l, r) -> loadPerformance(l, r) }
    }

    private suspend fun evolutionLoop() {
        combine(lancamentos.filterNotNull(), evoRange) { l, r -> l to r }
            .collectLatest { (l, r) -> loadEvolution(l, r) }
    }

    private suspend fun fetchCloses(list: List<Lancamento>, range: ChartRange): Closes = coroutineScope {
        val tickers = list.map { it.ticker.uppercase() }.distinct()
        val results = tickers.map { t -> async { t to safely { quotes.chart(t, range) }.getOrNull() } }.awaitAll()
        val ok = results.mapNotNull { (t, s) -> s?.takeIf { it.value.isNotEmpty() }?.let { t to it } }
        Closes(
            map = ok.associate { (t, s) -> t to s.value },
            missing = results.filter { it.second?.value.isNullOrEmpty() }.map { it.first },
            updatedAt = ok.minOfOrNull { it.second.fetchedAt },
            stale = ok.any { it.second.stale },
        )
    }

    private suspend fun loadPerformance(list: List<Lancamento>, range: ChartRange) {
        if (list.isEmpty()) {
            perf.value = PerfBase(range = range, loading = false)
            return
        }
        perf.update { it.copy(range = range, loading = true, error = null, note = null) }
        val c = fetchCloses(list, range)
        val points = withContext(Dispatchers.Default) {
            PerformanceCalculator.series(list, c.map, zone = zone).dropWhile { it.value <= 0 }
        }
        if (points.size < 2) {
            perf.value = PerfBase(
                range = range, loading = false, error = "Sem histórico para o período.",
                lancamentos = list, updatedAt = c.updatedAt, stale = c.stale,
            )
            return
        }
        val timeline = points.map { it.epochMillis }
        val start = timeline.first()
        val startDate = Instant.ofEpochMilli(start).atZone(zone).toLocalDate()
        val intraday = range.isIntraday

        data class Bench(val series: List<ChartPoint>?, val at: Long?, val stale: Boolean)

        val (bench, benchAt, benchStale) = coroutineScope {
            val ibov = async {
                safely { quotes.chart(Symbols.IBOV, range) }.getOrNull()?.let { s ->
                    val aligned = SeriesMath.rebasePct(s.value.filter { it.epochMillis >= start }).let { SeriesMath.align(timeline, it) }
                    Bench(aligned, s.fetchedAt, s.stale)
                }
            }
            // CDI e IPCA são séries diárias/mensais: não fazem sentido dentro do dia.
            val cdi = async {
                if (intraday) null else safely { bcb.cdiAccumulated(startDate) }.getOrNull()?.let { SeriesMath.align(timeline, it) }
            }
            val ipca = async {
                if (intraday) null else safely { bcb.ipcaAccumulated(startDate) }.getOrNull()?.let { SeriesMath.align(timeline, it) }
            }
            val ibovResult = ibov.await()
            val map = buildMap {
                ibovResult?.series?.takeIf { it.size >= 2 }?.let { put(Benchmark.IBOV, it) }
                cdi.await()?.takeIf { it.size >= 2 }?.let { put(Benchmark.CDI, it) }
                ipca.await()?.takeIf { it.size >= 2 }?.let { put(Benchmark.IPCA, it) }
            }
            Triple(map, ibovResult?.at, ibovResult?.stale ?: false)
        }
        val notes = buildList {
            if (c.missing.isNotEmpty()) add("Sem histórico de ${c.missing.joinToString()}: usando preço médio.")
            if (intraday) add("CDI e IPCA aparecem a partir de 1 mês.")
        }
        perf.value = PerfBase(
            range = range,
            loading = false,
            lancamentos = list,
            closes = c.map,
            benchmarks = bench,
            note = notes.joinToString(" ").ifBlank { null },
            updatedAt = listOfNotNull(c.updatedAt, benchAt).minOrNull(),
            stale = c.stale || benchStale,
        )
    }

    private suspend fun loadEvolution(list: List<Lancamento>, range: ChartRange) {
        if (list.isEmpty()) {
            evo.value = EvolutionState(range = range, loading = false)
            return
        }
        evo.update { it.copy(range = range, loading = true, error = null) }
        val c = fetchCloses(list, range)
        val points = withContext(Dispatchers.Default) {
            PerformanceCalculator.series(list, c.map, zone = zone).dropWhile { it.value <= 0 }
        }
        if (points.size < 2) {
            evo.value = EvolutionState(range = range, loading = false, error = "Sem histórico para o período.", updatedAt = c.updatedAt, stale = c.stale)
            return
        }
        evo.value = EvolutionState(
            range = range,
            loading = false,
            error = if (c.missing.isEmpty()) null else "Sem histórico de ${c.missing.joinToString()}.",
            patrimonio = points.map { ChartPoint(it.epochMillis, it.value) },
            investido = points.map { ChartPoint(it.epochMillis, it.invested) },
            updatedAt = c.updatedAt,
            stale = c.stale,
        )
    }

    // ---- ações da tela -------------------------------------------------------------------

    fun selectSort(s: PositionSort) { sort.value = s }

    fun selectPerformanceRange(r: ChartRange) {
        if (r == perfRange.value) return
        // Limpa série antiga para o gráfico mudar de imediato ao trocar o período.
        perfRange.value = r
        perf.value = PerfBase(range = r, loading = true)
    }

    fun selectEvolutionRange(r: ChartRange) {
        if (r == evoRange.value) return
        evoRange.value = r
        evo.value = EvolutionState(range = r, loading = true)
    }

    fun toggleBenchmark(b: Benchmark) = enabled.update { if (b in it) it - b else it + b }

    /** Valida e grava. [onResult] recebe a mensagem de erro, ou null se deu certo. */
    fun add(l: Lancamento, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.tryAdd(l)) }
    }

    fun remove(id: Long, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repository.tryRemove(id)) }
    }

    companion object {
        const val RETRY_MS = 60_000L
    }
}
