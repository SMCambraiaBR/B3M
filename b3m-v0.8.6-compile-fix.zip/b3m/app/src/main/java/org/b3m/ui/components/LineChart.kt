package org.b3m.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.b3m.data.quotes.ChartPoint
import org.b3m.domain.SeriesMath
import org.b3m.ui.theme.AppColors

data class ChartSeries(
    val name: String,
    val points: List<ChartPoint>,
    val color: Color,
    val fill: Boolean = false,
)

/** Cor padrão de um gráfico de uma série só: verde se terminou acima do início, vermelho se abaixo. */
fun trendColor(points: List<ChartPoint>): Color {
    val first = points.firstOrNull()?.value ?: return AppColors.Neutral
    val last = points.lastOrNull()?.value ?: return AppColors.Neutral
    return AppColors.forChange(last - first)
}

/**
 * Gráfico de linhas com toque: encostar o dedo e arrastar mostra o valor (e a hora/data)
 * de cada série no ponto selecionado.
 */
@Composable
fun LineChart(
    series: List<ChartSeries>,
    valueFormat: (Double) -> String,
    timeFormat: (Long) -> String,
    modifier: Modifier = Modifier,
    zeroLine: Boolean = false,
    height: androidx.compose.ui.unit.Dp = 220.dp,
) {
    // Com 1 ponto só, repete o ponto com +1s para o traço aparecer (evita gráfico vazio).
    val data = series.mapNotNull { s ->
        when {
            s.points.size >= 2 -> s
            s.points.size == 1 -> s.copy(
                points = listOf(
                    s.points[0],
                    s.points[0].copy(epochMillis = s.points[0].epochMillis + 1_000),
                ),
            )
            else -> null
        }
    }
    if (data.isEmpty()) {
        Box(modifier.height(height), contentAlignment = Alignment.Center) {
            Text("Sem dados para o período", color = AppColors.Neutral)
        }
        return
    }

    val measurer = rememberTextMeasurer()
    var touchX by remember { mutableStateOf<Float?>(null) }
    val labelStyle = TextStyle(color = AppColors.Neutral, fontSize = 10.sp)
    val tipStyle = TextStyle(color = Color.White, fontSize = 12.sp)

    Canvas(
        modifier
            .height(height)
            .pointerInput(Unit) {
                // Encostar mostra o valor; arrastar na HORIZONTAL acompanha o dedo; arrastar na
                // VERTICAL devolve o gesto à lista, para a tela continuar rolando.
                awaitEachGesture {
                    val down = awaitFirstDown()
                    touchX = down.position.x
                    val slop = viewConfiguration.touchSlop
                    var horizontal = false
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull() ?: break
                        if (!horizontal && change.isConsumed) break // a lista assumiu o gesto
                        if (change.pressed) {
                            val dx = kotlin.math.abs(change.position.x - down.position.x)
                            val dy = kotlin.math.abs(change.position.y - down.position.y)
                            if (!horizontal && (dx > slop || dy > slop)) {
                                if (dx > dy) horizontal = true else break
                            }
                            touchX = change.position.x
                            if (horizontal) change.consume()
                        }
                    } while (event.changes.any { it.pressed })
                    touchX = null
                }
            }
    ) {
        val gutter = 54.dp.toPx()
        val labelArea = 18.dp.toPx()
        val plotW = size.width - gutter
        val plotH = size.height - labelArea

        // Evita crash quando o Canvas ainda não tem tamanho (primeiro frame) ou é
        // menor que o texto dos eixos: coerceIn(0, max) com max < 0 lança IllegalArgumentException.
        if (plotW <= 1f || plotH <= 1f) return@Canvas

        val minT = data.minOf { it.points.first().epochMillis }
        val maxT = data.maxOf { it.points.last().epochMillis }
        var minV = data.minOf { s -> s.points.minOf { it.value } }
        var maxV = data.maxOf { s -> s.points.maxOf { it.value } }
        if (zeroLine) {
            minV = minOf(minV, 0.0)
            maxV = maxOf(maxV, 0.0)
        }
        if (maxV - minV < 1e-9) {
            minV -= 1.0
            maxV += 1.0
        }
        val pad = (maxV - minV) * 0.08
        minV -= pad
        maxV += pad

        fun x(t: Long): Float = if (maxT == minT) 0f else plotW * (t - minT).toFloat() / (maxT - minT).toFloat()
        fun y(v: Double): Float {
            val range = maxV - minV
            if (range <= 0.0 || !range.isFinite()) return plotH / 2f
            val yy = (plotH * (1.0 - (v - minV) / range)).toFloat()
            return if (yy.isFinite()) yy else plotH / 2f
        }

        // grade e rótulos do eixo Y
        for (i in 0..2) {
            val v = maxV - (maxV - minV) * i / 2.0
            val yy = y(v)
            drawLine(Color(0x22FFFFFF), Offset(0f, yy), Offset(plotW, yy), strokeWidth = 1f)
            val layout = measurer.measure(valueFormat(v), labelStyle)
            val maxLy = (plotH - layout.size.height).coerceAtLeast(0f)
            val ly = (yy - layout.size.height / 2f).coerceIn(0f, maxLy)
            drawText(layout, topLeft = Offset(plotW + 6.dp.toPx(), ly))
        }

        if (zeroLine && minV < 0 && maxV > 0) {
            drawLine(
                Color(0x66FFFFFF), Offset(0f, y(0.0)), Offset(plotW, y(0.0)), strokeWidth = 1.5f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)),
            )
        }

        // rótulos do eixo X
        for (i in 0..3) {
            val frac = i / 3f
            val t = minT + ((maxT - minT) * frac).toLong()
            val layout = measurer.measure(timeFormat(t), labelStyle)
            val maxLx = (plotW - layout.size.width).coerceAtLeast(0f)
            val lx = (plotW * frac - layout.size.width / 2f).coerceIn(0f, maxLx)
            drawText(layout, topLeft = Offset(lx, plotH + 3.dp.toPx()))
        }

        // linhas (e preenchimento)
        data.forEach { s ->
            val path = Path()
            s.points.forEachIndexed { i, p ->
                if (i == 0) path.moveTo(x(p.epochMillis), y(p.value)) else path.lineTo(x(p.epochMillis), y(p.value))
            }
            if (s.fill) {
                val fillPath = Path().apply {
                    addPath(path)
                    lineTo(x(s.points.last().epochMillis), plotH)
                    lineTo(x(s.points.first().epochMillis), plotH)
                    close()
                }
                drawPath(
                    fillPath,
                    Brush.verticalGradient(listOf(s.color.copy(alpha = 0.35f), Color.Transparent), 0f, plotH),
                )
            }
            drawPath(
                path, s.color,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }

        // seleção pelo toque
        touchX?.let { tx ->
            val cx = tx.coerceIn(0f, plotW.coerceAtLeast(0f))
            val t = if (plotW <= 0f || maxT == minT) minT
            else minT + ((cx / plotW) * (maxT - minT)).toLong()
            drawLine(
                Color.White, Offset(cx, 0f), Offset(cx, plotH), strokeWidth = 1.5f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)),
            )
            val lines = ArrayList<String>()
            lines += timeFormat(t)
            data.forEach { s ->
                SeriesMath.lastAtOrBefore(s.points, t)?.let { p ->
                    drawCircle(Color.White, 5.dp.toPx(), Offset(x(p.epochMillis), y(p.value)))
                    drawCircle(s.color, 3.dp.toPx(), Offset(x(p.epochMillis), y(p.value)))
                    lines += if (data.size == 1) valueFormat(p.value) else "${s.name}: ${valueFormat(p.value)}"
                }
            }
            val layout = measurer.measure(lines.joinToString("\n"), tipStyle)
            val padPx = 6.dp.toPx()
            val boxW = layout.size.width + padPx * 2
            val boxH = layout.size.height + padPx * 2
            val bx = (cx - boxW / 2).coerceIn(0f, (plotW - boxW).coerceAtLeast(0f))
            drawRoundRect(
                AppColors.CardAlt, Offset(bx, 0f), Size(boxW, boxH), CornerRadius(8.dp.toPx()),
            )
            drawText(layout, topLeft = Offset(bx + padPx, padPx))
        }
    }
}
