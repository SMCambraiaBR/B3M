# B3M — B3 Monitor

App Android open source (Kotlin + Jetpack Compose) para acompanhar sua carteira de ações/FIIs e o mercado da B3.

> **Status: v0.6.0** — dados sempre com data e hora da coleta, impostos configuráveis em todos os valores líquidos, proventos por mês, favoritos e backup em CSV. A lógica tem testes automáticos; as telas e as fontes de dados ainda precisam de validação em aparelho real.

## Novidades da v0.6

**Dados claros e honestos**
- Cada bloco mostra **quando o dado foi coletado** ("Atualizado hoje às 14:32:10"). Se a coleta nova falha, aparece em destaque **"Sem atualização agora. Último dado coletado em 29/10/2026 às 18:05:44."** com o último dado que se tinha, em vez de uma tela vazia ou de valores zerados.
- **Ao aparecer na tela, o app busca de novo**: os caches de cotação e de gráfico são descartados e o Fundamentus é consultado outra vez (o ranking de dividendos, que exige dezenas de consultas, é reaproveitado por até 15 min; o botão de atualizar força tudo). Ao sair da tela, as consultas param.
- O último dado de cada coisa fica guardado em disco (30 dias), então o app abre com algo útil mesmo sem internet.
- Uma fonte que responde rápido mas com lista vazia ou preço zero não vence mais a corrida das fontes de cotação.

**Impostos**
- Alíquotas configuráveis na aba **Ajustes** (dividendos, JCP, rendimentos de FIIs; padrão: 0%, 15%, 0%).
- Todo valor líquido do app usa essas alíquotas: Retorno e % Retorno, ranking de dividendos, proventos recebidos, resultado total, renda mensal e desempenho da carteira.
- Nas telas de detalhe, cada provento mostra **bruto, líquido e a alíquota já descontada**; os resumos trazem o aviso "Valores líquidos: imposto já descontado (JCP 15% · dividendos 0% · rendimentos de FIIs 0%)".

**Carteira**
- Resultado das cotações **e** resultado total (com proventos líquidos); imposto retido; peso de cada ativo; ordenação (valor, resultado, dia, A–Z).
- **Proventos por mês** (gráfico de barras, últimos 12 meses) e **renda mensal estimada** (média dos últimos 6 meses).
- O desempenho (TWR) passa a incluir os proventos recebidos.
- Validação ao digitar: código no formato da B3 (PETR4, B3SA3, BOVA11), venda nunca maior que a posição, exclusão que deixaria uma venda sem ações é recusada, confirmação antes de excluir.
- Cotação ausente ou antiga aparece marcada no ativo, em vez de usar o preço médio sem avisar.

**Ativo, Mercado e Ajustes**
- Botão **Adicionar à carteira** direto na tela do ativo; nome da empresa; indicadores com nome por extenso e explicação (toque para ver).
- **Favoritos** (estrela) com seção própria em Mercado; seletor de período também no gráfico do IBOV; setas ▲▼ junto das cores.
- Aba **Ajustes**: impostos, token da brapi e chave da HG Brasil (ficam só no aparelho), exportar/importar lançamentos em CSV, apagar dados guardados.
- Rolar a tela por cima de um gráfico não aciona mais o valor do gráfico; só arrastar na horizontal.

**Por baixo**
- Cálculo do desempenho em tempo linear; sem "posição fantasma" por resíduo de ponto flutuante; "1.000" é lido como mil.
- Banco migrado para a versão 2 (sem apagar a carteira); backup automático do Android da carteira e das alíquotas (as chaves ficam de fora); release com R8.
- O token da brapi **não é mais gravado no APK** pelo CI (um APK de Actions pode ser baixado por outras pessoas): digite em Ajustes.

## O que o app faz

**Mercado** (aba inicial)
- Busca de ativos com sugestões a cada letra.
- Ibovespa: pontos, % do dia e gráfico com seletor de período.
- Favoritos.
- Destaques: maiores altas, maiores quedas e mais negociadas (9 de cada, entre os ativos mais negociados do dia).
- Melhores dividendos (9), ordenáveis por **Retorno** ou **% Retorno**, líquidos de imposto.

**Ativo**
- Cotação atualizada a cada 10 s e gráfico (toque e arraste na horizontal para ver o valor em cada instante).
- Períodos: 1D, 1S, 1M, 3M, 6M, 1A, 2A, 3A e Tudo.
- Resumo (fechamento anterior, abertura, máxima, mínima, volume, variação do dia, Retorno e % Retorno).
- 8 indicadores (D.Y, P/L, ROE, ROIC, VPA, LPA, P/VP, M. EBIT) do Fundamentus.
- "Dados completos": todas as seções do Fundamentus e a lista de proventos (bruto, líquido, alíquota).
- Aba **Posição** quando você tem o ativo: valor atual, investido, quantidade, preço médio, resultado das cotações, proventos líquidos recebidos, imposto retido, resultado total e gasto real.

**Carteira**
- Patrimônio com variação do dia, valor investido, resultado, proventos, resultado total, gasto real e imposto retido.
- Desempenho (rentabilidade ponderada pelo tempo — TWR, sem distorção por aportes) com IBOV, CDI e IPCA sobrepostos.
- Meus ativos, proventos por mês, evolução patrimonial (patrimônio x investido) e lançamentos.

Todo gráfico tem seletor de período. Verde = positivo, vermelho = negativo em todo o app.

## Carteira sem API da B3

O Investidor B3 não tem API pública para pessoa física, então a carteira é **cadastrada à mão** (dados só no aparelho, em SQLite/Room) ou importada de um CSV (`ticker;tipo;quantidade;preco;data`, ex.: `PETR4;COMPRA;100;35.5;2026-01-10`).

- Preço médio ponderado nas compras; venda reduz a quantidade e mantém o preço médio.
- Proventos recebidos = quantidade que você tinha na **data com** × valor líquido por ação, só dos já pagos.
- **Regra do app:** proventos de posições vendidas por inteiro não entram nos totais. Gasto real = valor investido − proventos recebidos (das posições abertas).

## Impostos

Configure em **Ajustes**. Padrão: JCP 15%, dividendos 0%, rendimentos de FIIs 0%.

Desde 2026 (Lei 15.270/2025), quem recebe mais de R$ 50 mil por mês de uma mesma empresa tem 10% de dividendos retidos. O app **não** separa por esse limite: aplica a alíquota informada a todo dividendo. Informe 10% só se esse for o seu caso. Isto não é orientação tributária.

## Métricas próprias

- **Retorno** = (dividendos + JCP pagos nos últimos 6 meses, líquidos de imposto) ÷ 6, por ação e por mês
- **% Retorno** = Retorno ÷ cotação atual
- **Renda mensal estimada** (carteira) = proventos líquidos recebidos nos últimos 6 meses ÷ 6

`domain/ReturnCalculator.kt` e `domain/DividendCalculator.kt`.

## Cotações: a fonte mais rápida vence (+ cache)

`RacingQuoteSource` consulta as fontes em paralelo e usa a primeira resposta **válida** (preço maior que zero, lista não vazia). Depois de 3 respostas, só a mais rápida (medida no aparelho) é consultada, com limite de 3 s; se falhar, volta a competir. Por cima roda um cache em memória com validade curta (5 s para cotação; 45 s/5 min para gráficos), descartado ao abrir cada tela, e por baixo o último dado guardado em disco (`QuoteRepository`/`Snapshots`).

| Fonte | Cotação | Gráfico | Chave |
|---|---|---|---|
| Yahoo Finance (query1) | sim | sim | não |
| Yahoo Finance (query2, espelho) | sim | sim | não |
| brapi.dev | sim | sim | opcional* |
| B3 (endpoint do site) | sim | não | não |
| HG Brasil | sim | não | sim (opcional) |

\*Sem token a brapi só atende alguns tickers de teste.

Para adicionar outra fonte: implemente `QuoteSource` e inclua em `AppGraph.kt`.

## Outras fontes

- **Fundamentus**: indicadores, dados completos, proventos e ranking de dividendos (HTML, sem API; validade de 2/5/15 min na memória).
- **Banco Central (SGS)**: CDI (série 12) e IPCA (série 433) para os comparativos.
- **brapi.dev**: busca e destaques do dia (com token, em Ajustes); sem ele, busca e destaques usam o Fundamentus mais as cotações.
- **Logos**: `icons.brapi.dev`; sem logo, aparecem as iniciais.

## Como compilar

### Pelo GitHub (sem Android Studio)

1. Crie um repositório no GitHub e envie **todo o conteúdo desta pasta** (incluindo `gradlew`, `gradle/` e `.github/`).
2. Vá em **Actions** → workflow **Build APK** → **Run workflow** (ou faça um push na branch `main`).
3. Quando terminar, baixe o artefato **B3M-debug** (APK pronto para instalar) e, se quiser, o relatório de testes.
4. No app, abra **Ajustes** e informe o token da brapi (opcional).

### Local (opcional)

1. Copie `local.properties.example` → `local.properties` (e o caminho do SDK se necessário). Os tokens também podem ser informados direto em Ajustes.
2. `./gradlew assembleDebug` — APK em `app/build/outputs/apk/debug/`.
3. Testes: `./gradlew testDebugUnitTest`.

Requer JDK 17+ e Android SDK (API 35). O Gradle Wrapper já está incluído.

## Testes

Cobrem a lógica (preço médio, retorno, proventos, imposto, desempenho, validação e CSV), as fontes (corrida, cache, snapshots) e os ViewModels das telas com dados de mentira: hora da coleta, aviso de dado antigo, imposto, falha de proventos que não vira "sem proventos". Não há testes de interface (Compose) nem das fontes contra os sites reais.

## Roadmap

- Validação real dos parsers (Fundamentus, B3, Yahoo, brapi, HG) e das telas em aparelho.
- Importação do extrato da B3 (CSV/XLSX do Investidor B3).
- Alertas de preço / variação.
- Widget de patrimônio.
- Testes de integração das fontes.

## Limitações conhecidas

- Fundamentus e endpoints não oficiais podem mudar ou limitar acessos.
- Fontes gratuitas não informam negócios e quantidade do dia (o app não mostra mais esses campos).
- "Maiores altas/quedas" são entre os ~120 (brapi) ou ~40 (Fundamentus) ativos mais negociados.
- O desempenho inclui os proventos só dos ativos que você tem hoje.
- Sem login/sincronização automática com o Investidor B3.
- O release minificado (R8) ainda não foi testado em aparelho.

## Estrutura

```
app/src/main/java/org/b3m/
  AppGraph.kt          dependências e lista de fontes
  domain/              Retorno, preço médio, proventos, impostos, desempenho, validação, CSV (com testes)
  data/quotes/         fontes de cotação, corrida, cache e QuoteRepository (com data/hora da coleta)
  data/snapshot/       último dado coletado de cada coisa, em disco
  data/market/         busca/destaques, ranking de dividendos, Banco Central
  data/fundamentus/    cliente do Fundamentus
  data/settings/       Ajustes (alíquotas, chaves)
  data/db/             Room: lançamentos, snapshots, favoritos (migração 1→2)
  ui/                  telas Mercado, Ativo, Carteira, Ajustes, componentes e tema
```

Licença: MIT.
