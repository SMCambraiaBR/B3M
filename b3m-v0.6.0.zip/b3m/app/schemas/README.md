Esquemas do banco (Room) gerados no build. Versione estes arquivos: servem para conferir
que cada migração (ver `MIGRATION_1_2` em `data/db/Database.kt`) leva de um esquema ao outro.
