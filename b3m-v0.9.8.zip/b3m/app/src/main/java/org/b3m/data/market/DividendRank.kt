package org.b3m.data.market

import java.time.LocalDate
import kotlinx.serialization.Serializable
import org.b3m.domain.Provento
import org.b3m.domain.RetornoResult
import org.b3m.domain.ReturnCalculator
import org.b3m.domain.TaxRates

/**
 * Candidato do ranking: guarda os PROVENTOS (brutos) e não o resultado pronto, então o
 * Retorno é calculado na hora com as alíquotas de imposto atuais (Ajustes).
 */
@Serializable
data class DividendRank(
    val ticker: String,
    val price: Double,
    val dividendYield: Double, // % dos últimos 12 meses, como o Fundamentus informa
    val proventos: List<Provento>,
) {
    fun result(taxes: TaxRates, today: LocalDate = LocalDate.now()): RetornoResult =
        ReturnCalculator.calculate(proventos, price, today, taxes)
}

/** De onde vem a lista de candidatos do ranking (o Fundamentus no app; um dado de mentira nos testes). */
fun interface RankingSource {
    suspend fun load(): List<DividendRank>
}

enum class DividendSort { RETORNO, PERCENT }

/** Ordena pelo Retorno (R$/ação/mês) ou % Retorno, líquidos de imposto; só entra quem teve provento. */
fun List<DividendRank>.rankedBy(
    sort: DividendSort,
    taxes: TaxRates,
    today: LocalDate = LocalDate.now(),
    limit: Int = 30,
): List<DividendRank> {
    // Usa proventos reais (dividendo + JCP + rendimento). Se a lista vier vazia,
    // estima pelo DY do Fundamentus para o ranking não ficar em branco.
    data class Score(val rank: DividendRank, val retorno: Double, val pct: Double)
    val scored = map { row ->
        val res = row.result(taxes, today)
        if (res.retorno > 0) {
            Score(row, res.retorno, res.percentRetorno)
        } else if (row.dividendYield > 0 && row.price > 0) {
            val monthly = row.price * (row.dividendYield / 100.0) / 12.0
            Score(row, monthly, row.dividendYield / 12.0)
        } else null
    }.filterNotNull()
    return when (sort) {
        DividendSort.RETORNO -> scored.sortedByDescending { it.retorno }
        DividendSort.PERCENT -> scored.sortedByDescending { it.pct }
    }.take(limit).map { it.rank }
}
