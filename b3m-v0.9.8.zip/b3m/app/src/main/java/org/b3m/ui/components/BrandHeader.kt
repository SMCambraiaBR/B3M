package org.b3m.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.b3m.R

/** Logo + título no topo das abas principais. */
@Composable
fun BrandHeader(title: String, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(R.drawable.ic_launcher_legacy),
            contentDescription = "B3M",
            modifier = Modifier.size(36.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}
