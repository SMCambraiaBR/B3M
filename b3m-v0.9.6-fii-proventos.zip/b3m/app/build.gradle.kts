import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.devtools.ksp")
}

// Chaves opcionais ficam em local.properties (que NÃO vai para o Git):
//   BRAPI_TOKEN=seu_token     (brapi.dev, gratuito)
//   HGBRASIL_KEY=sua_chave    (hgbrasil.com, gratuito)
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

fun prop(name: String): String = localProps.getProperty(name, "").trim()

android {
    namespace = "org.b3m"
    compileSdk = 35
    base.archivesName.set("B3M")
    // Nome do artefato: B3M-0.9.0-release.apk etc.

    defaultConfig {
        applicationId = "org.b3m"
        minSdk = 26
        targetSdk = 35
        versionCode = 22
        versionName = "0.9.6"

        buildConfigField("String", "BRAPI_TOKEN", "\"${prop("BRAPI_TOKEN")}\"")
        buildConfigField("String", "HGBRASIL_KEY", "\"${prop("HGBRASIL_KEY")}\"")
    }

    // Keystore de sideload (mesmo arquivo no CI e local). Senha só para instalação manual.
    signingConfigs {
        create("release") {
            val ks = rootProject.file("app/b3m-upload.jks")
            if (ks.exists()) {
                storeFile = ks
                storePassword = "b3mopen"
                keyAlias = "b3m"
                keyPassword = "b3mopen"
            }
        }
    }

    buildTypes {
        release {
            // Minify desligado por enquanto: o R8 ainda não foi validado em aparelho.
            isMinifyEnabled = false
            isDebuggable = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            isDebuggable = true
            // Debug também assinado com a mesma chave para atualizar sem desinstalar.
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

// Room: exporta o esquema do banco (app/schemas) para versionar e testar as migrações.
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    // Rede e parsing
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jsoup:jsoup:1.18.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Banco local
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Logos das empresas (SVG incluso)
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-svg:2.7.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
}

