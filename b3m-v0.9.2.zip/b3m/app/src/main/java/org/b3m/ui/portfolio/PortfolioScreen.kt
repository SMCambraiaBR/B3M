package org.b3m.ui.portfolio

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import org.b3m.domain.IncomeEvent
import org.b3m.domain.Lancamento
import org.b3m.domain.LancamentoTipo
import org.b3m.domain.label
import org.b3m.ui.Factories
import org.b3m.ui.arrowPct
import org.b3m.ui.brl
import org.b3m.ui.components.AppCard
import org.b3m.ui.components.BarChart
import org.b3m.ui.components.BarItem
import org.b3m.ui.components.ChartSeries
import org.b3m.ui.components.ChipRow
import org.b3m.ui.components.CompanyLogo
import org.b3m.ui.components.ErrorLine
import org.b3m.ui.components.ChartDetailDialog
import org.b3m.ui.components.LineChart
import org.b3m.ui.components.RangeSelector
import org.b3m.ui.components.SectionTitle
import org.b3m.ui.components.TaxNote
import org.b3m.ui.components.UpdatedLine
import org.b3m.ui.components.WarningLine
import org.b3m.ui.formatCollected
import org.b3m.ui.pct
import org.b3m.ui.qty
import org.b3m.ui.signedBrl
import org.b3m.ui.signedPct
import org.b3m.ui.theme.AppColors
import org.b3m.ui.timeFormatter

private val ptBR = Locale("pt", "BR")

private fun Benchmark.color(): Color = when (this) {
    Benchmark.IBOV -> Color(0xFFBDBDBD)
    Benchmark.CDI -> Color(0xFF4C8DFF)
    Benchmark.IPCA -> Color(0xFFB07A5A)
}

@Composable
fun PortfolioScreen(
    onOpen: (String) -> Unit,
    vm: PortfolioViewModel = viewModel(factory = Factories.portfolio),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Lancamento?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    // Só consulta a internet enquanto a tela está à vista; ao voltar, busca tudo de novo.
    LifecycleStartEffect(vm) {
        vm.start()
        onStopOrDispose { vm.stop() }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(AppColors.Background).statusBarsPadding(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Carteira", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    val ts = ui.quotesAt
                    if (ts != null) {
                        Text(
                            "Atualizado ${formatCollected(ts)}",
                            color = if (ui.quotesStale) AppColors.Warning else AppColors.Neutral,
                            fontSize = 12.sp,
                        )
                    }
                }
                IconButton(onClick = vm::refresh) { Icon(Icons.Default.Refresh, contentDescription = "Atualizar") }
            }
        }

        if (!ui.loaded) {
            item { CircularProgressIndicator(Modifier.height(28.dp)) }
            return@LazyColumn
        }

        if (ui.positions.isEmpty()) {
            item {
                Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Adicionar ativo")
                }
            }
            item {
                Text(
                    "Nenhum ativo ainda. Toque em \"Adicionar ativo\" e informe código, quantidade, preço e data da compra. " +
                        "Em Ajustes você também pode importar uma carteira de um arquivo CSV.",
                    color = AppColors.Neutral,
                )
            }
        } else {
            // Gráfico de desempenho no topo
            item { PerformanceBlock(ui, vm) }

            if (ui.positions.isNotEmpty()) item { SummaryCard(ui) }

            item {
                Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Adicionar ativo")
                }
            }

            item { SectionTitle("Meus ativos") }
            item { ChipRow(PositionSort.entries, ui.sort, { it.label }, vm::selectSort) }
            items(ui.positions, key = { it.position.ticker }) { p ->
                PositionCard(p) { onOpen(p.position.ticker) }
            }

            item { IncomeBlock(ui) }

            item { EvolutionBlock(ui.evolution, vm) }
        }

        if (ui.lancamentos.isNotEmpty()) {
            item { SectionTitle("Lançamentos") }
            items(ui.lancamentos, key = { "l-" + it.id }) { l ->
                AppCard {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            val tipo = if (l.tipo == LancamentoTipo.COMPRA) "Compra" else "Venda"
                            Text("$tipo ${l.ticker}", fontWeight = FontWeight.Bold)
                            Text(
                                "${l.quantidade.qty()} × ${l.preco.brl()} · " +
                                    l.data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                                color = AppColors.Neutral, fontSize = 13.sp,
                            )
                        }
                        TextButton(onClick = { toDelete = l }) { Text("Excluir", color = AppColors.Negative) }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showAdd) {
        AddLancamentoDialog(
            existing = ui.lancamentos,
            onDismiss = { showAdd = false },
            onSubmit = { l, done -> vm.add(l, done) },
        )
    }

    toDelete?.let { l ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Excluir lançamento?") },
            text = {
                val tipo = if (l.tipo == LancamentoTipo.COMPRA) "compra" else "venda"
                Text("Excluir a $tipo de ${l.quantidade.qty()} ${l.ticker} em ${l.data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}? " +
                    "O preço médio e os totais serão recalculados.")
            },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    vm.remove(l.id) { error -> if (error != null) info = error }
                }) { Text("Excluir", color = AppColors.Negative) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }

    info?.let { msg ->
        AlertDialog(
            onDismissRequest = { info = null },
            title = { Text("Não foi possível") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { info = null }) { Text("OK") } },
        )
    }
}

@Composable
private fun SummaryCard(ui: PortfolioUi) {
    val provReady = !ui.income.loading || ui.income.events.isNotEmpty()
    AppCard {
        Text("Patrimônio", color = AppColors.Neutral, fontSize = 13.sp)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(ui.patrimonio.brl(), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Column(horizontalAlignment = Alignment.End) {
                Text(ui.dayChangePct.arrowPct(), color = AppColors.forChange(ui.dayChange), fontWeight = FontWeight.Medium)
                Text(ui.dayChange.signedBrl(), color = AppColors.forChange(ui.dayChange), fontSize = 13.sp)
            }
        }
        if (ui.missingQuotes.isNotEmpty()) {
            WarningLine("Sem cotação: ${ui.missingQuotes.joinToString()} → usa PM")
        }
        Spacer(Modifier.height(12.dp))
        // Grade estilo indicadores
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricTile("Investido (pago)", ui.investido.brl(), Color.White, Modifier.weight(1f))
            MetricTile(
                "Δ cotações",
                "${ui.resultado.signedBrl()} (${ui.resultadoPct.signedPct()})",
                AppColors.forChange(ui.resultado),
                Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricTile(
                "Proventos líq.",
                if (provReady) ui.dividends.brl() else "…",
                if (ui.dividends > 0) AppColors.Positive else Color.White,
                Modifier.weight(1f),
            )
            MetricTile(
                "Resultado total",
                if (provReady) "${ui.resultadoTotal.signedBrl()} (${ui.resultadoTotalPct.signedPct()})" else "…",
                if (provReady) AppColors.forChange(ui.resultadoTotal) else Color.White,
                Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricTile(
                "Patrim. + prov.",
                if (provReady) (ui.patrimonio + ui.dividends).brl() else "…",
                Color.White,
                Modifier.weight(1f),
            )
            MetricTile(
                "Gasto real",
                if (provReady) ui.gastoReal.brl() else "…",
                Color.White,
                Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(8.dp))
        Text("Investido = valor (qtd × PM) · Gasto real = investido − proventos.", color = AppColors.Neutral, fontSize = 11.sp)
        TaxNote(ui.taxes)
        if (ui.income.failedTickers.isNotEmpty()) {
            WarningLine("Prov. indisponível: ${ui.income.failedTickers.joinToString()}")
        }
    }
}

@Composable
private fun MetricTile(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Column(
        modifier
            .background(AppColors.CardAlt, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Text(label, color = AppColors.Neutral, fontSize = 11.sp)
        Text(value, color = valueColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun SummaryRow(
    leftLabel: String, left: String, leftColor: Color,
    rightLabel: String, right: String, rightColor: Color,
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            Text(leftLabel, color = AppColors.Neutral, fontSize = 13.sp)
            Text(left, color = leftColor, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text(rightLabel, color = AppColors.Neutral, fontSize = 13.sp)
            Text(right, color = rightColor, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PositionCard(p: PositionUi, onClick: () -> Unit) {
    val q = p.quote
    AppCard(onClick = onClick) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            CompanyLogo(p.position.ticker)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.position.ticker, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        "  ${p.price.brl()}",
                        color = AppColors.Neutral,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
                Text(
                    "${p.position.quantity.qty()} un. · PM ${p.position.averagePrice.brl()}",
                    color = AppColors.Neutral, fontSize = 13.sp,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(p.value.brl(), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("${p.weight.pct()} da carteira", color = AppColors.Neutral, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Cotações ${p.result.signedBrl()}", color = AppColors.forChange(p.result), fontSize = 12.sp)
            Text(
                "Proventos ${p.dividendsNet.signedBrl()}",
                color = if (p.dividendsNet > 0) AppColors.Positive else AppColors.Neutral,
                fontSize = 12.sp,
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "Total ${p.totalResult.signedBrl()} (${p.totalResultPct.signedPct()})",
                color = AppColors.forChange(p.totalResult), fontSize = 13.sp, fontWeight = FontWeight.Medium,
            )
            when {
                q == null -> Text("Sem cotação · PM", color = AppColors.Warning, fontSize = 12.sp)
                p.stale -> Text("Cotação de ${formatCollected(q.fetchedAt)}", color = AppColors.Warning, fontSize = 12.sp)
                else -> Text(
                    "${q.price.brl()} · ${q.changePct.arrowPct()}",
                    color = AppColors.forChange(q.changePct), fontSize = 12.sp,
                )
            }
        }
    }
}

@Composable
private fun IncomeBlock(ui: PortfolioUi) {
    val income = ui.income
    val ordered = remember(income.events) {
        income.events.sortedByDescending { it.date }
    }
    var showAll by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("Proventos recebidos")
        AppCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("Renda mensal estimada", color = AppColors.Neutral, fontSize = 13.sp)
                    Text(
                        income.average6.brl(),
                        fontWeight = FontWeight.Bold, fontSize = 20.sp,
                        color = if (income.average6 > 0) AppColors.Positive else Color.White,
                    )
                    Text("média dos últimos 12 meses", color = AppColors.Neutral, fontSize = 11.sp)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("Últimos 12 meses", color = AppColors.Neutral, fontSize = 13.sp)
                    Text(income.last12.brl(), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("proventos líquidos", color = AppColors.Neutral, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            if (income.loading && income.events.isEmpty()) {
                CircularProgressIndicator(Modifier.height(28.dp))
            } else {
                BarChart(
                    items = income.monthly.map { m ->
                        BarItem(m.month.month.getDisplayName(TextStyle.SHORT, ptBR).replace(".", ""), m.value)
                    },
                    valueFormat = { it.brl() },
                    average = income.average6,
                    averageLabel = "média 12m",
                    emptyText = "Sem proventos recebidos nos últimos 12 meses",
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(10.dp))
            Text("Lista (mais recentes)", fontWeight = FontWeight.Medium, fontSize = 14.sp)
            if (ordered.isEmpty() && !income.loading) {
                Text("Nenhum provento recebido nas posições abertas.", color = AppColors.Neutral, fontSize = 12.sp)
            } else {
                ordered.take(9).forEach { e ->
                    IncomeEventRow(e)
                }
                if (ordered.size > 9) {
                    TextButton(
                        onClick = { showAll = true },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("Mostrar mais (${ordered.size - 9})")
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            TaxNote(ui.taxes)
            Text("Só proventos de posições abertas (data-com).", color = AppColors.Neutral, fontSize = 11.sp)
            UpdatedLine(income.updatedAt, income.stale)
        }
    }
    if (showAll) {
        AlertDialog(
            onDismissRequest = { showAll = false },
            title = { Text("Todos os proventos (${ordered.size})") },
            text = {
                LazyColumn(Modifier = Modifier.heightIn(max = 420.dp)) {
                    items(ordered.size) { i ->
                        IncomeEventRow(ordered[i])
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAll = false }) { Text("Fechar") }
            },
        )
    }
}

@Composable
private fun IncomeEventRow(e: IncomeEvent) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            Text("${e.ticker} · ${e.tipo.label()}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text(
                e.date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")),
                color = AppColors.Neutral,
                fontSize = 11.sp,
            )
        }
        Text(
            e.net.brl(),
            color = if (e.net > 0) AppColors.Positive else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun PerformanceBlock(ui: PortfolioUi, vm: PortfolioViewModel) {
    val state = ui.performance
    val total = state.twr.lastOrNull()?.value
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            SectionTitle("Desempenho")
            if (total != null) {
                Text(total.signedPct(), color = AppColors.forChange(total), fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        // Comparativos sobrepostos: cada um liga/desliga.
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Benchmark.entries.forEach { b ->
                val on = b in state.enabled
                val last = state.benchmarks[b]?.lastOrNull()?.value
                Column(
                    Modifier
                        .background(if (on) AppColors.CardAlt else AppColors.Card, RoundedCornerShape(10.dp))
                        .clickable { vm.toggleBenchmark(b) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Text("● ${b.label}", color = if (on) b.color() else AppColors.Neutral, fontSize = 13.sp)
                    Text(
                        last?.signedPct() ?: "—",
                        color = if (last == null) AppColors.Neutral else AppColors.forChange(last),
                        fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (state.loading && state.twr.isEmpty()) CircularProgressIndicator(Modifier.height(28.dp))
        state.error?.let { ErrorLine(it) }
        val series = buildList {
            add(ChartSeries("Carteira", state.twr, if (total != null) AppColors.forChange(total) else AppColors.Neutral, fill = true))
            Benchmark.entries.filter { it in state.enabled }.forEach { b ->
                state.benchmarks[b]?.let { add(ChartSeries(b.label, it, b.color())) }
            }
        }
        var expanded by remember { mutableStateOf(false) }
        Column(Modifier.clickable(enabled = state.twr.size >= 2) { expanded = true }) {
            LineChart(
                series = series,
                valueFormat = { it.signedPct() },
                timeFormat = timeFormatter(state.range),
                zeroLine = true,
            )
            if (state.twr.size >= 2) Text("Toque para ampliar", color = AppColors.Neutral, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        RangeSelector(state.range, vm::selectPerformanceRange)
        if (expanded) {
            ChartDetailDialog(
                title = "Desempenho",
                series = series,
                range = state.range,
                onRange = vm::selectPerformanceRange,
                valueFormat = { it.signedPct() },
                timeFormat = timeFormatter(state.range),
                onDismiss = { expanded = false },
                zeroLine = true,
                footnote = "TWR · benchmarks sobpostos",
            )
        }
        Text(
            "Rentabilidade da carteira (sem distorção por aportes e retiradas), somando os proventos líquidos recebidos.",
            color = AppColors.Neutral, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
        )
        state.note?.let { Text(it, color = AppColors.Neutral, fontSize = 12.sp) }
        UpdatedLine(state.updatedAt, state.stale)
    }
}

@Composable
private fun EvolutionBlock(state: EvolutionState, vm: PortfolioViewModel) {
    Column {
        SectionTitle("Evolução patrimonial")
        Spacer(Modifier.height(8.dp))
        if (state.loading && state.patrimonio.isEmpty()) CircularProgressIndicator(Modifier.height(28.dp))
        state.error?.let { ErrorLine(it) }
        val last = state.patrimonio.lastOrNull()?.value
        val inv = state.investido.lastOrNull()?.value
        val patColor = if (last != null && inv != null) AppColors.forChange(last - inv) else AppColors.Neutral
        LineChart(
            series = listOf(
                ChartSeries("Patrimônio", state.patrimonio, patColor, fill = true),
                ChartSeries("Investido", state.investido, Color(0xFF9E9E9E)),
            ),
            valueFormat = { it.brl() },
            timeFormat = timeFormatter(state.range),
        )
        Spacer(Modifier.height(8.dp))
        RangeSelector(state.range, vm::selectEvolutionRange)
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppCard(Modifier.weight(1f)) {
                Text("Patrimônio inicial", color = AppColors.Neutral, fontSize = 13.sp)
                Text(state.patrimonio.firstOrNull()?.value?.brl() ?: "—", fontWeight = FontWeight.Bold)
            }
            AppCard(Modifier.weight(1f)) {
                Text("Patrimônio final", color = AppColors.Neutral, fontSize = 13.sp)
                Text(last?.brl() ?: "—", fontWeight = FontWeight.Bold)
            }
        }
        UpdatedLine(state.updatedAt, state.stale)
    }
}
