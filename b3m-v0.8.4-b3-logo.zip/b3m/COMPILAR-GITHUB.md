# Compilar o B3M só pelo GitHub (sem Android Studio)

## Passo a passo

### 1. Criar o repositório
1. Acesse [github.com/new](https://github.com/new).
2. Nome sugerido: `b3m`.
3. **Não** marque "Add a README".

### 2. Enviar o código
Pela interface web: **Add file → Upload files** e arraste **toda** a pasta (incluindo `gradlew`, `gradle/`, `.github/` e `app/b3m-upload.jks`).

Ou no computador:

```bash
git init
git add .
git commit -m "B3M v0.8.4"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/b3m.git
git push -u origin main
```

### 3. Gerar o APK
1. Aba **Actions** → **Build APK** → **Run workflow**.
2. Aguarde ~5–10 minutos.
3. Em **Artifacts**, baixe **B3M-release** (preferível) ou **B3M-debug**.
4. Extraia o ZIP e instale o `.apk`.

### Instalação no Android 11 (Motorola e similares)

1. **Desinstale** qualquer versão antiga do B3M (assinatura mudou em builds anteriores).
2. Baixe o **B3M-release** (não o ZIP inteiro — o arquivo `.apk` de dentro).
3. Abra com o app **Arquivos** do Google (não só o Chrome).
4. Em Configurações → Apps → Arquivos → **Instalar apps desconhecidos** → permitir.
5. Se o Play Protect avisar “app prejudicial / bloqueado”:
   - Toque em **Mais detalhes** → **Instalar mesmo assim** (é sideload open-source, não vem da Play Store).
6. O SAI continua funcionando se o instalador do sistema recusar.

### Token brapi (opcional)
Depois de instalar: aba **Ajustes** → token gratuito de [brapi.dev](https://brapi.dev).

## Estrutura importante
- `gradlew` + `gradle/wrapper/`
- `.github/workflows/build.yml`
- `app/b3m-upload.jks` — assinatura estável (não apague)
- `local.properties` **não** vai para o Git
