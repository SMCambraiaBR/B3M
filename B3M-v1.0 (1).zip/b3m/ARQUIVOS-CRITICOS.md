# Arquivos críticos do B3M

Este arquivo é um mapa rápido para manutenção. Os comentários `CRÍTICO` no código apontam as mesmas áreas.

| Arquivo | Função | Cuidado |
|---|---|---|
| `.github/workflows/build.yml` | Roteiro do GitHub Actions: extrai o projeto, configura o Android, executa testes, compila, alinha, assina e publica os APKs. | Não alterar caminhos de `gradlew`, `app`, `dist` ou a etapa de assinatura sem testar o workflow completo. |
| `app/build.gradle.kts` | Define `applicationId`, SDKs, versão, variantes e assinatura Gradle. | `applicationId`, `versionCode`, keystore e `signingConfig` afetam instalação e atualização. |
| `app/b3m-upload.jks` | Chave que identifica o APK para o Android. | Não remover, substituir ou publicar em repositório público. Perder/trocar a chave pode impedir atualização por cima da versão instalada. |
| `gradlew`, `gradle/wrapper/` | Versão do Gradle usada pelo projeto e pelo GitHub. | Não apagar o wrapper; o workflow depende dele. |
| `app/src/main/java/org/b3m/AppGraph.kt` | Monta banco, fontes de cotação, cache e repositórios usados pelo app. | Alterar a ordem das fontes pode mudar a qualidade/velocidade das cotações. |
| `app/src/main/java/org/b3m/data/db/Database.kt` | Define as tabelas da carteira e as migrações Room. | Toda mudança de banco precisa de uma nova migração; não apagar dados para corrigir schema. |
| `app/src/main/java/org/b3m/MainActivity.kt` | Controla abas, navegação e retorno do detalhe do ativo. | O estado de rolagem fica aqui para restaurar a posição anterior. |

## Carteira inicial

Não existe seed, ativo de demonstração ou lançamento automático no código deste projeto. A carteira é preenchida somente pelos lançamentos gravados pelo usuário ou importados por CSV. Se um ativo continuar aparecendo após uma reinstalação, ele está no banco de dados persistido do Android ou foi restaurado pelo sistema; isso não deve ser apagado automaticamente, pois pode ser um ativo real do usuário. Para remover, use a exclusão do lançamento dentro do app ou desinstale limpando os dados após fazer backup CSV.
