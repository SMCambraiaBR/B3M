package org.b3m

import android.content.Context
import androidx.room.Room
import coil.ImageLoader
import coil.decode.SvgDecoder
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import org.b3m.data.db.AppDatabase
import org.b3m.data.db.LancamentoRepository
import org.b3m.data.db.MIGRATION_1_2
import org.b3m.data.db.RoomSnapshotStore
import org.b3m.data.db.WatchlistRepository
import org.b3m.data.fundamentus.FundamentusClient
import org.b3m.data.market.BcbClient
import org.b3m.data.market.BrapiMarketSource
import org.b3m.data.market.DividendRanking
import org.b3m.data.market.FallbackMarketSource
import org.b3m.data.market.FundamentusMarketSource
import org.b3m.data.quotes.B3QuoteSource
import org.b3m.data.quotes.BrapiQuoteSource
import org.b3m.data.quotes.CachedQuoteSource
import org.b3m.data.quotes.HgBrasilQuoteSource
import org.b3m.data.quotes.MarketListSource
import org.b3m.data.quotes.NamedSource
import org.b3m.data.quotes.QuoteRepository
import org.b3m.data.quotes.QuoteSource
import org.b3m.data.quotes.RacingQuoteSource
import org.b3m.data.quotes.YahooQuoteSource
import org.b3m.data.settings.AppSettings
import org.b3m.data.snapshot.Codecs
import org.b3m.data.snapshot.DataCodecs
import org.b3m.data.snapshot.Snapshots
import org.b3m.domain.TaxRates

// ARQUIVO CRÍTICO — FUNÇÃO: monta as dependências reais do app (banco, rede, cache e fontes).
// Não remover uma fonte, o QuoteRepository ou a inicialização do Room sem revisar as fábricas.

/** Montagem manual das dependências (simples o bastante para dispensar Hilt por enquanto). */
object AppGraph {
    private lateinit var db: AppDatabase
    private var loader: ImageLoader? = null

    lateinit var settings: AppSettings
        private set

    val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .callTimeout(25, TimeUnit.SECONDS)
            .build()
    }

    /** Alíquotas de imposto sobre proventos (Ajustes). Todo valor "líquido" do app usa estas. */
    val taxRates: StateFlow<TaxRates> get() = settings.taxRates

    /**
     * Fontes de cotação em corrida + cache em memória (TTL).
     * A que responder mais rápido (com resposta válida) no seu aparelho e rede é a usada.
     * Os tokens são lidos na hora de cada consulta, então mudar em Ajustes vale sem reiniciar.
     * Para incluir outra fonte: implemente [QuoteSource] e acrescente abaixo.
     */
    val quotes: QuoteSource by lazy {
        val sources = listOf(
            // brapi primeiro: no Brasil costuma responder gráficos com mais estabilidade
            NamedSource("brapi", BrapiQuoteSource(http) { settings.brapiToken.ifBlank { null } }),
            NamedSource("yahoo", YahooQuoteSource(http)),
            NamedSource("yahoo2", YahooQuoteSource(http, host = "query2.finance.yahoo.com")),
            NamedSource("b3", B3QuoteSource(http)),
            NamedSource("hgbrasil", HgBrasilQuoteSource(http) { settings.hgKey }),
        )
        CachedQuoteSource(RacingQuoteSource(sources))
    }

    val fundamentus: FundamentusClient by lazy { FundamentusClient(http) }

    /** Busca e destaques: brapi (com token) e, sem ele, o Fundamentus + cotações. */
    val market: MarketListSource by lazy {
        FallbackMarketSource(
            listOf(
                // Fundamentus primeiro: inclui FIIs no auto-completar mesmo sem token brapi
                FundamentusMarketSource(fundamentus, quotes),
                BrapiMarketSource(http) { settings.brapiToken },
            )
        )
    }

    val dividends: DividendRanking by lazy { DividendRanking(fundamentus) }
    val bcb: BcbClient by lazy { BcbClient(http) }

    /** Última coleta de cada dado, em disco: é o que a tela mostra, com data e hora, se a internet falhar. */
    val snapshots: Snapshots by lazy { Snapshots(RoomSnapshotStore(db.snapshotDao())) }

    val codecs: DataCodecs get() = Codecs

    val quoteRepo: QuoteRepository by lazy { QuoteRepository(quotes, snapshots, Codecs.quote, Codecs.chart) }

    val lancamentos: LancamentoRepository by lazy { LancamentoRepository(db.lancamentoDao()) }
    val watchlist: WatchlistRepository by lazy { WatchlistRepository(db.watchDao()) }

    /** Ajustes > Limpar dados guardados: apaga o que está em disco e nos caches de memória. */
    suspend fun clearCaches() {
        snapshots.clear()
        quotes.invalidateQuotes()
        fundamentus.invalidateAll()
        market.invalidate()
    }

    fun imageLoader(context: Context): ImageLoader = loader ?: ImageLoader.Builder(context.applicationContext)
        .components { add(SvgDecoder.Factory()) }
        .okHttpClient(http)
        .crossfade(true)
        .build()
        .also { loader = it }

    fun init(context: Context) {
        if (::db.isInitialized) return
        settings = AppSettings(context)
        // build() só prepara; a abertura real do SQLite acontece na primeira query (em background).
        db = Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "b3m.db")
            .addMigrations(MIGRATION_1_2)
            .build()
        // Limpa coletas antigas fora da main thread (evita qualquer chance de ANR no onCreate).
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                snapshots.prune(30L * 24 * 3600 * 1000)
            } catch (_: Throwable) {
                // Nunca derruba o app por limpeza de cache.
            }
        }
    }
}
