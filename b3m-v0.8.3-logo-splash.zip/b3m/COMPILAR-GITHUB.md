# Compilar o B3M só pelo GitHub (sem Android Studio)

## Passo a passo

### 1. Criar o repositório
1. Acesse [github.com/new](https://github.com/new).
2. Nome sugerido: `b3m` (ou o que preferir).
3. Deixe **público** ou privado.
4. **Não** marque "Add a README" (já temos um).

### 2. Enviar o código
No computador, na pasta deste projeto:

```bash
git init
git add .
git commit -m "B3M v0.8.1"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/b3m.git
git push -u origin main
```

(Substitua `SEU_USUARIO` pelo seu usuário do GitHub.)

Se preferir pela interface web: use **Add file → Upload files** e arraste **toda** a pasta (incluindo `gradlew`, `gradle/` e `.github/`).

### 3. (Opcional) Token da brapi
O token **não vai mais no APK**. Depois de instalar o app, abra a aba **Ajustes** e digite:
1. Token gratuito de [brapi.dev](https://brapi.dev) (melhora busca e destaques).
2. Opcional: chave da HG Brasil (mais uma fonte de cotações).

Eles ficam só no aparelho e fora do backup do Android. Sem o token o app usa o Fundamentus para busca e destaques.

### 4. Gerar o APK
1. Aba **Actions**.
2. Clique em **Build APK**.
3. Botão **Run workflow** → **Run workflow**.
4. Aguarde ~5–10 minutos.
5. Abra a execução concluída → seção **Artifacts**.
6. Baixe **preferencialmente o B3M-release** (assinado, não-debug — instala melhor no instalador do sistema / Arquivos do Google).
7. Extraia o ZIP e instale o `.apk` no celular.
8. Se o Google / Play Protect avisar, é normal em APKs de sideload; confirme a instalação. O SAI também continua funcionando.

**Dica de instalação no Android 11:**
- Baixe o APK (não o ZIP) se possível.
- Em Configurações → Apps → Arquivos (ou o navegador que você usou) → Ativar **“Instalar apps desconhecidos”**.
- Se já tiver uma versão antiga instalada, desinstale antes.

A cada `git push` na `main` o build roda de novo automaticamente.

## Estrutura importante (não apague)
- `gradlew` + `gradle/wrapper/` — Gradle Wrapper (obrigatório no CI)
- `.github/workflows/build.yml` — workflow de build
- `local.properties` **não** vai para o Git (está no `.gitignore`); o CI só informa o caminho do SDK
